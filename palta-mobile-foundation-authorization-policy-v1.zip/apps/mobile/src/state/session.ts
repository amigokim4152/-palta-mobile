export interface SessionStore {
  getAccessToken(): Promise<string | null>;
  setAccessToken(token: string): Promise<void>;
  clear(): Promise<void>;
}

/**
 * Temporary strict implementation: no token is persisted until secure storage is wired.
 * Do not replace this with AsyncStorage for auth tokens.
 */
export class UnconfiguredSessionStore implements SessionStore {
  async getAccessToken(): Promise<string | null> { return null; }
  async setAccessToken(_token: string): Promise<void> { throw new Error('Secure session storage is not configured.'); }
  async clear(): Promise<void> {}
}
