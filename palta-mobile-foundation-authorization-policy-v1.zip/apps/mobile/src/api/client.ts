import type { ApiEnvelope, BootstrapPayload } from '@palta/core';

const API_BASE_URL = process.env.EXPO_PUBLIC_API_BASE_URL ?? 'http://127.0.0.1:8787';

export class ApiClient {
  constructor(private readonly getAccessToken: () => Promise<string | null>) {}

  private async request<T>(path: string, init?: RequestInit): Promise<T> {
    const token = await this.getAccessToken();
    const headers = new Headers(init?.headers);
    headers.set('accept', 'application/json');
    if (init?.body) headers.set('content-type', 'application/json');
    if (token) headers.set('authorization', `Bearer ${token}`);

    const response = await fetch(`${API_BASE_URL}${path}`, { ...init, headers });
    const payload = (await response.json()) as ApiEnvelope<T>;
    if (!payload.ok) throw new Error(`${payload.error.code}: ${payload.error.message}`);
    return payload.data;
  }

  health(): Promise<{ service: string; version: string; status: string }> {
    return this.request('/health');
  }

  bootstrap(): Promise<BootstrapPayload> {
    return this.request('/v1/bootstrap');
  }
}
