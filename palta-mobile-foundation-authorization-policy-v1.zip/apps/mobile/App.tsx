import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { SafeAreaView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { ApiClient } from './src/api/client';
import { UnconfiguredSessionStore } from './src/state/session';

type HealthState = 'checking' | 'ok' | 'error';

export default function App() {
  const session = useMemo(() => new UnconfiguredSessionStore(), []);
  const api = useMemo(() => new ApiClient(() => session.getAccessToken()), [session]);
  const [health, setHealth] = useState<HealthState>('checking');

  const checkApi = useCallback(async () => {
    setHealth('checking');
    try {
      await api.health();
      setHealth('ok');
    } catch {
      setHealth('error');
    }
  }, [api]);

  useEffect(() => { void checkApi(); }, [checkApi]);

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" />
      <View style={styles.container}>
        <Text style={styles.brand}>Palta</Text>
        <Text style={styles.title}>생활을 한곳에서.</Text>
        <Text style={styles.body}>새 Palta 모바일 코어가 시작되었습니다.</Text>

        <View style={styles.card}>
          <Text style={styles.cardLabel}>기반 상태</Text>
          <Text style={styles.cardValue}>{health === 'checking' ? '확인 중' : health === 'ok' ? 'API 연결됨' : 'API 연결 필요'}</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardLabel}>다음 연결</Text>
          <Text style={styles.cardValue}>로그인 · 내 위치 · 개인 홈</Text>
          <Text style={styles.caption}>지도와 Municipalidad 데이터는 독립 트랙에서 준비 후 연결합니다.</Text>
        </View>

        <TouchableOpacity accessibilityRole="button" onPress={() => void checkApi()} style={styles.button}>
          <Text style={styles.buttonText}>연결 다시 확인</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#FAFAF7' },
  container: { flex: 1, paddingHorizontal: 24, paddingTop: 48 },
  brand: { fontSize: 18, fontWeight: '700', marginBottom: 32 },
  title: { fontSize: 32, fontWeight: '800', marginBottom: 10 },
  body: { fontSize: 16, lineHeight: 24, opacity: 0.68, marginBottom: 28 },
  card: { borderWidth: 1, borderColor: '#E4E4DE', borderRadius: 18, padding: 18, marginBottom: 14 },
  cardLabel: { fontSize: 13, opacity: 0.55, marginBottom: 7 },
  cardValue: { fontSize: 19, fontWeight: '700' },
  caption: { fontSize: 14, lineHeight: 20, opacity: 0.6, marginTop: 8 },
  button: { alignSelf: 'flex-start', borderRadius: 14, paddingHorizontal: 18, paddingVertical: 12, backgroundColor: '#151515' },
  buttonText: { color: '#FFFFFF', fontWeight: '700' }
});
