# Infrastructure boundary

Phase 1 keeps infrastructure replaceable:
- Worker talks to PostgreSQL through a standard Postgres driver/Hyperdrive layer later.
- Core schema avoids Supabase-only or provider-specific database features.
- R2 stores immutable/static or large assets, not authoritative transactional state.
- Secrets are never committed.
- Production publish remains blocked until explicit credentials and target environment exist.
