-- Privacy and audit foundations. Keep sensitive/personal actions traceable without exposing payloads in logs.

create table if not exists audit_event (
  id uuid primary key,
  actor_person_id uuid references person(id) on delete set null,
  actor_type text not null check (actor_type in ('user','system','admin','service')),
  action text not null,
  resource_kind text not null,
  resource_id text,
  request_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists audit_event_resource_idx on audit_event(resource_kind, resource_id, created_at desc);
create index if not exists audit_event_actor_idx on audit_event(actor_person_id, created_at desc);

create table if not exists data_retention_job (
  id uuid primary key,
  scope text not null,
  target_before timestamptz not null,
  status text not null default 'pending' check (status in ('pending','running','completed','failed')),
  created_at timestamptz not null default now(),
  completed_at timestamptz
);
