-- PALTA Kernel v1 hardening after five-scenario validation.
-- This migration strengthens integrity without changing domain ownership.

-- Spatial support is open PostgreSQL infrastructure, not a vendor-specific API.
create extension if not exists postgis;

alter table place
  add column if not exists geog geography(Point, 4326);

update place
set geog = ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)::geography
where geog is null and latitude is not null and longitude is not null;

create index if not exists place_geog_gist_idx on place using gist(geog);

-- Versioned administrative boundaries are separate from the administrative identity.
create table if not exists administrative_area_boundary (
  id uuid primary key,
  administrative_area_id text not null references administrative_area(id) on delete cascade,
  boundary_version text not null,
  source_kind text not null,
  source_ref text,
  effective_from timestamptz,
  effective_to timestamptz,
  geom geometry(MultiPolygon, 4326),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(administrative_area_id, boundary_version)
);
create index if not exists administrative_area_boundary_geom_idx
  on administrative_area_boundary using gist(geom);

-- A person may save several places of one type, but only one may be primary at a time.
create unique index if not exists person_place_one_primary_per_type_idx
  on person_place(person_id, relation_type)
  where is_primary = true and valid_to is null;

-- Current location is a replaceable runtime state, not a movement history stream.
create unique index if not exists person_location_one_open_current_idx
  on person_location_context(person_id)
  where context_type = 'current' and valid_until is null;

-- Event target rules express membership/audience scope without copying domain content.
create table if not exists palta_event_target (
  id uuid primary key,
  event_id uuid not null references palta_event(id) on delete cascade,
  target_kind text not null check (target_kind in (
    'person','organization','business','group','administrative_area','relationship_grant'
  )),
  target_id text,
  relation_type text,
  required_grant text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  check (
    (target_kind = 'relationship_grant' and required_grant is not null)
    or target_kind <> 'relationship_grant'
  )
);
create index if not exists palta_event_target_event_idx on palta_event_target(event_id);
create index if not exists palta_event_target_lookup_idx on palta_event_target(target_kind, target_id);

-- Relevance is a decision record. Priority is the ordering result, not the only score.
alter table need_candidate
  add column if not exists relevance_score numeric(6,3) not null default 0,
  add column if not exists location_score numeric(6,3) not null default 0,
  add column if not exists relationship_score numeric(6,3) not null default 0,
  add column if not exists decision text not null default 'evaluate'
    check (decision in ('evaluate','surface','inbox_only','action_only','store_only','suppress'));

-- Cases should be traceable back to the action that opened them.
alter table action_case
  add column if not exists action_item_id uuid references action_item(id) on delete set null;
create index if not exists action_case_action_idx on action_case(action_item_id);

-- A delivery decision needs its own idempotency key so retries do not duplicate Home/push items.
alter table delivery_projection
  add column if not exists dedupe_key text;
create unique index if not exists delivery_projection_dedupe_idx
  on delivery_projection(dedupe_key)
  where dedupe_key is not null;

-- Intake is a shared ingestion receipt. Extraction results become domain/event candidates,
-- never canonical truth solely because AI parsed them.
create table if not exists intake_receipt (
  id uuid primary key,
  person_id uuid not null references person(id) on delete cascade,
  source_type text not null check (source_type in ('whatsapp','share_sheet','link','text','media','document','manual')),
  source_context_kind text,
  source_context_id text,
  raw_text text,
  media_refs jsonb not null default '[]'::jsonb,
  status text not null default 'queued' check (status in ('queued','processing','processed','needs_review','ignored','failed')),
  privacy_class text not null default 'private' check (privacy_class in ('member_scoped','private','sensitive','ultra_sensitive')),
  created_at timestamptz not null default now(),
  processed_at timestamptz,
  metadata jsonb not null default '{}'::jsonb
);
create index if not exists intake_receipt_person_idx on intake_receipt(person_id, created_at desc);
