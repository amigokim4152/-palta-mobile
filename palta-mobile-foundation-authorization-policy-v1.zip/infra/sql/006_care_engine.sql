-- PALTA Kernel v1: Care layer.
-- Purpose: represent what a person should do, may receive, or should remember/care about.
-- This is not legal/employment/family case management. It is a life-assistance layer.

-- Event truth must distinguish a plan from something actually observed or confirmed.
alter table palta_event
  add column if not exists truth_state text not null default 'observed'
    check (truth_state in ('planned','observed','confirmed','cancelled','unknown')),
  add column if not exists confirmation_source text;

-- Care items are person-centered responsibilities/opportunities/care prompts.
-- They can come from a rule, schedule, domain record, external calendar, or explicit user input.
create table if not exists care_item (
  id uuid primary key,
  person_id uuid not null references person(id) on delete cascade,
  care_kind text not null check (care_kind in ('obligation','entitlement','care_need')),
  domain text not null,
  title text not null,
  description text,

  -- Optional context links. These are references, not ownership transfers.
  relationship_id uuid references relationship_edge(id) on delete set null,
  -- Optional person the care item is about (e.g. child/parent), while person_id remains the person Palta is helping.
  subject_person_id uuid references person(id) on delete set null,
  life_object_id uuid references life_object(id) on delete set null,
  place_id uuid references place(id) on delete set null,
  administrative_area_id text references administrative_area(id) on delete set null,
  source_event_id uuid references palta_event(id) on delete set null,

  -- Source/provenance: Palta must know why this item exists.
  source_kind text not null check (source_kind in (
    'user','rule','domain','external_calendar','external_system','derived'
  )),
  source_ref text,
  source_version text,
  source_checked_at timestamptz,
  source_valid_from timestamptz,
  source_valid_until timestamptz,
  -- Cross-domain subject reference for canonical objects not owned by the Kernel (business, program, property, etc.).
  context_kind text,
  context_ref text,
  -- Stable generation key prevents the same rule/source from creating duplicate active care items on retries.
  dedupe_key text,
  confidence text not null default 'candidate'
    check (confidence in ('candidate','likely','confirmed','verified')),

  -- Timing. A care item may be one-off or recurring.
  starts_at timestamptz,
  due_at timestamptz,
  expires_at timestamptz,
  recurrence_rule text,
  recurrence_timezone text,

  -- Care item state is intentionally lightweight. Palta does not invent real-world completion.
  status text not null default 'candidate'
    check (status in ('candidate','active','due','snoozed','handled','expired','dismissed')),
  handled_at timestamptz,
  handled_source text,

  actionability text not null default 'unknown'
    check (actionability in ('unknown','informational','actionable','externally_actionable')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists care_item_person_dedupe_uq
  on care_item(person_id, dedupe_key) where dedupe_key is not null;
create index if not exists care_item_subject_person_idx
  on care_item(subject_person_id) where subject_person_id is not null;
create index if not exists care_item_context_idx
  on care_item(context_kind, context_ref) where context_ref is not null;

create index if not exists care_item_person_due_idx
  on care_item(person_id, status, due_at);
create index if not exists care_item_kind_idx
  on care_item(person_id, care_kind, status);
create index if not exists care_item_relationship_idx
  on care_item(relationship_id) where relationship_id is not null;
create index if not exists care_item_life_object_idx
  on care_item(life_object_id) where life_object_id is not null;

-- Relevance/action decisions may reference the care item that generated them.
alter table need_candidate
  add column if not exists care_item_id uuid references care_item(id) on delete set null;
create index if not exists need_candidate_care_item_idx on need_candidate(care_item_id);

alter table action_item
  add column if not exists care_item_id uuid references care_item(id) on delete set null;
create index if not exists action_item_care_item_idx on action_item(care_item_id);

-- Optional external schedule reference. Palta does not need to own the source calendar.
create table if not exists schedule_reference (
  id uuid primary key,
  person_id uuid not null references person(id) on delete cascade,
  provider text not null,
  external_calendar_id text,
  external_event_id text not null,
  title text,
  starts_at timestamptz,
  ends_at timestamptz,
  timezone text,
  place_id uuid references place(id) on delete set null,
  sync_state text not null default 'linked'
    check (sync_state in ('linked','stale','removed','error')),
  last_seen_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb,
  unique(person_id, provider, external_event_id)
);
create index if not exists schedule_reference_person_time_idx
  on schedule_reference(person_id, starts_at);

-- Generation safety: source evidence and generator decision are explicit.
alter table care_item
  add column if not exists generation_mode text not null default 'proposed'
    check (generation_mode in ('declared','rule_derived','source_declared','extracted','proposed')),
  add column if not exists evidence_state text not null default 'unverified'
    check (evidence_state in ('unverified','source_backed','user_asserted','system_observed','authoritative')),
  add column if not exists review_state text not null default 'not_required'
    check (review_state in ('not_required','required','approved','rejected')),
  add column if not exists source_locator text,
  add column if not exists rule_id text,
  add column if not exists rule_version text;

-- AI/extraction may propose care, but may not silently upgrade evidence or authority.
-- Publication/surfacing policy is enforced by the Care Generator service, not by DB defaults alone.
