create table if not exists palta_entity (
  id text primary key,
  kind text not null,
  country_code char(2) not null default 'CL',
  comuna_code text,
  title text not null,
  verification_status text not null,
  payload jsonb not null,
  updated_at timestamptz not null,
  created_at timestamptz not null default now(),
  constraint palta_entity_verification_status_ck check (
    verification_status in ('verified','corroborated','needs_verification','stale','conflict','rejected')
  )
);

create index if not exists palta_entity_kind_idx on palta_entity(kind);
create index if not exists palta_entity_comuna_idx on palta_entity(comuna_code);
create index if not exists palta_entity_updated_idx on palta_entity(updated_at desc);
