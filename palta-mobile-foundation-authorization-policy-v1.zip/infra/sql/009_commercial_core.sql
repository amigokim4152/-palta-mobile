-- Palta Commercial Core V1 draft.
-- Purpose: common transaction semantics shared by POS, retail, wholesale,
-- restaurant, booking/quote conversion and field-service commerce.
-- Specialist operational data stays in capability modules.

create table if not exists commercial_business (
  id uuid primary key,
  canonical_entity_id text not null unique,
  status text not null default 'active' check (status in ('active','paused','closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists commercial_location (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  location_kind text not null check (location_kind in ('branch','warehouse','mobile','virtual')),
  name text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists commercial_location_business_idx on commercial_location(business_id, active);

create table if not exists commercial_capability (
  business_id uuid not null references commercial_business(id),
  capability_key text not null,
  enabled boolean not null default true,
  config jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (business_id, capability_key)
);

create table if not exists commercial_staff_assignment (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  person_ref text not null,
  location_id uuid references commercial_location(id),
  role_key text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists commercial_staff_lookup_idx on commercial_staff_assignment(business_id, person_ref, active);

create table if not exists catalog_item (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  item_kind text not null check (item_kind in ('product','service','bundle')),
  sku text,
  name text not null,
  base_price_minor bigint,
  currency char(3) not null default 'CLP',
  active boolean not null default true,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, sku)
);
create index if not exists catalog_item_business_idx on catalog_item(business_id, active);

create table if not exists inventory_position (
  business_id uuid not null references commercial_business(id),
  location_id uuid not null references commercial_location(id),
  catalog_item_id uuid not null references catalog_item(id),
  quantity numeric(18,4) not null default 0,
  updated_at timestamptz not null default now(),
  primary key (location_id, catalog_item_id)
);

create table if not exists commercial_order (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  location_id uuid references commercial_location(id),
  customer_ref text,
  channel text not null check (channel in ('pos','app','web','quote','booking','manual','integration')),
  state text not null check (state in ('draft','accepted','in_fulfillment','completed','cancelled')),
  currency char(3) not null default 'CLP',
  subtotal_minor bigint not null default 0,
  discount_minor bigint not null default 0,
  tax_minor bigint not null default 0,
  total_minor bigint not null default 0,
  client_idempotency_key text not null,
  source_case_ref text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, client_idempotency_key)
);
create index if not exists commercial_order_business_created_idx on commercial_order(business_id, created_at desc);

create table if not exists commercial_order_line (
  id uuid primary key,
  order_id uuid not null references commercial_order(id) on delete restrict,
  catalog_item_id uuid references catalog_item(id),
  line_no integer not null check (line_no > 0),
  description text not null,
  quantity numeric(18,4) not null check (quantity > 0),
  unit_price_minor bigint not null,
  discount_minor bigint not null default 0,
  tax_minor bigint not null default 0,
  line_total_minor bigint not null,
  metadata jsonb not null default '{}'::jsonb,
  unique (order_id, line_no)
);
create index if not exists commercial_order_line_order_idx on commercial_order_line(order_id);

create table if not exists inventory_movement (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  location_id uuid not null references commercial_location(id),
  catalog_item_id uuid not null references catalog_item(id),
  movement_kind text not null check (movement_kind in ('sale','return','adjustment','transfer_in','transfer_out','stocktake')),
  quantity_delta numeric(18,4) not null check (quantity_delta <> 0),
  order_id uuid references commercial_order(id),
  idempotency_key text not null,
  reason text,
  actor_ref text,
  occurred_at timestamptz not null default now(),
  unique (business_id, idempotency_key)
);
create index if not exists inventory_movement_item_idx on inventory_movement(location_id, catalog_item_id, occurred_at);

create table if not exists pos_register_session (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  location_id uuid not null references commercial_location(id),
  register_ref text not null,
  opened_by text not null,
  opened_at timestamptz not null,
  opening_cash_minor bigint not null default 0,
  status text not null check (status in ('open','closing','closed')),
  closed_by text,
  closed_at timestamptz,
  expected_cash_minor bigint,
  counted_cash_minor bigint,
  variance_minor bigint,
  close_note text
);
create unique index if not exists pos_register_one_open_idx
  on pos_register_session(business_id, location_id, register_ref)
  where status in ('open','closing');

create table if not exists payment_result (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  order_id uuid not null references commercial_order(id),
  provider_key text not null,
  provider_transaction_ref text,
  status text not null check (status in ('pending','authorized','captured','failed','voided','refunded','unknown')),
  amount_minor bigint not null,
  currency char(3) not null default 'CLP',
  request_idempotency_key text not null,
  provider_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, request_idempotency_key)
);
create index if not exists payment_result_order_idx on payment_result(order_id, status);

create table if not exists tax_document_request (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  order_id uuid not null references commercial_order(id),
  document_kind text not null,
  adapter_version text not null,
  status text not null check (status in ('pending','submitted','accepted','rejected','cancelled','unknown')),
  external_ref text,
  idempotency_key text not null,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, idempotency_key)
);
create index if not exists tax_document_order_idx on tax_document_request(order_id, status);

create table if not exists commercial_return (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  original_order_id uuid not null references commercial_order(id),
  state text not null check (state in ('requested','approved','completed','rejected','cancelled')),
  reason text,
  client_idempotency_key text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, client_idempotency_key)
);

create table if not exists commercial_return_line (
  id uuid primary key,
  return_id uuid not null references commercial_return(id),
  original_order_line_id uuid not null references commercial_order_line(id),
  quantity numeric(18,4) not null check (quantity > 0),
  disposition text not null check (disposition in ('restock','damage','discard','inspection')),
  unique (return_id, original_order_line_id)
);

comment on table commercial_order is 'Common commercial transaction order. Specialist restaurant/booking/quote/work-order semantics stay in capability modules.';
comment on table inventory_movement is 'Immutable stock ledger event; inventory_position is the current projection and must not be treated as the audit source.';
comment on table payment_result is 'External provider result only. It does not make Palta the payment operator.';
comment on table tax_document_request is 'Versioned country-adapter request state; SII-specific rules stay outside Commercial Core.';
