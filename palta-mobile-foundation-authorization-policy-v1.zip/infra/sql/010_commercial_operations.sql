-- Palta Commercial Operations V1 draft.
-- Purpose: staff authorization, caja audit, multi-location transfers,
-- exchanges, and offline sync conflict receipts.
-- These controls belong to Commercial/POS, not Shared Core.

create table if not exists commercial_role (
  business_id uuid not null references commercial_business(id),
  role_key text not null,
  name text not null,
  system_role boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (business_id, role_key)
);

create table if not exists commercial_role_permission (
  business_id uuid not null references commercial_business(id),
  role_key text not null,
  permission_key text not null,
  effect text not null default 'allow' check (effect in ('allow','deny')),
  created_at timestamptz not null default now(),
  primary key (business_id, role_key, permission_key),
  foreign key (business_id, role_key) references commercial_role(business_id, role_key)
);

-- A staff assignment can be location-scoped. NULL location means business-wide.
-- Authorization must be evaluated at action time; role names alone are not permissions.
create table if not exists commercial_staff_role_assignment (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  person_ref text not null,
  role_key text not null,
  location_id uuid references commercial_location(id),
  active boolean not null default true,
  valid_from timestamptz not null default now(),
  valid_until timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (business_id, role_key) references commercial_role(business_id, role_key)
);
create index if not exists commercial_staff_role_lookup_idx
  on commercial_staff_role_assignment(business_id, person_ref, active, location_id);

-- Immutable cash movements. Expected cash at close is derived from opening cash
-- plus these movements; it must never be "fixed" by rewriting sales.
create table if not exists pos_cash_movement (
  id uuid primary key,
  session_id uuid not null references pos_register_session(id),
  movement_kind text not null check (movement_kind in ('cash_sale','cash_refund','cash_in','cash_out','correction')),
  amount_minor bigint not null check (amount_minor <> 0),
  reason text,
  actor_ref text not null,
  idempotency_key text not null,
  occurred_at timestamptz not null default now(),
  unique (session_id, idempotency_key)
);
create index if not exists pos_cash_movement_session_idx on pos_cash_movement(session_id, occurred_at);

-- Store close snapshots separately so counted denominations/evidence can evolve
-- without mutating the register session audit trail.
create table if not exists pos_register_close_snapshot (
  id uuid primary key,
  session_id uuid not null references pos_register_session(id),
  counted_cash_minor bigint not null,
  expected_cash_minor bigint not null,
  variance_minor bigint not null,
  count_detail jsonb not null default '{}'::jsonb,
  note text,
  actor_ref text not null,
  created_at timestamptz not null default now(),
  unique (session_id)
);

create table if not exists inventory_transfer (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  from_location_id uuid not null references commercial_location(id),
  to_location_id uuid not null references commercial_location(id),
  state text not null check (state in ('draft','approved','in_transit','received','cancelled')),
  client_idempotency_key text not null,
  requested_by text not null,
  approved_by text,
  received_by text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (from_location_id <> to_location_id),
  unique (business_id, client_idempotency_key)
);

create table if not exists inventory_transfer_line (
  id uuid primary key,
  transfer_id uuid not null references inventory_transfer(id),
  catalog_item_id uuid not null references catalog_item(id),
  line_no integer not null check (line_no > 0),
  quantity numeric(18,4) not null check (quantity > 0),
  unique (transfer_id, line_no)
);

-- Exchange is not a stock mutation shortcut. It links a completed/approved return
-- to a normal replacement order so price/tax/payment differences remain auditable.
create table if not exists commercial_exchange (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  return_id uuid not null references commercial_return(id),
  replacement_order_id uuid not null references commercial_order(id),
  state text not null check (state in ('open','completed','cancelled')),
  client_idempotency_key text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, client_idempotency_key),
  unique (return_id, replacement_order_id)
);

-- Offline devices submit operations with stable client operation IDs.
-- Server receipts make reconnect/retry idempotent and surface conflicts explicitly.
create table if not exists commercial_sync_receipt (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  device_ref text not null,
  client_operation_id text not null,
  operation_kind text not null,
  resource_kind text,
  resource_ref text,
  client_base_version bigint,
  server_version bigint,
  status text not null check (status in ('accepted','applied','rejected','conflict')),
  conflict_reason text,
  result_ref text,
  received_at timestamptz not null default now(),
  applied_at timestamptz,
  unique (business_id, device_ref, client_operation_id)
);
create index if not exists commercial_sync_status_idx
  on commercial_sync_receipt(business_id, status, received_at);

-- Version supports optimistic concurrency for current projections. The immutable
-- inventory_movement ledger remains the audit source of truth.
alter table inventory_position add column if not exists version bigint not null default 0;

comment on table commercial_role_permission is 'Commercial/POS permissions only; Shared Verification establishes identity/assurance but does not grant business operational rights.';
comment on table pos_cash_movement is 'Immutable caja cash ledger. Closing variance never rewrites sales or payment records.';
comment on table inventory_transfer is 'Two-location transfer workflow; transfer_out and transfer_in inventory movements must be idempotent and linked to this transfer by application logic.';
comment on table commercial_exchange is 'Exchange = return + replacement order, preserving independent inventory/payment/tax history.';
comment on table commercial_sync_receipt is 'Offline sync idempotency/conflict receipt. Conflicts are explicit; last-write-wins is not allowed for financial or stock operations.';
