-- Palta privacy/operator/safety boundary v1.
-- Private data is not an operator workspace. Work context is purpose-limited and auditable.

create table if not exists work_context (
  id uuid primary key,
  context_kind text not null check (context_kind in ('business_onboarding','business_support','palta_support','moderation_case','legal_case')),
  subject_kind text not null,
  subject_ref text not null,
  purpose text not null,
  status text not null default 'open' check (status in ('open','waiting','resolved','closed')),
  opened_by_person_id uuid references person(id) on delete set null,
  created_at timestamptz not null default now(),
  closed_at timestamptz
);
create index if not exists work_context_subject_idx on work_context(subject_kind, subject_ref, status);

create table if not exists work_context_participant (
  work_context_id uuid not null references work_context(id) on delete cascade,
  participant_kind text not null check (participant_kind in ('person','business','operator','service')),
  participant_ref text not null,
  role text not null,
  primary key(work_context_id, participant_kind, participant_ref)
);

create table if not exists privacy_access_decision (
  id uuid primary key,
  actor_kind text not null check (actor_kind in ('person','business_member','operator','operator_ai','personal_ai','service')),
  actor_ref text not null,
  data_realm text not null check (data_realm in ('public','work','private','sensitive','analytics')),
  resource_kind text not null,
  resource_ref text,
  purpose text not null,
  work_context_id uuid references work_context(id) on delete set null,
  decision text not null check (decision in ('allow','deny','review')),
  reason_code text not null,
  request_id text,
  decided_at timestamptz not null default now()
);
create index if not exists privacy_access_actor_idx on privacy_access_decision(actor_kind, actor_ref, decided_at desc);
create index if not exists privacy_access_denied_idx on privacy_access_decision(decided_at desc) where decision = 'deny';

create table if not exists analytics_subject (
  analytics_id uuid primary key,
  person_id uuid not null unique references person(id) on delete cascade,
  created_at timestamptz not null default now()
);
comment on table analytics_subject is 'Pseudonymous mapping. Never expose person_id through analytics/operator APIs.';

create table if not exists aggregate_release_policy (
  metric_kind text primary key,
  minimum_cohort integer not null default 20 check (minimum_cohort >= 5),
  minimum_time_bucket interval not null default interval '1 day',
  minimum_geo_level text not null default 'comuna',
  suppress_rare_dimensions boolean not null default true,
  updated_at timestamptz not null default now()
);

create table if not exists moderation_case (
  id uuid primary key,
  content_kind text not null,
  content_ref text not null,
  reporter_person_id uuid references person(id) on delete set null,
  status text not null default 'open' check (status in ('open','automated_review','human_review','actioned','appealed','closed')),
  risk_kinds text[] not null default '{}',
  decision text check (decision in ('publish','limit','hold','request_edit','remove','restrict_account','escalate')),
  evidence_ref text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists moderation_case_status_idx on moderation_case(status, created_at);

create table if not exists moderation_action (
  id uuid primary key,
  case_id uuid not null references moderation_case(id) on delete cascade,
  actor_kind text not null check (actor_kind in ('rule','ai','operator','system')),
  actor_ref text,
  action text not null,
  reason_code text not null,
  payload_hash text,
  created_at timestamptz not null default now()
);

create table if not exists security_incident (
  id uuid primary key,
  incident_kind text not null,
  severity text not null check (severity in ('low','medium','high','critical')),
  status text not null default 'open' check (status in ('open','contained','investigating','recovered','closed')),
  detected_at timestamptz not null default now(),
  contained_at timestamptz,
  closed_at timestamptz,
  evidence_ref text,
  metadata jsonb not null default '{}'::jsonb
);
