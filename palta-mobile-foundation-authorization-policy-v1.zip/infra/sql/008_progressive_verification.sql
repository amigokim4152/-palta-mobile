-- PALTA Kernel v1: progressive verification / action assurance.
-- Verification is demanded by risky actions, never inferred from relationships and never used as a universal trust score.

create table if not exists verification_assertion (
  id uuid primary key,
  subject_kind text not null check (subject_kind in ('person','business','organization')),
  subject_ref text not null,
  assertion_type text not null,
  status text not null check (status in ('pending','verified','failed','expired','revoked')),
  provider_kind text not null check (provider_kind in ('palta_account','official_registry','regulated_provider','trusted_domain_adapter','manual_review')),
  provider_ref text,
  evidence_ref text,
  verified_at timestamptz,
  expires_at timestamptz,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists verification_assertion_subject_idx
  on verification_assertion(subject_kind, subject_ref, assertion_type, status);

create table if not exists action_assurance_policy (
  action_kind text primary key,
  risk_tier text not null check (risk_tier in ('open','account','interaction','qualified','regulated')),
  required_assertions jsonb not null default '[]'::jsonb,
  verification_timing text not null default 'at_action'
    check (verification_timing in ('none','at_action','before_activation')),
  notes text,
  updated_at timestamptz not null default now()
);

-- This is capability gating only. It must not be reused as ranking/reputation/trust.
comment on table verification_assertion is
  'Purpose-specific verification facts. Not a universal trust score and not authority derived from family/relationship edges.';
comment on table action_assurance_policy is
  'Maps risky actions to minimum verification assertions. Low-risk browsing/discovery remains open.';
