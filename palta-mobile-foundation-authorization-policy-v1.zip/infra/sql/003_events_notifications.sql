-- PALTA Kernel v1: Event -> Need/Relevance -> Action -> Case/Outcome -> Life History.
-- Domain records remain canonical in their owning domain. palta_event is the shared event envelope.

create table if not exists palta_event (
  id uuid primary key,
  event_type text not null,
  producer_domain text not null,
  subject_kind text,
  subject_id text,
  place_id uuid references place(id) on delete set null,
  administrative_area_id text references administrative_area(id) on delete set null,
  occurred_at timestamptz not null,
  effective_from timestamptz,
  expires_at timestamptz,
  urgency text not null default 'normal' check (urgency in ('low','normal','attention','urgent','critical')),
  privacy_class text not null default 'public' check (privacy_class in ('public','member_scoped','private','sensitive','ultra_sensitive')),
  visibility_scope text not null default 'public',
  source_kind text,
  source_ref text,
  dedupe_key text,
  payload_version integer not null default 1,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create unique index if not exists palta_event_dedupe_idx on palta_event(dedupe_key) where dedupe_key is not null;
create index if not exists palta_event_time_idx on palta_event(occurred_at desc);
create index if not exists palta_event_geo_idx on palta_event(administrative_area_id, occurred_at desc);
create index if not exists palta_event_subject_idx on palta_event(subject_kind, subject_id, occurred_at desc);

create table if not exists need_candidate (
  id uuid primary key,
  person_id uuid not null references person(id) on delete cascade,
  event_id uuid references palta_event(id) on delete cascade,
  domain text not null,
  need_type text not null,
  title text not null,
  reason text,
  status text not null default 'candidate' check (status in ('candidate','active','snoozed','done','expired','dismissed')),
  urgency_score numeric(6,3) not null default 0,
  timing_score numeric(6,3) not null default 0,
  context_score numeric(6,3) not null default 0,
  actionability_score numeric(6,3) not null default 0,
  confidence_score numeric(6,3) not null default 0,
  priority_score numeric(6,3) not null default 0,
  why_shown jsonb not null default '{}'::jsonb,
  due_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists need_candidate_person_priority_idx on need_candidate(person_id, status, priority_score desc);

create table if not exists action_item (
  id uuid primary key,
  person_id uuid not null references person(id) on delete cascade,
  need_id uuid references need_candidate(id) on delete set null,
  event_id uuid references palta_event(id) on delete set null,
  domain text not null,
  action_type text not null,
  title text not null,
  status text not null default 'open' check (status in ('open','scheduled','in_progress','completed','cancelled','expired')),
  target_kind text,
  target_id text,
  action_uri text,
  due_at timestamptz,
  completed_at timestamptz,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists action_item_person_idx on action_item(person_id, status, due_at);

create table if not exists action_case (
  id uuid primary key,
  person_id uuid references person(id) on delete set null,
  domain text not null,
  case_type text not null,
  subject_kind text,
  subject_id text,
  provider_kind text,
  provider_id text,
  status text not null default 'requested' check (status in ('requested','accepted','scheduled','in_progress','waiting','completed_by_provider','confirmed_by_user','resolved','cancelled','rejected')),
  opened_at timestamptz not null default now(),
  resolved_at timestamptz,
  source_event_id uuid references palta_event(id) on delete set null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists action_case_person_idx on action_case(person_id, status, updated_at desc);
create index if not exists action_case_provider_idx on action_case(provider_kind, provider_id, status);

create table if not exists case_transition (
  id uuid primary key,
  case_id uuid not null references action_case(id) on delete cascade,
  from_status text,
  to_status text not null,
  actor_kind text not null check (actor_kind in ('person','provider','organization','system','admin')),
  actor_id text,
  note text,
  occurred_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb
);
create index if not exists case_transition_case_idx on case_transition(case_id, occurred_at);

create table if not exists case_outcome (
  id uuid primary key,
  case_id uuid not null references action_case(id) on delete cascade,
  outcome_type text not null,
  summary text,
  provider_completed_at timestamptz,
  person_confirmed_at timestamptz,
  confirmation_status text not null default 'pending' check (confirmation_status in ('pending','confirmed','disputed','not_required')),
  amount numeric,
  currency char(3) not null default 'CLP',
  next_due_at timestamptz,
  warranty_until date,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists case_outcome_case_idx on case_outcome(case_id);

create table if not exists life_history (
  id uuid primary key,
  person_id uuid not null references person(id) on delete cascade,
  life_object_id uuid references life_object(id) on delete set null,
  source_event_id uuid references palta_event(id) on delete set null,
  source_case_id uuid references action_case(id) on delete set null,
  domain text not null,
  history_type text not null,
  title text not null,
  occurred_at timestamptz not null,
  provider_kind text,
  provider_id text,
  verification_status text not null default 'unverified' check (verification_status in ('unverified','user_confirmed','provider_verified','platform_verified')),
  next_due_at timestamptz,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists life_history_person_idx on life_history(person_id, occurred_at desc);
create index if not exists life_history_object_idx on life_history(life_object_id, occurred_at desc);

-- Delivery is a projection decision, not a domain-specific notification taxonomy.
create table if not exists delivery_projection (
  id uuid primary key,
  person_id uuid not null references person(id) on delete cascade,
  event_id uuid references palta_event(id) on delete set null,
  need_id uuid references need_candidate(id) on delete set null,
  channel text not null check (channel in ('home','inbox','push','calendar')),
  status text not null default 'pending' check (status in ('pending','ready','delivered','read','dismissed','suppressed','failed','expired')),
  title text not null,
  body text,
  action_uri text,
  privacy_mode text not null default 'full' check (privacy_mode in ('full','redacted','generic_private','in_app_only')),
  rank_score numeric(6,3),
  available_at timestamptz not null default now(),
  expires_at timestamptz,
  delivered_at timestamptz,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists delivery_projection_person_channel_idx on delivery_projection(person_id, channel, status, rank_score desc, created_at desc);

create table if not exists device_installation (
  id uuid primary key,
  person_id uuid references person(id) on delete cascade,
  platform text not null check (platform in ('ios','android')),
  push_token text,
  app_version text,
  device_locale text,
  last_seen_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique(platform, push_token)
);

create table if not exists outbox_message (
  id uuid primary key,
  topic text not null,
  payload jsonb not null,
  created_at timestamptz not null default now(),
  published_at timestamptz,
  attempts integer not null default 0
);
create index if not exists outbox_unpublished_idx on outbox_message(created_at) where published_at is null;
