-- PALTA Kernel v1: relationship/access boundary hardening.
-- Relationship context never grants access by itself. This table records explicit, narrow sharing only.

create table if not exists access_grant (
  id uuid primary key,
  grantor_person_id uuid not null references person(id) on delete cascade,
  recipient_person_id uuid not null references person(id) on delete cascade,
  subject_person_id uuid references person(id) on delete cascade,
  purpose text not null,
  resource_kind text not null,
  resource_ref text,
  detail_level text not null default 'minimum'
    check (detail_level in ('minimum','summary','specific_item')),
  starts_at timestamptz not null default now(),
  expires_at timestamptz,
  revoked_at timestamptz,
  source_kind text not null default 'explicit_user'
    check (source_kind in ('explicit_user','trusted_domain_adapter','authorized_external_adapter')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  check (grantor_person_id <> recipient_person_id),
  check (expires_at is null or expires_at > starts_at)
);
create index if not exists access_grant_recipient_active_idx
  on access_grant(recipient_person_id, resource_kind, expires_at)
  where revoked_at is null;
create index if not exists access_grant_subject_idx
  on access_grant(subject_person_id) where subject_person_id is not null;

comment on column relationship_edge.grants is
  'DEPRECATED for authorization. Relationship metadata must not confer access. Use access_grant for explicit purpose-limited sharing.';

-- A LifeObject is canonical independently of legal ownership. person_id in the original draft
-- represented convenience ownership and is removed before production deployment.
alter table life_object alter column person_id drop not null;
comment on column life_object.person_id is
  'LEGACY migration aid only; not legal ownership. New code must use life_object_relation.';

create table if not exists life_object_relation (
  id uuid primary key,
  life_object_id uuid not null references life_object(id) on delete cascade,
  person_id uuid not null references person(id) on delete cascade,
  relation_type text not null,
  source_kind text not null default 'explicit_user'
    check (source_kind in ('explicit_user','verified_system','imported','inferred')),
  confidence text not null default 'confirmed'
    check (confidence in ('confirmed','verified','inferred','possible')),
  starts_at timestamptz,
  ends_at timestamptz,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(life_object_id, person_id, relation_type)
);
create index if not exists life_object_relation_person_idx
  on life_object_relation(person_id, relation_type);
