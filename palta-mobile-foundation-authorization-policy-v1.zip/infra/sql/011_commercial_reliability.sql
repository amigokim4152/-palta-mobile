-- Palta Commercial Reliability V1 draft.
-- Purpose: crash-safe command handling, after-commit side effects, inventory reservation,
-- and explicit reconciliation for ambiguous external/transaction outcomes.
-- These controls belong to Commercial/POS, not Shared Core.

-- Stable command boundary for retries from POS/mobile/web/integrations.
-- The same command ID with a different request hash must be rejected by application logic.
create table if not exists commercial_command_receipt (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  command_scope text not null,
  command_id text not null,
  request_hash text not null,
  status text not null check (status in ('processing','applied','failed','unknown')),
  result_kind text,
  result_ref text,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, command_scope, command_id)
);
create index if not exists commercial_command_status_idx
  on commercial_command_receipt(business_id, status, created_at);

-- Transactional outbox. Domain changes and their outbound side effects are written in the
-- same DB transaction. Workers publish after commit and may safely retry delivery.
create table if not exists commercial_outbox_event (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  aggregate_kind text not null,
  aggregate_ref text not null,
  event_kind text not null,
  payload jsonb not null default '{}'::jsonb,
  dedupe_key text not null,
  status text not null default 'pending' check (status in ('pending','processing','delivered','failed','dead_letter')),
  attempts integer not null default 0 check (attempts >= 0),
  available_at timestamptz not null default now(),
  locked_at timestamptz,
  delivered_at timestamptz,
  last_error text,
  created_at timestamptz not null default now(),
  unique (business_id, dedupe_key)
);
create index if not exists commercial_outbox_ready_idx
  on commercial_outbox_event(status, available_at)
  where status in ('pending','failed');

-- Reservations protect stock shared across POS/app/web channels before fulfillment.
-- They are optional for immediate local counter sales but required where oversell risk exists.
create table if not exists inventory_reservation (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  location_id uuid not null references commercial_location(id),
  catalog_item_id uuid not null references catalog_item(id),
  order_id uuid references commercial_order(id),
  quantity numeric(18,4) not null check (quantity > 0),
  status text not null check (status in ('active','consumed','released','expired','cancelled')),
  idempotency_key text not null,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, idempotency_key)
);
create index if not exists inventory_reservation_active_idx
  on inventory_reservation(location_id, catalog_item_id, expires_at)
  where status = 'active';

-- Explicit review queue for cases where the system cannot safely infer the real outcome.
-- Examples: provider timeout after card authorization, SII timeout after submission,
-- commit acknowledgement lost, cash mismatch, stock projection mismatch.
create table if not exists commercial_reconciliation_issue (
  id uuid primary key,
  business_id uuid not null references commercial_business(id),
  issue_kind text not null check (issue_kind in (
    'db_commit_unknown','payment_unknown','tax_document_unknown','inventory_mismatch',
    'cash_variance','transfer_mismatch','sync_conflict','other'
  )),
  severity text not null default 'review' check (severity in ('info','review','blocking')),
  resource_kind text,
  resource_ref text,
  source_ref text,
  status text not null default 'open' check (status in ('open','investigating','resolved','dismissed')),
  details jsonb not null default '{}'::jsonb,
  detected_at timestamptz not null default now(),
  resolved_at timestamptz,
  resolved_by text,
  resolution_note text
);
create index if not exists commercial_reconciliation_open_idx
  on commercial_reconciliation_issue(business_id, severity, detected_at)
  where status in ('open','investigating');

-- Prevent accidental cross-business joins at the DB boundary for critical stock references.
-- Existing single-column FKs remain valid; these composite keys add tenant consistency.
create unique index if not exists commercial_location_id_business_uq
  on commercial_location(id, business_id);
create unique index if not exists catalog_item_id_business_uq
  on catalog_item(id, business_id);
create unique index if not exists commercial_order_id_business_uq
  on commercial_order(id, business_id);

alter table inventory_position
  add constraint inventory_position_location_business_fk
  foreign key (location_id, business_id) references commercial_location(id, business_id);
alter table inventory_position
  add constraint inventory_position_item_business_fk
  foreign key (catalog_item_id, business_id) references catalog_item(id, business_id);

alter table inventory_movement
  add constraint inventory_movement_location_business_fk
  foreign key (location_id, business_id) references commercial_location(id, business_id);
alter table inventory_movement
  add constraint inventory_movement_item_business_fk
  foreign key (catalog_item_id, business_id) references catalog_item(id, business_id);

comment on table commercial_command_receipt is 'Idempotent command boundary. A duplicate command ID returns the original outcome; the same ID with a different request hash is rejected.';
comment on table commercial_outbox_event is 'Transactional outbox for after-commit side effects such as notifications, SII submission jobs, provider callbacks, and integrations.';
comment on table inventory_reservation is 'Short-lived stock hold for channels where concurrent demand can oversell inventory; immutable inventory movements remain the audit source.';
comment on table commercial_reconciliation_issue is 'Explicit human/system review queue for ambiguous outcomes. Never guess whether money, tax, stock, or commit succeeded.';
