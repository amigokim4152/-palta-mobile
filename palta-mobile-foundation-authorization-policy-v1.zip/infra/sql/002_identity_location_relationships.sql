-- PALTA Kernel v1: Person, place, geography, relationships and life objects.
-- Auth credentials remain provider-owned. Palta stores provider-neutral identity links only.

create table if not exists person (
  id uuid primary key,
  display_name text,
  locale text not null default 'es-CL',
  timezone text not null default 'America/Santiago',
  status text not null default 'active' check (status in ('active','disabled','pending_deletion')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists auth_identity (
  id uuid primary key,
  person_id uuid not null references person(id) on delete cascade,
  provider text not null,
  provider_subject text not null,
  email text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(provider, provider_subject)
);
create index if not exists auth_identity_person_idx on auth_identity(person_id);

create table if not exists administrative_area (
  id text primary key,
  country_code char(2) not null default 'CL',
  area_type text not null check (area_type in ('country','region','province','comuna')),
  official_code text,
  name text not null,
  parent_id text references administrative_area(id) on delete restrict,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(country_code, area_type, official_code)
);
create index if not exists administrative_area_parent_idx on administrative_area(parent_id);

create table if not exists place (
  id uuid primary key,
  country_code char(2) not null default 'CL',
  place_kind text not null check (place_kind in ('address','poi','facility','venue','area_anchor','other')),
  name text,
  address_text text,
  latitude double precision,
  longitude double precision,
  comuna_area_id text references administrative_area(id) on delete set null,
  locality text,
  coordinate_precision text check (coordinate_precision in ('exact','approximate','area_only')),
  source_kind text,
  source_ref text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check ((latitude is null and longitude is null) or (latitude between -90 and 90 and longitude between -180 and 180))
);
create index if not exists place_comuna_idx on place(comuna_area_id);
create index if not exists place_lat_lng_idx on place(latitude, longitude);

create table if not exists person_place (
  id uuid primary key,
  person_id uuid not null references person(id) on delete cascade,
  place_id uuid not null references place(id) on delete cascade,
  relation_type text not null check (relation_type in ('home','work','school','saved','other')),
  label text,
  is_primary boolean not null default false,
  valid_from timestamptz,
  valid_to timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(person_id, place_id, relation_type)
);
create index if not exists person_place_person_idx on person_place(person_id, relation_type);

-- Runtime context, not a permanent movement trail. Expire temporary/current rows aggressively.
create table if not exists person_location_context (
  id uuid primary key,
  person_id uuid not null references person(id) on delete cascade,
  context_type text not null check (context_type in ('current','habitual','temporary','jurisdiction')),
  place_id uuid references place(id) on delete set null,
  administrative_area_id text references administrative_area(id) on delete set null,
  latitude double precision,
  longitude double precision,
  accuracy_m double precision,
  source text not null check (source in ('gps','saved_place','manual','derived')),
  valid_from timestamptz not null default now(),
  valid_until timestamptz,
  updated_at timestamptz not null default now(),
  check ((latitude is null and longitude is null) or (latitude between -90 and 90 and longitude between -180 and 180))
);
create index if not exists person_location_context_active_idx
  on person_location_context(person_id, context_type, updated_at desc);

create table if not exists relationship_edge (
  id uuid primary key,
  person_id uuid not null references person(id) on delete cascade,
  target_kind text not null check (target_kind in ('person','organization','business','group','administrative_area')),
  target_id text not null,
  relation_type text not null,
  status text not null default 'requested' check (status in ('requested','active','paused','ended','rejected')),
  verification text not null default 'self_declared' check (verification in ('self_declared','counterpart_approved','official_verified')),
  grants jsonb not null default '[]'::jsonb,
  visibility text not null default 'private' check (visibility in ('private','counterpart_visible','public')),
  source_kind text not null default 'manual',
  source_ref text,
  started_at timestamptz,
  ended_at timestamptz,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(person_id, target_kind, target_id, relation_type)
);
create index if not exists relationship_edge_person_idx on relationship_edge(person_id, status);
create index if not exists relationship_edge_target_idx on relationship_edge(target_kind, target_id, status);

create table if not exists life_object (
  id uuid primary key,
  person_id uuid not null references person(id) on delete cascade,
  object_type text not null check (object_type in ('home','vehicle','pet','contract','subscription','insurance','document','device','other')),
  title text not null,
  status text not null default 'active' check (status in ('active','inactive','disposed','ended')),
  lifecycle_stage text,
  source_kind text not null default 'explicit_user' check (source_kind in ('explicit_user','verified_system','imported','inferred')),
  source_ref text,
  confidence text not null default 'confirmed' check (confidence in ('confirmed','verified','inferred','possible')),
  started_at timestamptz,
  ended_at timestamptz,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists life_object_person_idx on life_object(person_id, object_type, status);
