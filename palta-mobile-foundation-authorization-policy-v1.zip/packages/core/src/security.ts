import type { AccessRequest, AccessResult } from './index';

export interface AuthorizationFacts {
  isResourceOwner?: boolean;
  isWorkParticipant?: boolean;
  workContextOpen?: boolean;
  workPurposeMatches?: boolean;
  analyticsAggregateOnly?: boolean;
  breakGlassApproved?: boolean;
}

const deny = (reasonCode: string): AccessResult => ({ decision: 'deny', reasonCode, maximumDetail: 'none' });

/**
 * Pure, deterministic authorization policy. AI/model output never changes these facts.
 * Callers must resolve facts from trusted server-side data, never from request text.
 */
export function authorizeAccess(req: AccessRequest, facts: AuthorizationFacts): AccessResult {
  if (req.actor === 'operator_ai') {
    if (req.realm === 'private' || req.realm === 'sensitive') return deny('operator_ai_private_forbidden');
    if (req.realm === 'analytics') {
      return facts.analyticsAggregateOnly
        ? { decision: 'allow', reasonCode: 'aggregate_analytics_only', maximumDetail: 'summary' }
        : deny('operator_ai_individual_analytics_forbidden');
    }
    if (req.realm === 'work') {
      if (!req.workContextId) return deny('work_context_required');
      if (!facts.workContextOpen || !facts.isWorkParticipant || !facts.workPurposeMatches) return deny('work_context_scope_mismatch');
      return { decision: 'allow', reasonCode: 'authorized_work_context', maximumDetail: 'specific_item' };
    }
    return { decision: 'allow', reasonCode: 'public_read', maximumDetail: 'specific_item' };
  }

  if (req.actor === 'operator') {
    if (req.realm === 'private' || req.realm === 'sensitive') {
      return facts.breakGlassApproved
        ? { decision: 'review', reasonCode: 'break_glass_review_required', maximumDetail: 'specific_item' }
        : deny('operator_private_forbidden');
    }
    if (req.realm === 'work') {
      if (!req.workContextId) return deny('work_context_required');
      if (!facts.workContextOpen || !facts.isWorkParticipant || !facts.workPurposeMatches) return deny('work_context_scope_mismatch');
      return { decision: 'allow', reasonCode: 'authorized_work_context', maximumDetail: 'specific_item' };
    }
  }

  if (req.actor === 'person' || req.actor === 'personal_ai') {
    if ((req.realm === 'private' || req.realm === 'sensitive') && !facts.isResourceOwner) return deny('resource_owner_required');
    if (facts.isResourceOwner) return { decision: 'allow', reasonCode: 'resource_owner', maximumDetail: 'specific_item' };
  }

  if (req.realm === 'analytics' && !facts.analyticsAggregateOnly) return deny('individual_analytics_forbidden');
  if (req.realm === 'public') return { decision: 'allow', reasonCode: 'public_read', maximumDetail: 'specific_item' };
  return deny('no_matching_authorization');
}
