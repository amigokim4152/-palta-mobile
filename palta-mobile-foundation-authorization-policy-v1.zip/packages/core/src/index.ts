export type DataVerificationStatus =
  | 'verified'
  | 'corroborated'
  | 'needs_verification'
  | 'stale'
  | 'conflict'
  | 'rejected';

export type PrivacyClass =
  | 'public'
  | 'member_scoped'
  | 'private'
  | 'sensitive'
  | 'ultra_sensitive';

export type DeliveryChannel = 'home' | 'inbox' | 'push' | 'calendar';
export type CareKind = 'obligation' | 'entitlement' | 'care_need';
export type EventTruthState = 'planned' | 'observed' | 'confirmed' | 'cancelled' | 'unknown';
export type LocationContextType = 'current' | 'habitual' | 'temporary' | 'jurisdiction';
export type LifeObjectType = 'home' | 'vehicle' | 'pet' | 'contract' | 'subscription' | 'insurance' | 'document' | 'device' | 'other';

export interface GeoPoint {
  latitude: number;
  longitude: number;
  accuracyM?: number;
}

export interface PersonLocationContext {
  id?: string;
  contextType: LocationContextType;
  source: 'gps' | 'saved_place' | 'manual' | 'derived';
  placeId?: string;
  administrativeAreaId?: string;
  point?: GeoPoint;
  validFrom: string;
  validUntil?: string;
  updatedAt: string;
}

export interface RelationshipEdge {
  id: string;
  targetKind: 'person' | 'organization' | 'business' | 'group' | 'administrative_area';
  targetId: string;
  relationType: string;
  status: 'requested' | 'active' | 'paused' | 'ended' | 'rejected';
  verification: 'self_declared' | 'counterpart_approved' | 'official_verified';
}

export interface LifeObjectRef {
  id: string;
  objectType: LifeObjectType;
  title: string;
  status: 'active' | 'inactive' | 'disposed' | 'ended';
}

export interface PersonContext {
  personId: string;
  locale: string;
  timezone: string;
  locations: PersonLocationContext[];
  relationships: RelationshipEdge[];
  lifeObjects: LifeObjectRef[];
}

export interface PaltaEventEnvelope {
  id: string;
  eventType: string;
  producerDomain: string;
  subjectKind?: string;
  subjectId?: string;
  placeId?: string;
  administrativeAreaId?: string;
  occurredAt: string;
  effectiveFrom?: string;
  expiresAt?: string;
  urgency: 'low' | 'normal' | 'attention' | 'urgent' | 'critical';
  privacyClass: PrivacyClass;
  visibilityScope: string;
  sourceKind?: string;
  sourceRef?: string;
  payloadVersion: number;
  truthState?: EventTruthState;
  confirmationSource?: string;
}

export interface CareItem {
  id: string;
  careKind: CareKind;
  domain: string;
  title: string;
  description?: string;
  relationshipId?: string;
  lifeObjectId?: string;
  placeId?: string;
  administrativeAreaId?: string;
  sourceEventId?: string;
  sourceKind: 'user' | 'rule' | 'domain' | 'external_calendar' | 'external_system' | 'derived';
  confidence: 'candidate' | 'likely' | 'confirmed' | 'verified';
  startsAt?: string;
  dueAt?: string;
  expiresAt?: string;
  recurrenceRule?: string;
  status: 'candidate' | 'active' | 'due' | 'snoozed' | 'handled' | 'expired' | 'dismissed';
  actionability: 'unknown' | 'informational' | 'actionable' | 'externally_actionable';
}

export interface NeedCandidate {
  id: string;
  eventId?: string;
  careItemId?: string;
  domain: string;
  needType: string;
  title: string;
  reason?: string;
  priorityScore: number;
  whyShown?: Record<string, unknown>;
  dueAt?: string;
  expiresAt?: string;
}

export interface DeliveryProjection {
  id: string;
  channel: DeliveryChannel;
  title: string;
  body?: string;
  actionUri?: string;
  rankScore?: number;
  expiresAt?: string;
  eventId?: string;
  needId?: string;
}

export interface ApiErrorBody {
  ok: false;
  error: { code: string; message: string; requestId: string };
}

export interface ApiSuccess<T> {
  ok: true;
  data: T;
  requestId: string;
}

export type ApiEnvelope<T> = ApiSuccess<T> | ApiErrorBody;

export interface SessionUser {
  id: string;
  email?: string;
  displayName?: string;
}

export interface BootstrapPayload {
  user: SessionUser;
  context: PersonContext;
  unreadNotificationCount: number;
  featureFlags: Record<string, boolean>;
}

export interface HomeCard extends DeliveryProjection {
  channel: 'home';
}

export type AssuranceRiskTier = 'open' | 'account' | 'interaction' | 'qualified' | 'regulated';
export type AssuranceVerificationStatus = 'pending' | 'verified' | 'failed' | 'expired' | 'revoked';

export interface VerificationAssertion {
  id: string;
  subjectKind: 'person' | 'business' | 'organization';
  subjectRef: string;
  assertionType: string;
  status: AssuranceVerificationStatus;
  providerKind: 'palta_account' | 'official_registry' | 'regulated_provider' | 'trusted_domain_adapter' | 'manual_review';
  providerRef?: string;
  verifiedAt?: string;
  expiresAt?: string;
}

export interface ActionAssurancePolicy {
  actionKind: string;
  riskTier: AssuranceRiskTier;
  requiredAssertions: string[];
  verificationTiming: 'none' | 'at_action' | 'before_activation';
}

// Listing / local platform core: reusable publication and distribution semantics.
export type ListingVertical =
  | 'marketplace'
  | 'auto'
  | 'real_estate'
  | 'jobs'
  | 'business'
  | 'local_activity'
  | 'local_alert';

export type ListingActorType = 'individual' | 'business' | 'professional';
export type ListingStatus = 'draft' | 'active' | 'paused' | 'completed' | 'expired' | 'removed';
export type ListingAudienceScope = 'nearby' | 'neighborhood' | 'comuna' | 'region' | 'country' | 'custom';

export interface CanonicalListingRef {
  id: string;
  vertical: ListingVertical;
  actorType: ListingActorType;
  actorRef: string;
  status: ListingStatus;
  placeId?: string;
  administrativeAreaId?: string;
  audienceScope: ListingAudienceScope;
  createdAt: string;
  updatedAt: string;
}

export type RealEstateIntent = 'venta' | 'arriendo';
export type ArriendoMode = 'long_term' | 'temporary' | 'vacational';
export type PropertyType = 'house' | 'apartment' | 'cabin' | 'room' | 'commercial' | 'land' | 'other';

export interface RealEstateListingFacet {
  intent: RealEstateIntent;
  arriendoMode?: ArriendoMode;
  propertyType: PropertyType;
}

export type DistributionChannelKind =
  | 'palta'
  | 'share_link'
  | 'business_site'
  | 'external_marketplace'
  | 'partner_feed';

export interface ListingDistributionBinding {
  id: string;
  listingId: string;
  channelKind: DistributionChannelKind;
  channelRef?: string;
  externalRef?: string;
  syncMode: 'manual' | 'push' | 'pull' | 'bidirectional';
  status: 'pending' | 'active' | 'error' | 'disconnected';
  lastSyncedAt?: string;
}

export type PromotionObjectKind = 'listing' | 'business' | 'product' | 'coupon' | 'event';

export interface PromotionCampaignRef {
  id: string;
  advertiserRef: string;
  promotedObjectKind: PromotionObjectKind;
  promotedObjectRef: string;
  placement: string;
  targetAreaRef?: string;
  startsAt?: string;
  endsAt?: string;
  budgetMinor?: number;
  currency?: string;
  status: 'draft' | 'scheduled' | 'active' | 'paused' | 'ended';
}

export interface ListingPolicyDecision {
  canPublish: boolean;
  requiresProfessionalMode: boolean;
  freeQuotaRemaining?: number;
  reasonCodes: string[];
}

// Privacy / operator / safety foundations.
export type DataRealm = 'public' | 'work' | 'private' | 'sensitive' | 'analytics';
export type AccessActor = 'person' | 'business_member' | 'operator' | 'operator_ai' | 'personal_ai' | 'service';
export type AccessDecision = 'allow' | 'deny' | 'review';
export type ModerationDecision = 'publish' | 'limit' | 'hold' | 'request_edit' | 'remove' | 'restrict_account' | 'escalate';
export type SafetyRiskKind = 'spam' | 'fraud' | 'impersonation' | 'harassment' | 'threat' | 'privacy_exposure' | 'minor_safety' | 'illegal_goods_services' | 'dangerous_service' | 'sexual_content' | 'copyright' | 'false_business' | 'review_manipulation';

export interface WorkContextRef {
  id: string;
  kind: 'business_onboarding' | 'business_support' | 'palta_support' | 'moderation_case' | 'legal_case';
  subjectRef: string;
  purpose: string;
  status: 'open' | 'waiting' | 'resolved' | 'closed';
}

export interface AccessRequest {
  actor: AccessActor;
  actorRef: string;
  realm: DataRealm;
  resourceKind: string;
  resourceRef?: string;
  purpose: string;
  workContextId?: string;
}

export interface AccessResult {
  decision: AccessDecision;
  reasonCode: string;
  maximumDetail: 'none' | 'metadata' | 'summary' | 'specific_item';
}

export interface ModerationCaseRef {
  id: string;
  contentRef: string;
  risks: SafetyRiskKind[];
  decision: ModerationDecision;
  requiresHumanReview: boolean;
}

export { authorizeAccess } from './security';
export type { AuthorizationFacts } from './security';
