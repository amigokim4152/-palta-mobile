# Care Engine Domain Validation — 2026-09-14

Status: design-contract validation passed; production/runtime validation not yet complete.

## Scope

Stress-tested the Care model against five Palta domains in addition to the existing kernel scenarios:

1. Real Estate
2. Auto
3. Education / school-parent context
4. Public benefits / policy programs
5. Business-owner context

## Design gaps found and corrected

### 1. Responsible person vs subject person
A Care item originally only had `person_id`. That was insufficient for cases such as a parent being reminded about a child's school requirement or a user caring for a parent's appointment.

Correction: added optional `subject_person_id`. `person_id` remains the person whose Palta experience surfaces the item.

### 2. Cross-domain context reference
Care needs to point at domain-owned objects such as Business, Property or Policy Program without making Care their canonical owner.

Correction: added `context_kind` + `context_ref` as lightweight cross-domain references while preserving the specialist domain as source of truth.

### 3. Rule/source provenance
Entitlements and obligations generated from Chilean rules must be reproducible and auditable.

Correction: added `source_version`, `source_checked_at`, `source_valid_from`, `source_valid_until`.

### 4. Idempotent generation
Scheduled collectors and rules must not create duplicate care items on retries.

Correction: added `dedupe_key` and a partial unique index by `(person_id, dedupe_key)`.

### 5. Chile timezone / DST safety
Recurring local obligations must not drift when Chile changes UTC offset.

Correction: added `recurrence_timezone`; schedule references also carry timezone.

## Domain results

### Real Estate — PASS
Care can invoke property comparison/visit actions. Browsing or a planned visit does not modify durable home context. Only a confirmed move should do that.

### Auto — PASS
A vehicle obligation can belong to the person responsible for maintenance/payment even when legal ownership belongs to someone else.

### School — PASS after correction
Parent and child identities stay separate. A parent-facing Care item can explicitly reference the child as `subject_person_id`.

### Public benefits — PASS after correction
Entitlement candidates can remain candidates while carrying versioned provenance, validity and a dedupe key. The model does not claim eligibility as fact merely because a rule matched.

### Business — PASS after correction
A person's Care surface can reference a Business context and route into Business actions without turning Care into a business-management back office.

## Automated checks

- Kernel contract validator: PASS (7 contract groups)
- Deterministic kernel/domain simulations: PASS (14/14)
- Data validator: PASS (`0 canonical records`, expected at foundation stage)
- Python syntax compile: PASS

## Not yet proven

The following remain unverified and must not be described as production-ready:

- SQL migrations against a real PostgreSQL/PostGIS instance
- React Native / Expo TypeScript build and device runtime
- actual Google/Apple calendar adapters
- actual Chile policy/benefit rule ingestion into Care
- production API persistence and authentication
- live Business / Real Estate / Auto domain adapter integration

## Decision

The Care model is coherent enough to continue as a shared platform contract. Do not freeze it as production schema until the PostgreSQL migration test and one real end-to-end Chile data flow pass.

## Family/minor boundary stress test

Result: PASS after hardening.

Findings:
- family/household context must not imply access;
- ordinary Care personalization must not require family/custody documents;
- minors default to private and relationship labels never auto-grant visibility;
- explicit purpose-limited sharing is represented separately from relationship context;
- future official-government authority checks belong behind an authorized adapter, not in the ordinary Care kernel;
- LifeObject legal ownership cannot be represented by a single `person_id`; person/object roles are modeled separately through `life_object_relation`.
