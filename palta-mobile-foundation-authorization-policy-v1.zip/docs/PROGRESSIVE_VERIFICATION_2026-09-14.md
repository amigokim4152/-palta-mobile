# Progressive Verification — validated direction

Palta stays open for low-risk discovery and asks for verification only when an action creates meaningful responsibility.

Boundary:

`open discovery → account features → interaction → qualified commercial action → regulated money movement`

Rules:
- Relationship, household membership, surname, AI inference, or proximity never grant authority.
- Verification is purpose-specific capability gating, not reputation/ranking.
- Business claim/POS activation may require business authority/tax-status assertions.
- Money movement/settlement should defer regulated authentication/KYC to the relevant regulated provider rather than making Palta the identity-document warehouse.
- Store the minimum verification assertion/status/provenance needed; avoid copying identity evidence unless legally/operationally necessary.
- Official Chile adapters remain replaceable; the Kernel stores assertions, not SII/CMF-specific workflow logic.

Chile validation notes (2026-09-14):
- SII Resolution 79/2025 provides individual and authorized automated verification of Inicio de Actividades for covered operators/platforms.
- CMF customer-authentication rules require reinforced authentication in specified electronic-payment contexts; the regulated provider remains responsible for its regulated flow.

This document is architectural guidance, not legal advice. Exact Palta obligations depend on the commercial/payment model eventually chosen.
