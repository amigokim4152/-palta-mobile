# Palta core build order

This is the implementation order for the zero-base mobile platform. Map/GTFS and Municipalidad data are parallel inputs, not blockers.

## 1. Foundation — current
- Mobile shell (Expo/React Native)
- API boundary (Cloudflare Workers)
- Standard PostgreSQL migrations
- Provider-neutral auth boundary
- User/location/relationship schema
- Event/notification outbox
- AI gateway boundary
- Privacy/audit foundation

## 2. Connect real infrastructure
- Provision low-cost standard PostgreSQL
- Run SQL migrations
- Connect Worker to PostgreSQL (prefer pooled/edge-safe connection)
- Configure R2 bindings
- Configure real authentication provider and secure token verification
- Configure mobile secure token storage

## 3. First user journey
1. Install/open app
2. Sign in
3. Ask for location once, with clear reason
4. Resolve GPS to Palta location context
5. Create private user context
6. Load personal home bootstrap
7. Register push-capable device

The app must not show repeated location setup controls across screens. Location is a shared core state.

## 4. Personal home
Home is a life inbox, not a portal grid. Cards are generated from:
- user context
- local graph
- relationships
- events
- rules
- AI only where it adds value

## 5. Shared platform services
- Search/discovery
- Notifications
- Messaging
- Trust/safety
- Media/files
- AI gateway
- Organization/group access

## 6. Attach parallel data tracks
- Santiago map/GTFS
- Municipalidad/local graph

They enter through stable interfaces and must not dictate the app architecture.

## Non-negotiable UX rules
- Mobile app first.
- One source of truth for current/saved location.
- No repeated GPS/location setup UI.
- Progressive disclosure: simple first surface, details on demand.
- No fake data in production paths.
- No provider keys in the mobile app.
- No auth tokens in insecure storage.
