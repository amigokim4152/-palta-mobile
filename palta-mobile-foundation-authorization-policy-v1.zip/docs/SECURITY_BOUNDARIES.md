# Security and privacy boundaries

## Data classes
1. Public/local: municipality, events, facilities, public business data.
2. Account: identity, preferences, device registrations.
3. Personal: saved places, relationships, memberships, household context.
4. Sensitive: health and other specially protected domain data.
5. Transactional: bookings, quotes, POS/order/payment-related records.

## Rules
- Personal home is private by default.
- Admin/operator tooling must not expose private personal context by default.
- AI receives the minimum context required for the specific task.
- Secrets and provider keys live server-side only.
- Access checks happen at API/domain boundaries, not only in UI.
- Audit sensitive/admin actions without logging sensitive payloads.
- Sensitive domains may be separated physically later; schema/API boundaries must make that possible from day one.
