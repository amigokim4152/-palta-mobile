# Palta Commercial Industry Matrix — Chile Validation

Status: architecture validation; not production scope freeze
Date: 2026-09-14

## Conclusion

The existing rule remains valid: one canonical Business + one Commercial Core + optional capabilities. Industry support should be expressed as capability combinations, not separate POS products.

Chile validation adds four capabilities that should exist before inventory schema is frozen:

- `lot_expiry` — lot/batch identity, manufacture/expiry dates, FEFO, quarantine/recall traceability.
- `production_batch` — input-to-output batch genealogy for businesses that transform or manufacture goods.
- `recipe_bom` — recipe/bill-of-material consumption and yield; useful for restaurants, bakeries, light manufacturing and installation kits.
- `storage_condition` — cold/frozen/ambient or other required storage condition and location state. This records operational requirements; it is not a certification system.

These are optional. A kiosk or small service business must never see them unless enabled.

## Representative Chile industry coverage

| Industry profile | Base capabilities | Optional / advanced capabilities |
|---|---|---|
| Kiosk / small neighborhood shop | retail, tax_document, payment_adapter | inventory, crm_loyalty |
| Minimarket / convenience | retail, inventory, tax_document | multi_location, crm_loyalty, delivery |
| Clothing retail | retail, inventory | multi_location, crm_loyalty |
| Clothing wholesale | wholesale, inventory, multi_location | crm_loyalty, business_messaging |
| Imported food wholesale | wholesale, inventory, lot_expiry, storage_condition, tax_document | multi_location, delivery |
| Fresh/chilled food distributor | wholesale, inventory, lot_expiry, storage_condition | multi_location, delivery |
| Bakery / pastry production | retail, inventory, production_batch, recipe_bom, lot_expiry | booking, delivery |
| Cafe | retail, restaurant | kitchen_kds, recipe_bom, delivery |
| Full-service restaurant | restaurant, kitchen_kds, inventory, recipe_bom | delivery, multi_location, booking |
| Fast food / takeaway | restaurant, kitchen_kds, retail | delivery, recipe_bom |
| Catering / banqueting | quote, booking, production_batch, delivery | inventory, staff_operations |
| Beauty / hair salon | booking, retail, staff_operations | crm_loyalty, inventory |
| Massage / wellness | booking, staff_operations | crm_loyalty, retail |
| Gym / classes | booking, staff_operations | crm_loyalty, retail |
| Academy / tutoring | booking, staff_operations | crm_loyalty, business_messaging |
| Auto workshop | quote, booking, field_service, inventory | crm_loyalty, multi_location |
| Tire / auto-parts shop | retail, inventory, field_service | multi_location, quote |
| Phone/electronics sales + repair | retail, inventory, quote, field_service | crm_loyalty |
| HVAC / installation company | quote, field_service, booking, inventory | multi_location, staff_operations |
| Window film distributor/installer | wholesale, quote, field_service, inventory | multi_location, booking |
| Hardware / construction materials | retail, wholesale, inventory | delivery, multi_location |
| Furniture / home goods | retail, inventory, delivery | quote, multi_location |
| Pet shop | retail, inventory | lot_expiry, crm_loyalty |
| Veterinary clinic (commercial surface only) | booking, retail, inventory | lot_expiry; clinical records stay outside Commercial Core |
| Optician retail surface | retail, inventory, booking | field_service; health/clinical data stays outside Commercial Core |
| Hotel / lodging commercial surface | booking, payment_adapter, tax_document | restaurant, crm_loyalty; full property-management semantics need a separate capability if pursued |
| Courier / local delivery operator | delivery, staff_operations | multi_location, business_messaging |
| Warehouse / distributor | wholesale, inventory, multi_location | delivery, lot_expiry |
| Small manufacturer | inventory, production_batch, recipe_bom, wholesale | multi_location, lot_expiry where relevant |
| Multi-branch chain | retail or restaurant, multi_location, staff_operations, reporting | industry-specific capabilities |

## Boundary findings

1. **No industry-specific monolith.** Restaurant, wholesale, salon, field service, food distribution and retail all reuse the same Business and Commercial Core.
2. **Expiry is inventory semantics, not a food-only POS.** Food is the strongest current use case, but lot/expiry can also serve cosmetics, pet products and other batch-controlled goods where applicable.
3. **Clinical data stays out of Commercial Core.** A veterinary clinic, optical shop, dental office or medical practice may use booking/POS/inventory, but health records require a separate regulated domain.
4. **Hospitality may outgrow Booking.** Basic lodging can use Booking, but room-night inventory, housekeeping and property-management semantics should become a dedicated capability only when actually pursued.
5. **Manufacturing needs genealogy.** A bakery or light manufacturer may need to connect ingredient/input lots to output batches. This cannot be reconstructed safely from simple stock totals.
6. **Unit-of-measure must be core inventory metadata.** Wholesale and construction businesses may sell each, box, roll, meter, kilogram, pallet or case. UOM conversion belongs with Catalog/Inventory semantics rather than one industry module.
7. **Customer credit terms are wholesale semantics, not banking.** Palta can record agreed invoice terms and receivable status, but lending/credit underwriting is outside current scope.
8. **SII remains an adapter boundary.** Palta can be a market/self-developed invoicing solution and support DTE flows, but certification concerns the electronic tax documents emitted, not a blanket certification of the whole POS.

## Chile-specific validation notes

- SII publishes economic activity codes across retail, wholesale, restaurants, accommodation, transport, professional and service categories, so a narrow retail-only POS would not match the breadth of Chilean businesses.
- SII explicitly supports own/market electronic invoicing software and a certification/test environment. The tax-document adapter must therefore be replaceable and versioned.
- For imported food, the Chilean sanitary regulation requires the importer to retain records including sanitary/customs background, lot or manufacture date, expiry, country of origin, product type, brand and foreign supplier, and imported foods must satisfy Chilean labeling requirements. This justifies lot/expiry/provenance fields before inventory freeze.

## Freeze rule

Do not freeze the production inventory schema until it can represent:

- variant + unit of measure,
- branch/warehouse location,
- lot/batch where enabled,
- manufacture/expiry where enabled,
- reservation/on-hand movement ledger,
- quarantine/recall disposition where enabled,
- input/output batch genealogy where enabled.

Businesses without those capabilities remain on the simple path.
