# Palta API Registry + Cost Guard V1

Status: shared infrastructure contract
Date: 2026-09-14

Purpose: every external source/partner is registered once and reused by all Palta domains. No vertical owns a duplicate provider integration.

## Registry record
Each integration records: provider/integration id, category, adapter/version/environment, integration class (`data_supply` or `transaction`), authorization/contract status, secret reference only, capabilities, geographic coverage, endpoint class, quota/rate limit, unit price/currency, monthly budget, freshness/TTL, cache policy, webhook support, health/latency/error state, fallback, reconciliation policy, provenance, and allowed consumers.

Categories include municipal/government, transport, travel/booking, logistics, payment, channel commerce, weather, FX, map/geodata and future providers.

## Cost Guard
For each provider and capability measure actual calls, cache hits/misses, estimated spend, quota use and projected month-end spend.

Budget states: `normal -> warning -> guarded -> blocked_noncritical`.

Rules:
- Critical transaction commit/reconciliation is never silently replaced by stale cache.
- Near budget limits, reduce or defer noncritical refreshes first.
- Never throttle a transaction into an ambiguous result; preserve `unknown` and reconcile.
- Prefer webhook/event delivery over polling where reliable.
- Deduplicate shared reads: one weather/municipal/transport snapshot can serve many surfaces.
- Cost policy is configurable; no provider prices are hard-coded into Core.

## Freshness classes
- `static`: maps, stops, route geometry; long cache/R2/device cache.
- `slow`: municipal policy, business basics, reference content; hours/days plus change detection.
- `medium`: weather, FX, travel descriptive/indicative data; minutes/hours as source semantics require.
- `live`: ETA/vehicle position/availability; short TTL and demand-aware refresh.
- `authoritative_transaction`: booking/payment/shipment/stock commit; source recheck, no stale confirmation.

Every serving response that can become stale carries source/provenance and `observed_at`; UI may expose last-updated when material.

## Fallback
Data supply may fall back to last known canonical/serving snapshot, R2 snapshot or device cache with freshness metadata. Transaction operations fail safely or enter reconciliation when authoritative source is unavailable.

## Observability
Operator dashboard must be able to report calls/day/month, spend/provider/capability, cache-hit ratio, latency/error rate, webhook vs polling volume, fallback use, quota remaining and projected month-end cost.

## Future partner rule
Adding an official Municipalidad feed, DTPM integration, travel supplier, courier, payment provider or marketplace requires a new registry entry + adapter. Palta domain models/screens do not change merely because the provider changes.
