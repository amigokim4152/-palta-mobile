# Palta External Integration Gateway V1

Status: shared infrastructure contract
Date: 2026-09-14

One integration pattern for municipal/government data, transport, travel/booking, logistics, payments/channels and future partners.

`Provider -> Adapter -> Gateway -> Raw/Evidence or Transaction Result -> Canonical Domain -> Projections`

## Registry fields
- integration/provider id and category
- adapter/version/environment
- contract/authorization status
- credential secret reference (never raw secret in registry/export)
- capabilities/endpoints
- geographic coverage
- rate limit/quota/unit cost/budget owner
- cache/freshness class when data is cacheable
- webhook/event support
- last healthy response/error/latency
- fallback and reconciliation policy
- provenance requirements

## Two integration classes
1. Data supply: API/feed/file/web/official future feed -> raw snapshot -> change detection -> normalize/validate -> evidence -> canonical truth.
2. Transaction: quote/search -> authoritative recheck -> create/commit -> provider reference -> webhook/status -> reconciliation/settlement where applicable.

Never use stale cache to confirm booking, payment, stock, shipment creation, or other authoritative transaction truth.

## Future-provider rule
A municipality, DTPM, travel supplier, courier or other partner may later provide an official API/feed. Replace/add its adapter; do not redesign Palta domains or screens.

## Registry / cost / freshness boundary
All adapters MUST register through `API_REGISTRY_COST_GUARD_V1.md`. Provider calls bypassing the registry are non-compliant. Registry policy controls shared caching, freshness, budget guardrails, health, fallback and observability; domain modules own business meaning, not provider economics.
