# Palta Kernel v1 — Validated Design

Status: DESIGN-VALIDATED / NOT YET PRODUCTION-DEPLOYED  
Date: 2026-09-14

## 1. Validation basis

This design was checked against existing Palta assets and five cross-domain scenarios:

1. current-location change → current local information changes;
2. municipal program → eligible/relevant person Home;
3. school/WhatsApp notice → parent action;
4. business quote/service → case → user-confirmed vehicle/home history;
5. local event/performance → surfaced by current LifeArea relevance.

All five fit one shared kernel. Scenario 4 required an explicit Case/Outcome lifecycle. All scenarios require a shared Event envelope.

## 2. Kernel boundary

### Canonical truth
- `person`
- `place`
- `administrative_area`
- `relationship_edge`
- `life_object`
- domain-owned canonical records outside the Kernel
- `life_history`

### Operating state
- `person_location_context`
- `schedule_reference`
- `palta_event`
- `care_item` (`obligation` / `entitlement` / `care_need`)
- `need_candidate`
- `action_item`
- `action_case`
- `case_transition`
- `case_outcome`

### Derived delivery
- `delivery_projection` for Home / Inbox / Push / Calendar

Home, notifications and search are not source-of-truth owners.

## 3. Core flow

```text
Domain / Local Graph / External source
              ↓
          palta_event / schedule
              ↓
      person + location + relationship + life object
              ↓
            care_item
   obligation / entitlement / care_need
              ↓
         need_candidate
              ↓
        relevance decision
         ↙       ↓       ↘
      Home     Action   Suppress/store
                ↓
              Case
                ↓
             Outcome
                ↓
           Life History
```

## 4. Geographic rule

Administrative jurisdiction and daily-life relevance are separate.

- `administrative_area`: legal/official hierarchy and eligibility.
- `place`: actual place/coordinate.
- `person_place`: durable saved relationships to places, such as home/work/school.
- `person_location_context`: short-lived runtime context such as current/temporary/habitual/jurisdiction.

Do not build a permanent precise movement trail merely to provide current-area relevance.

## 5. Relationship rule

`relationship_edge` is descriptive life context: who/what is meaningfully connected to the person. It is not a legal or HR authority system. Existing Base44 membership records are migration inputs, not the new database model.

A relationship can help generate Care (for example, a recurring payment or family reminder), but the relationship itself does not prove legal status, real-world completion, or permission to expose unrelated private data.

## 6. Event rule

Domain truth remains in its owning domain. The Event envelope exists so all domains can participate in the same Relevance, Home, Notification and Action pipeline.

Examples:
- municipal program opened;
- school notice published;
- quote received;
- booking changed;
- transport disruption;
- local performance scheduled;
- service completed.


## 6A. Care rule

Care is the bridge between stored life context and what Palta should actually help with.

- `obligation`: something the person should do/pay/renew/submit;
- `entitlement`: something the person may be eligible to receive/use;
- `care_need`: something involving a person, household, life object or routine that deserves attention.

Care is deliberately lighter than case management. Palta should not invent completion or force users to check every ordinary life event. See `docs/CARE_ENGINE_V1.md`.

## 6B. Truth-state rule

A plan is not proof of completion. Shared events distinguish `planned`, `observed`, `confirmed`, `cancelled` and `unknown`. Passing a scheduled time does not automatically promote the event to `confirmed`.

## 7. Case/Outcome rule

A user action that requires an external party or multi-step execution uses `action_case`.

Example lifecycle:

`requested → accepted → scheduled → in_progress → completed_by_provider → confirmed_by_user → resolved`

Provider completion must not automatically become a confirmed private LifeHistory record when user confirmation is materially required.

## 8. Delivery rule

Home and Push are channels, not domain taxonomies.

One relevant item may be:
- Home only;
- Inbox only;
- Push + Home;
- Calendar projection;
- suppressed entirely.

The same underlying event/need is referenced rather than copied into unrelated domain notification systems.

## 9. Existing Palta reuse

Preserve and adapt rather than rebuild:
- MapLibre/PMTiles shared map contract;
- PolicyProgram and municipal/local research as Local Graph inputs;
- SourceRawItem/evidence discipline;
- Business canonical identity and specialist modules;
- Property/Real Estate domain;
- Education/School domain including WhatsApp/class intake assets;
- Mobility normalized transport identities/provider adapters;
- LifeHistory semantics;
- privacy/disclosure principles.

Do not migrate the 813 Base44 entities one-for-one.

## 10. Freeze status

The Kernel relationship directions are validated. Field-level contracts remain versioned and may be refined during migration proofs. No production infrastructure or paid service is authorized by this document.
