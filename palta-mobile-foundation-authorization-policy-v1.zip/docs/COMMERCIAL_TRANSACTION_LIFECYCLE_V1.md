# Palta Commercial Transaction Lifecycle V1

Status: validation contract, not production freeze  
Date: 2026-09-14

## Boundary

Commercial Core owns the durable transaction spine. Industry modules add operational meaning without replacing the spine.

`Business -> Location -> Catalog -> Order -> Fulfillment/Sale -> Payment result + Tax document result -> Return/Adjustment -> Audit/Reporting projection`

Payment and tax-document state are deliberately independent. A captured card transaction does not prove SII acceptance, and an accepted tax document does not prove payment settlement.

## Invariants

1. Client retries must not create a second order.
2. Stock decrement is represented by an immutable inventory movement and is applied once.
3. Current inventory quantity is a projection; the movement ledger is the audit source.
4. Payment-provider retries are idempotent and provider state can be `unknown` after a network ambiguity.
5. `unknown` payment state must never be silently treated as paid/completed; reconciliation is required.
6. Tax-document retries use a separate idempotency key and adapter version.
7. Returns reference original order lines; restock only when disposition allows it.
8. Cash register close records expected, counted and variance values rather than rewriting sales.
9. Staff permissions are scoped to business/location/role and do not become general Person authority.
10. Restaurant, KDS, wholesale, booking, quote and field-service details remain optional capabilities.

## Next real-runtime gates

This repository still needs an actual PostgreSQL/PostGIS runtime before production freeze. Required gates:

- execute migrations 001-009 from empty database and from previous-version database;
- rollback/recovery drill;
- concurrent order/idempotency test on unique keys;
- inventory row-lock/atomicity test;
- 500 / 1,000 / 5,000 line real inserts with latency and transaction-size measurement;
- two or more POS terminals racing for the same stock;
- connection loss after COMMIT but before client acknowledgement;
- payment `unknown -> reconciled` test;
- tax-document reject/retry/reconciliation test;
- register close/reopen and variance audit test.

Until these run on PostgreSQL, deterministic simulations prove architecture contracts only, not production capacity.
