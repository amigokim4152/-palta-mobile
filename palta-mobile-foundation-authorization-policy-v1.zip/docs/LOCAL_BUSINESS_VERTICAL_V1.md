# Palta Local Business Vertical V1

Status: validation candidate, 2026-09-14

## Purpose
Local Business is a supply and participation layer for Palta Local. A free profile must be genuinely useful. Paid capability adds operating value; it must not repair deliberately degraded free functionality.

## 1. Discovery modes
A Business may expose one or both:
- `storefront`: discover by physical location, distance, open state and local relevance.
- `service_area`: discover by where the provider actually works, not by home/office address.

Discovery may combine proximity, service-area coverage, specialty/fit, current availability and result density. Sparse areas may widen toward adjacent functional life areas; administrative jurisdiction remains separate.

## 2. Free useful profile
Free profile may support: identity, category, photos, description, physical location when applicable, service area, normal/special/seasonal hours, contact/WhatsApp/Palta contact, posts/news, favorites, basic coupon, attributes, community photos/reviews/Q&A, corrections and directions.

Paid capabilities add value such as structured menu/catalog/price list, booking/quote operations, order tools, advanced promotion, analytics/automation, POS/inventory/CRM and channel integrations.

## 3. Business attributes
Attributes are typed and category-aware, not free-form marketing claims. Examples:
- parking: own_free, own_paid, building_shared, nearby_paid, street_possible, difficult, unknown;
- nearby parking place reference + walking distance when known;
- pet policy;
- accessibility;
- terrace/outdoor seating;
- child/family suitability where factual;
- delivery/takeaway/reservation;
- accepted contact/action modes.

## 4. Live operating state
Normal hours are not enough. Support special hours, seasonal hours, temporary closure, early close, moved/closed reports and last-verified provenance. User reports never silently overwrite canonical business facts.

## 5. Community contribution
Separate:
- official business content controlled by authorized business operator;
- community photos/reviews/Q&A/comments controlled by their authors and moderation policy;
- Palta-derived recommendation signals.
Business operators cannot edit/delete unfavorable community content; they may reply or report it.

## 6. Quote routing
Common flow: need + media + approximate location + timing/constraints -> eligible providers -> proposals -> comparison -> user selection -> contact/booking. Contact details stay limited until the user chooses or disclosure is necessary. Routing uses service area + specialty + availability, not office distance alone. Quote is reusable across auto repair, gardening, plumbing, electrical work, home services and domain-specific request variants.

## 7. Recommendation independence
Natural discovery/recommendation, paid product capability and advertising are separate systems.
- payment never buys organic rank, review score, recommendation badge or "best" claim;
- sponsored placement is clearly labeled `Patrocinado`/`Publicidad`;
- unverified superlatives/rank claims such as "Palta #1" cannot be self-assigned in ad creative;
- future Palta badges are non-purchasable, evidence-based, periodically re-evaluated and launched only when evidence is sufficient.

## 8. Integrity and moderation
Community content needs append-only/auditable history for edits, reports and moderation actions. Verified-use evidence may strengthen a review but unverified experience is not automatically prohibited. Critical distinction: legitimate negative experience is not abuse. Detect spam, coordinated manipulation, impersonation, harassment, privacy exposure and fraudulent review patterns without creating a universal person score.

## 9. Multilingual
Store canonical source text and provenance. Presentation may translate Spanish, Chinese, Korean, English and other supported languages. Translation never replaces the source text or silently changes factual business data.

## 10. Engagement loop
Return useful aggregate signals to the operator: profile views, directions, favorites, questions, quote requests, contact actions and community contributions. Avoid exposing private user identity merely for analytics.

`useful free profile -> local discovery -> real customer response -> operator updates profile -> richer local data -> more users -> optional paid operating tools`

## 11. Local/Home/Map integration
Business is not isolated from Palta Local. Event cards can open Map; Map can expose nearby businesses; business pages can lead to directions, favorites, coupons, quote/booking. Current/trip context may change relevance without replacing the user's home-life context.

## 12. Non-goals
- no paid organic ranking;
- no fake physical address requirement for mobile professionals;
- no automatic claim that scheduled/open means actually observed open without appropriate evidence;
- no forced POS adoption;
- no separate duplicate business identity per vertical;
- no operator-controlled deletion of legitimate criticism.
