# Care Generation Safety Validation — 2026-09-14

Status: DESIGN VALIDATED / NOT PRODUCTION DEPLOYED

## Decision

Care creation must preserve **why Palta believes the item exists**. `source_kind` alone is insufficient.

Every generated Care item now distinguishes:
- `generation_mode`: declared / rule_derived / source_declared / extracted / proposed;
- `evidence_state`: unverified / source_backed / user_asserted / system_observed / authoritative;
- `review_state`: not_required / required / approved / rejected;
- source locator/version and rule id/version where applicable.

## Safety boundary

1. Explicit user input may create personal Care without demanding documentary proof.
2. Versioned deterministic rules may create candidates when their source and rule version are traceable.
3. A trusted source may declare an item only within that source's actual scope.
4. AI extraction is a proposal/extraction aid. It cannot silently turn ambiguous text into a verified obligation, entitlement, family fact, or completed real-world outcome.
5. Unsupported inference does not create an active Care item.
6. Calendar events remain planned unless separately observed/confirmed.
7. Relationship context never creates access permission.
8. Administrative Care currently guides and links to official action; Palta does not file on the user's behalf.

## Tested failure cases

The deterministic validator covers user-declared care, versioned rule-derived benefits, AI-extracted obligations, unsupported inference, trusted source declarations, calendar completion, relationship/access separation, and the current government-action boundary.

These fixtures validate architecture only; they are not claims about real Chilean programs or people.
