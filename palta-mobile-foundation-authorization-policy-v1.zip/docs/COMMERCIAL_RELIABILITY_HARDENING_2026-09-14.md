# Commercial/POS Reliability Hardening — 2026-09-14

## Why this exists

A POS cannot treat timeout as failure or retry every unknown result blindly. The dangerous case is not only a slow request; it is **success with lost acknowledgement**. An order, stock movement, payment, or tax submission may already have succeeded even when the device did not receive the response.

## Added contracts

1. `commercial_command_receipt`
   - Stable idempotency identity at the command boundary.
   - Repeating the same command returns the original result.
   - Reusing the same command ID with changed payload is an error.

2. `commercial_outbox_event`
   - Order/inventory state and the event that triggers follow-up work are committed together.
   - Notifications, SII jobs, integrations and callbacks happen after commit and may retry safely.

3. `inventory_reservation`
   - Optional stock hold for concurrent channels such as app/web/POS.
   - Prevents two channels from promising the same remaining stock.

4. `commercial_reconciliation_issue`
   - Ambiguous outcomes are first-class states, not guessed outcomes.
   - Includes DB commit unknown, payment unknown, tax-document unknown, stock/cash/transfer mismatches and sync conflicts.

5. Tenant consistency constraints
   - Critical inventory rows must reference location/item records belonging to the same business.

## Fixed rules

- Timeout ≠ failure.
- Retry ≠ recreate.
- Acknowledgement loss must return the same prior result through idempotency.
- Money/tax/stock ambiguity goes to reconciliation; never infer success or failure from silence.
- External side effects must not be executed inside the database transaction.
- Inventory current position is a projection; immutable movement history remains the audit source.
- `last-write-wins` is forbidden for financial and stock operations.

## Validation status

Deterministic reliability contract simulation: 10/10 PASS.

Still not proven:
- real PostgreSQL migration execution,
- row-lock behavior under concurrent transactions,
- actual process crash between COMMIT and client response,
- actual provider/SII timeout reconciliation,
- measured 500/1,000/5,000 line performance on production-like hardware.

These remain hard release gates for POS V1.
