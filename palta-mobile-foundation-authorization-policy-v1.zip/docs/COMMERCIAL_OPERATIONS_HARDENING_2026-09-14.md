# Commercial/POS Operations Hardening — 2026-09-14

## Scope
Operational controls that become necessary once Palta POS moves beyond a single-owner/single-register shop.
These controls stay in Commercial/POS. They do not enlarge Shared Core.

## Decisions

### 1. Staff identity is not staff authorization
Shared Verification may establish who a person/business is. Commercial authorization separately decides whether that person may sell, refund, adjust stock, close caja, approve transfers, etc.
Permissions may be business-wide or location-scoped.

### 2. Caja is an auditable ledger
Opening cash + immutable cash movements = expected cash.
Closing count records the observed amount and variance. A discrepancy never rewrites historical sales or payment records.

### 3. Multi-location transfer is a workflow
A transfer has source, destination and lifecycle. Shipping creates an idempotent `transfer_out`; receiving creates a separate idempotent `transfer_in`. Receiving cannot happen before shipping.

### 4. Exchange = return + replacement order
Do not edit the original sale into a different product. This preserves stock, price, tax, payment and audit history, including any price difference.

### 5. Offline sync cannot silently overwrite stock/financial state
Every device operation has a stable client operation ID. Retry returns the existing receipt. Stale base versions produce an explicit conflict. Last-write-wins is forbidden for stock and financial operations.

### 6. Real database proof still pending
The deterministic suite checks contracts only. Production readiness still requires PostgreSQL migration execution and concurrent transaction tests using row locking / conditional updates, reconnect after COMMIT, and 5,000-line measurements.

## Validation result
- Commercial operations deterministic scenarios: 10/10 PASS.
- Full contract gate, including prior Kernel/Care/Commercial suites: PASS.
- `@palta/core` TypeScript typecheck: PASS.
- Python compile: PASS.
- Canonical data validator: PASS (0 canonical records; no fake data added).
- Full mobile/API TypeScript typecheck was not executable in this container because Expo/React/Cloudflare workspace dependencies are not installed. This is an environment/dependency gap, not counted as a pass.
