# Palta Logistics Module V1

Status: shared commercial capability contract; Core V1 remains frozen
Date: 2026-09-14

## Boundary
Logistics is a reusable capability above Commercial Core. It does not own Order, Customer, Inventory, Payment, Person, or Business truth. It consumes purpose-bound references and returns shipment state.

## Provider-neutral lifecycle
`quote -> select service -> create shipment -> pickup/dropoff -> label/dispatch -> tracking events -> delivered`
Optional branches: `cancel`, `return`, `proof_of_delivery`, `reconcile_unknown`.

## Delivery modes
- `parcel`: carrier/network shipment (national/regional)
- `last_mile`: on-demand/same-day courier
- `pickup_point`: dropoff/pickup network
- `merchant_delivery`: business-operated delivery, no external provider required

## Minimal shipment input
Use data Palta already has. Never ask staff/customer to retype known data.
- origin place/contact reference
- destination place/contact reference
- order/fulfillment reference
- package count
- weight/dimensions only when provider/service requires them
- delivery notes only when needed

Physical weight is observed after packing unless a trusted package/product profile exists. Never fabricate it.

## Standard operations
- `getQuotes(request)`
- `createShipment(request)`
- `requestPickup(shipment)`
- `getLabel(shipment)`
- `cancelShipment(shipment)`
- `createReturn(shipment)`
- `getTracking(shipment)`
- `ingestProviderEvent(event)`
- `reconcile(shipment)`

Each provider advertises capabilities. Unsupported operations return `unsupported`; vertical/POS code must not contain provider-specific branches.

## Canonical shipment states
`draft | quoted | booked | awaiting_pickup | picked_up | in_transit | out_for_delivery | delivered | cancelled | return_requested | returning | returned | exception | unknown`
Provider-specific statuses are mapped by adapters; raw provider status is preserved for provenance/debugging.

## Adapter rule
Examples: PedidosYa Envíos, Moova, Shipit, Chilexpress, Starken, Blue Express, future providers. These names never become canonical domain types.

Adapter responsibilities:
- authentication/contract credentials
- provider request/response mapping
- service/cost/ETA normalization
- shipment creation
- labels where supported
- webhook/event verification and mapping
- cancellation/return where supported
- rate-limit/error mapping
- provider reconciliation

## Reliability
- idempotency key required for shipment creation/cancellation/return
- timeout is `unknown`, not failure
- retry must not create duplicate shipment
- provider reference preserved
- webhook preferred to polling for state changes
- signed/verified webhook where provider supports it
- duplicate/out-of-order events tolerated
- final financial/provider discrepancies go to reconciliation

## Commercial Core integration
`Order -> Fulfillment -> Logistics Shipment`
A fulfillment may have zero, one, or multiple shipments. Shipment does not mutate order/payment truth directly; accepted events produce domain events that Commercial Core handles through its own rules.

Returns connect to existing return/exchange semantics rather than creating a second return system.

## POS/UI contract
UI asks only for missing facts. Typical flow:
`order ready -> delivery -> quotes -> choose -> create -> print label/request courier -> track`.
Device/label printing belongs to Native/Device Adapter, not Logistics provider logic.

## Shared infrastructure
All provider adapters register in the External Integration Registry with:
provider, environment, contract status, credential reference, supported capabilities, coverage, rate limit, quota/cost model, webhook support, freshness rules, health, last success, fallback/reconciliation policy.

## Non-goals V1
- no real provider credentials
- no fake shipment creation
- no hard-coded provider pricing
- no assumption that every provider supports Chile nationwide
- no assumption that every shipment needs weight/dimensions
- no Core V1 reopening
