# Phase 1 — prove the architecture before expansion

## Gate A — foundation
- [x] Separate mobile app skeleton
- [x] Separate Worker API skeleton
- [x] Provider-independent core entity schema
- [x] Data validation/build CLI skeleton
- [x] PostgreSQL baseline migration
- [x] CI skeleton
- [ ] Dependency install and typecheck on a machine with package registry access
- [ ] Real iPhone/Android launch

## Gate B — one real Palta data path
- [ ] Receive one existing real Palta municipal/local dataset
- [ ] Preserve raw source
- [ ] Normalize to canonical records
- [ ] Validate provenance/status/duplicates
- [ ] Build serving snapshot
- [ ] Load to test PostgreSQL and/or R2
- [ ] Read through Worker API
- [ ] Show it in the mobile app

## Gate C — map/transit proof
- [ ] Connect existing Santiago PMTiles through proper R2/CDN Range support
- [ ] Render with MapLibre in the mobile app
- [ ] Load one existing GTFS snapshot
- [ ] Confirm mobile pan/zoom/location/route data path

Only after A+B+C pass do we treat the architecture as proven enough to expand verticals.
