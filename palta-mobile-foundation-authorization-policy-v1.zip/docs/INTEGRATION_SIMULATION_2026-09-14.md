# Palta Kernel v1 — 통합 시뮬레이션 검증

검증일: 2026-09-14

## 결론

기존 Palta 자산을 대조해 확정한 Kernel 계약을 서로 성격이 다른 5개 생활 시나리오에 적용했다.

- 기존 Kernel 구조 검증: `PASS`
- 통합 시나리오: **5/5 PASS**
- 테스트 fixture는 실제 공공정보가 아니다. 목적은 **공통 Core 계약이 서로 다른 Domain을 처리할 수 있는지** 검증하는 것이다.

## 검증한 흐름

| 시나리오 | 결과 | 확인한 핵심 계약 |
|---|---|---|
| 현재 위치 전환 | PASS | 현재 생활권은 바뀌어도 거주/행정 자격은 유지 |
| Municipalidad 프로그램 | PASS | residence 기준과 current-location 기준을 분리 |
| 학교/WhatsApp intake | PASS | Intake → membership → Event → Action |
| 업체 견적/서비스 | PASS | Action → Case → provider complete → user confirm → LifeHistory |
| 지역 행사 | PASS | 원본 Event는 유지하고 현재 위치에 따라 Home projection만 변경 |

## 이번 검증으로 고정해도 되는 부분

1. **Location Context는 canonical 장소와 별도 운영 상태로 둔다.**
2. **행정 자격과 현재 생활권 relevance를 분리한다.**
3. **Domain 원본을 하나의 Event 테이블로 억지 합치지 않고 Common Event Envelope로 투영한다.**
4. **Action과 LifeHistory 사이에 Case/Outcome lifecycle이 필요하다.**
5. **Home/Push/Inbox는 도메인 데이터가 아니라 Relevance 이후의 Delivery projection이다.**
6. **외부 메시지/문서는 Intake evidence로 받고, 추출 결과를 즉시 공식 사실로 승격하지 않는다.**

## 아직 Freeze하면 안 되는 부분

- Relevance 점수 가중치: 실제 사용자 행동/소음 수준을 보고 조정해야 한다.
- Local Graph의 세부 taxonomy: comuna별 조사 결과가 계속 들어오므로 adapter/canonical 경계만 먼저 고정한다.
- WhatsApp 자동 연동 방식: 공유하기/import 등 허용 가능한 실제 연동 경로를 제품·정책 측면에서 추가 검증해야 한다.
- 결제/시외교통/의료처럼 외부 거래·고위험 판단이 필요한 Domain의 상세 상태 머신.
- 운영 DB/인프라의 최종 공급자 선택.

## 다음 구현 게이트

이제 다음 단계는 **실제 데이터 소스 하나씩을 같은 계약에 연결하는 adapter 검증**이다.

우선순위:
1. Local/Admin 한 source family
2. Education notice intake
3. Business quote/service outcome
4. Local public event
5. Mobility static/realtime는 기존 별도 자산을 adapter로 연결

Core를 추가하기 전에 위 adapter들이 기존 Kernel로 처리되지 않는 구체적 이유가 있는지 먼저 증명한다.


## Care-layer extension

After the founder-level Care direction was clarified, four additional contract scenarios were added and passed:

6. household-help relationship → recurring payment obligation without legal/employment authority semantics;
7. public-program rule → entitlement candidate without falsely claiming verified eligibility;
8. calendar pickup plan → remains `planned` after time passes and becomes `confirmed` only with actual confirmation;
9. vehicle repair need → Care/Relevance → Business quote action, proving the domain is invoked after the life need is recognized.

Current deterministic fixture result: **9/9 PASS**.

These remain fixtures for architecture validation, not live public facts.
