# Palta Listing, Distribution & Monetization Core V1

Status: V1 design contract candidate for freeze
Date: 2026-09-14

## 1. Purpose

Palta must let individuals publish local-life items easily while letting professional operators manage large inventories without creating separate platforms for used goods, cars, property, jobs, local business, local activities and alerts.

Principle: **one canonical object, many surfaces and channels.**

## 2. Shared Listing Core boundary

Listing Core owns only reusable publication semantics:
- canonical listing identity
- actor reference and actor type
- location / administrative area
- audience scope
- lifecycle: draft, active, paused, completed, expired, removed
- source/provenance
- reusable distribution bindings
- reusable promotion attachment

Listing Core does not own specialist domain meaning. Auto owns vehicle details. Real Estate owns property and transaction intent. Jobs owns employment-specific fields. Marketplace owns item condition and exchange semantics.

## 3. Vertical policy is not one global quota

Policy differs by category and remains configuration, not hard-coded product truth.

### Auto
- ordinary individual flow assumes one active personal vehicle listing is normal
- repeated/multiple simultaneous inventory can trigger professional transition review
- professional sellers use Dealer capability rather than bypassing individual limits

### Real Estate
- ordinary individual flow supports a small number of personally controlled properties; launch default may be one active listing
- repeated portfolio-like behavior transitions to professional/property-manager mode
- exact quota stays policy-configurable

### Marketplace / used goods
- multiple simultaneous listings are normal for an individual
- quantity alone must never classify the person as a professional seller
- professional-seller signals may include repeated identical inventory, repeated new-goods patterns, persistent replenishment, duplicated catalog-style listings, or explicit business behavior
- signals recommend/require professional transition only according to policy; they are not a universal person score

### Jobs
- a Business can create a job directly from its Business context without re-entering business identity/location
- launch free credits/quotas are policy values and may change without schema changes

### Local activity / local alert
- garage sale, neighborhood event, donation, lost pet, found item and similar local-life content prioritize locality/safety rather than commercial quotas

## 4. Real Estate contract

Real Estate has two primary intents:
- `venta`
- `arriendo`

Arriendo may specify:
- long-term
- temporary
- vacational

Property type may include house, apartment, cabin/cabaña, room, commercial property, land and other.

A cabaña is therefore not a separate platform. It is a Real Estate listing with `intent=arriendo`, typically `propertyType=cabin`, and may later enable Availability/Booking without changing Listing Core.

## 5. Distribution Core

A canonical listing may be projected to:
- Palta
- share link / web preview
- business site/custom domain
- external marketplace adapter
- partner feed

Import and export must preserve provenance and ownership/permission. Palta must not scrape or republish third-party inventory without authorization.

Professional onboarding priority:
1. CSV/Excel or structured import
2. supported API/feed connector
3. user-approved migration/import assistant
4. manual creation only when needed

The objective is to avoid forcing a dealer, broker or business to re-enter hundreds of existing listings.

## 6. Promotion / advertising

Promotion does not clone domain content. It references the existing object.

`existing object -> Promote -> area / duration / budget -> sponsored placement`

Examples:
- Business Card -> Sponsored Business Card
- Marketplace Item -> Sponsored Item
- Property -> Sponsored Property
- Vehicle -> Sponsored Vehicle
- Job -> Sponsored Job

Sponsored content uses the native card grammar of the destination surface and must be clearly labeled `Publicidad` / `Patrocinado`.

Promotion policy controls free credits, paid boosts, budgets, placement and frequency. Free launch quotas are configuration and must never be encoded in core schema.

## 7. Cross-domain reuse

A Business can reuse its identity/location/profile to create:
- a job listing
- a coupon
- a promoted business card
- a marketplace/equipment listing when policy allows
- property/vehicle inventory when the corresponding professional capability is enabled

The user should not repeatedly rebuild the same business identity for each vertical.

## 8. Professional transition

Palta distinguishes normal personal activity from professional inventory without assuming that volume alone proves commercial activity.

Policy may evaluate domain-specific behavior signals. The resulting decision is purpose-specific:
- allow personal publication
- ask for professional mode
- require professional mode for additional listings
- allow publication but restrict commercial features until verification

This must not become a universal trust score or hidden social classification.

## 9. Platform acquisition strategy

Palta should first win the operational center, then the traffic:

`existing inventory -> easy import -> canonical Palta management -> distribute/share -> unified inquiry/status/promotion -> growing direct Palta demand`

Individuals receive a simple local-first publishing flow; professionals receive import, bulk management, distribution, analytics and promotion.

## 10. Freeze tests

A change belongs in Listing Core only if it is reusable across multiple listing verticals. Specialist meaning stays in the owning vertical. Distribution and Promotion reference canonical objects; they do not create second sources of truth.
