# Palta Commercial Capability Architecture V1

Status: design contract, not production schema freeze
Date: 2026-09-14

## 1. Purpose

Palta Business must support very different businesses without turning Shared Core or POS into a monolith. A business starts with the smallest useful set of capabilities and can enable more capabilities later without moving to a different product or duplicating canonical business data.

Principle: **one canonical Business, one Commercial Core, optional capabilities.**

## 2. Boundary

### Shared Core owns reusable platform behavior
- Person / account identity
- location and administrative area
- privacy / access / audit
- progressive verification / assurance
- messaging transport and notification delivery
- search/map primitives
- source/provenance and general action/event primitives

Shared Core does **not** own restaurant tables, kitchen tickets, wholesale matrices, work orders, POS carts, inventory movements, tax documents, or tender matching.

### Commercial Core owns common transaction semantics
- Business identity reference and branch reference
- Catalog item / service offer
- Price and price rule
- Inventory item and inventory movement
- Customer reference (minimal, purpose-bound; not a second Person owner)
- Order and order line
- Fulfillment
- Sale / return / refund state
- Commercial case linking quote, booking, order, fulfillment and outcome
- Commercial audit/idempotency keys

### Capability modules own specialist meaning
Capabilities are enabled only when the business needs them.

1. `booking`
   - availability, resource/staff slot, duration, confirmation, change/cancel, reminders, no-show state
2. `quote`
   - request, photos/specification, invited suppliers, response, comparison, acceptance
3. `field_service`
   - site visit, technician assignment, work order, parts used, service completion evidence
4. `retail`
   - barcode, cart, promotion, return/exchange, store pickup
5. `wholesale`
   - model/variant matrix, customer price list, minimum quantities, bulk order, credit terms reference
6. `restaurant`
   - table/seat, modifiers, course/fire state, takeaway/dine-in
7. `kitchen_kds`
   - station routing, kitchen ticket, preparation state, bump/recall
8. `delivery`
   - delivery/pickup mode, address handoff, dispatch state, external courier adapter
9. `staff_operations`
   - employee/worker role assignment for the business, shifts, register permissions, operational responsibility
10. `multi_location`
   - branches, warehouses, stock transfer, branch-specific prices/hours/capabilities
11. `crm_loyalty`
   - consented customer relationship, favorites, coupons, loyalty benefits, follow-up
12. `tax_document`
   - Boleta/DTE request state, SII adapter, retry/audit; regulations stay in versioned country adapter
13. `payment_adapter`
   - external payment-provider request/result only; Palta is not the payment operator in current scope
14. `opportunity_tender`
   - public/private opportunity intake, category matching, deadline, requirements summary, official-source handoff
15. `business_messaging`
   - inquiry/conversation context while minimizing exposure of personal phone/email
16. `reporting`
   - sales, inventory, booking, quote and operational projections; derived, never canonical transaction truth
17. `lot_expiry`
   - lot/batch identity, manufacture/expiry dates, FEFO policy, quarantine/recall traceability
18. `production_batch`
   - input/output batch genealogy for businesses that transform or manufacture goods
19. `recipe_bom`
   - recipe/BOM components, expected consumption and yield; does not replace canonical inventory movements
20. `storage_condition`
   - required storage class/condition and operational location state (for example ambient/chilled/frozen); not a certification system

New industries should first be expressed as combinations of these capabilities. Add a new capability only when existing semantics cannot safely represent the business behavior.

## 3. Progressive product rule

A small business must not see unused complexity.

Examples:
- Small cafe: Catalog + POS; optionally Table, KDS, Delivery
- Full restaurant: Catalog + POS + Restaurant + KDS + Inventory; optionally Delivery/Multi-location
- Massage/beauty: Service Catalog + Booking + POS; optionally Staff/CRM
- Air conditioning/installations: Quote + Field Service + Booking; optionally Inventory/POS
- Retail shop: Catalog + Inventory + Retail + POS; optionally Loyalty/Multi-location
- Clothing wholesale: Catalog + Wholesale + Inventory + POS; optionally Customer Price Lists/Multi-location
- Imported food wholesale: Wholesale + Inventory + Lot/Expiry + Storage Condition + Tax Document; optionally Multi-location/Delivery
- Bakery/light manufacturing: Inventory + Production Batch + Recipe/BOM; optionally Retail/Wholesale/Lot-Expiry

Turning on a capability must reuse the same Business, Catalog, Customer references and transaction history rather than creating a separate business system.

## 4. POS position

Palta POS is a business product built on Commercial Core. It is not Shared Core.

POS may use:
- Catalog / Price / Inventory
- Order / Sale / Return
- staff permissions
- tax-document adapter
- external payment adapter
- local-first transaction queue and sync

Current payment boundary:
`Palta POS -> external regulated payment provider -> payment result -> Palta sale state`.

Future Palta-owned payments are an optional distant expansion and must not leak present-day financial-regulatory complexity into Commercial Core.

## 5. Reliability contract

For POS and orders, correctness precedes speed.

Required properties:
- no lost sale
- no duplicated sale on retry
- no double inventory decrement
- idempotent client retry
- atomic server transaction where required
- local-first/offline queue for POS-critical actions
- resumable synchronization after network loss
- immutable audit trail for financial/stock mutations
- batch APIs for large orders; never require one network request per order line

Validation targets include 500 / 1,000 / 5,000 line orders plus concurrent terminals and failure recovery.

## 6. Marketplace / ranking neutrality

Palta ecosystem participation can be a tie-breaker only after user suitability and quality are satisfied.

Ranking order principle:
1. user fit, service ability, locality/availability, quality and current reliability
2. when materially comparable, Palta-integrated businesses may receive preference because data/actionability can be better
3. paid placement must be visibly labeled and must not masquerade as independent ranking

The founder archive explicitly requires verified-use reviews, privacy of quote-request contact details, booking confirmation/change/reminder flows, and no disguised paid recommendations.

## 7. Business opportunity / tender

`opportunity_tender` belongs to Palta Business, not Shared Core and not POS.

Flow:
`official/public/private opportunity source -> normalize -> business/category match -> relevance -> business home/alert -> requirements/deadline summary -> official action handoff`.

Current scope does not submit legal bids on the business's behalf. The same normalized opportunity data may later be translated/distributed to foreign suppliers, chambers, associations or export-support partners where legally permitted.

## 8. Additional controls that must not be forgotten

- branch and warehouse separation
- staff role/permission separation (cashier, manager, kitchen, warehouse, technician)
- cash-register opening/closing and reconciliation as POS module concern
- return/exchange/refund and cancellation paths
- inventory adjustments, stocktake and transfers
- per-customer/wholesale pricing without corrupting canonical base price
- tax-document retry/reconciliation
- payment-result reconciliation without becoming the payment operator
- customer consent and retention limits for CRM
- verified-use linkage for reviews
- data export/portability for businesses
- audit history for sensitive commercial mutations
- capability flags must not become a pile of UI booleans; domain modules own their own state
- unit-of-measure and conversions belong to Catalog/Inventory semantics because roll, box, unit, meter, kilogram and pallet cross industries
- lot/expiry and batch genealogy must be opt-in inventory extensions so simple businesses never inherit regulated-industry complexity

## 9. Architecture test

For every new commercial feature ask:

1. Is it reusable platform behavior? -> Shared Core.
2. Is it common transaction meaning across many industries? -> Commercial Core.
3. Is it specialist operational meaning? -> Capability module.
4. Is it external-regulated behavior? -> Adapter.
5. Can a small business ignore it completely? If not, the design is probably leaking complexity.

