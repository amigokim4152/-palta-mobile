# Commercial / POS Load & Recovery Gate

Status: design-contract validated; live PostgreSQL benchmark still required.

## Boundary
This is **Commercial Core / POS**, not Shared Core. Shared Core supplies identity, verification, notification, audit primitives only.

## Non-negotiable invariants
1. One client transaction ID / idempotency key creates at most one sale.
2. Order header + all order items + inventory mutation are atomic at the server transaction boundary.
3. A timeout or network retry must not duplicate a sale or inventory decrement.
4. Offline POS queues persist locally and replay safely after reconnect.
5. Payment-provider acknowledgement is external evidence; Palta does not become the payment processor.
6. SII/Boleta/DTE is an adapter boundary and must not make local sale capture disappear when an external service is temporarily unavailable; fiscal issuance/retry rules must follow the applicable SII specification.
7. Bulk item creation must use batch/database operations, not one remote API request per item.

## V1 load gates
Deterministic contract tests: 500, 1,000, 5,000 order items; duplicate replay; failure at item 470; offline replay; multiple POS transaction keys.

Before production freeze, run against real PostgreSQL with realistic indexes and transaction SQL:
- 500 / 1,000 / 5,000 item single-order inserts
- concurrent terminals and concurrent inventory updates
- forced connection loss before commit, during response, and after commit-before-client-ack
- duplicate idempotency-key races
- queue replay after device restart
- partial external payment/SII outages
- verify zero lost sales, zero duplicate sales, zero double stock decrement, and auditable recovery state

Performance latency thresholds should be set only after the real PostgreSQL benchmark. Correctness is the first gate.
