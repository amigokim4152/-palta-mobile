# Palta architecture decision — zero-base mobile

## Decision
Build Palta as a mobile-first platform independent from Base44.

## Runtime
React Native + Expo mobile app → Cloudflare Workers API → standard PostgreSQL.
Cloudflare R2 stores PMTiles, GTFS snapshots, images and large/static serving data.

Map/GTFS and Municipalidad collection are parallel data tracks. They are connected through stable interfaces and do not block core platform construction.

## Shared core
- Identity/auth boundary
- Location context
- Relationships/personal graph
- Local graph/data
- Personalization/home
- Search/discovery
- Event/notification
- AI gateway
- Messaging
- Trust/safety
- Privacy/audit
- Ingestion/normalization

## Design constraints
- Mobile first; web is secondary for admin/business consoles.
- One shared location context across the product.
- Provider-neutral PostgreSQL and auth boundaries where practical.
- No provider secrets in mobile clients.
- No synthetic production data.
- Public data and personal/sensitive data have separate access boundaries.
- Async work uses events/outbox/queues rather than long synchronous request chains.

## Reliability tiers
Public/local information may tolerate cache and eventual refresh.
Business/POS transaction flows require stronger guarantees and, when introduced, offline/local queueing plus central sync. Do not design POS as cloud-only.
