# Technical review — 2026-09-14

## Confirmed direction
- Expo SDK 57 is the current Expo SDK line and maps to React Native 0.86 / React 19.2.3, minimum Node 22.13.x.
- Cloudflare Workers supports traditional PostgreSQL and Cloudflare recommends Hyperdrive for accelerated pooled access.
- R2 remains appropriate for large/static assets because it separates object storage from transactional Postgres and has no internet egress charge.

## Not yet proven
- This repository has not been dependency-installed in this environment because registry network access is unavailable here.
- No production PostgreSQL or R2 target has been connected.
- No real Palta municipal dataset has yet been copied into this new repository.
- No mobile map implementation is included until the base data/API path is verified.

## Risk controls
- Do not introduce fake records merely to make a demo look complete.
- Do not couple core schema to one managed Postgres vendor.
- Do not put high-frequency dynamic app queries directly on R2 JSON if Postgres/API is the proper authority.
- Do not expand modules before one real dataset and map/transit path pass end to end.
