# Palta Trust & Safety Engine V1

## Pipeline
create -> deterministic checks -> safety classification -> publish / limit / hold -> reports -> case -> human review when required -> action -> appeal -> evidence/audit.

## Risk families
spam, fraud, impersonation, harassment, threats, privacy exposure, minor safety, illegal goods/services, dangerous services, sexual content, copyright, false businesses, review manipulation.

## Decision rules
- Clear low-risk spam/duplication: automation may act.
- Ambiguous defamation, disputes, copyright, identity, minor safety, regulated/dangerous services: human review.
- AI may classify/summarize evidence but does not create authorization or make irreversible high-risk decisions alone.
- A report grants access to the reported item/case evidence, not to the reporter's or author's private life.

## Evidence
Preserve content reference, hashes, timestamps, rule/model version, action, reason, reviewer and appeal outcome. Do not duplicate sensitive payloads into logs.
