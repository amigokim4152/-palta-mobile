# Palta V1 Validation Gate — 2026-09-14

## Newly found implementation defect
A real TypeScript compile check found two exported types with the same name, `VerificationStatus`, in `packages/core/src/index.ts`. One represented canonical-data verification (`verified/corroborated/...`) and the other represented progressive-assurance verification (`pending/verified/failed/...`). This was a genuine compile-time collision.

## Fix
- Canonical/source verification is now `DataVerificationStatus`.
- Progressive action-assurance verification is now `AssuranceVerificationStatus`.
- `VerificationAssertion.status` uses `AssuranceVerificationStatus`.

This also makes the semantic boundary explicit: evidence quality/status is not the same thing as identity/action assurance.

## Continuous gate
The root project now exposes `npm run validate:contracts`, which executes:
- Kernel contract validation
- 14 domain scenario simulations
- Care attention-budget tests
- Care generation-safety tests
- Progressive verification tests
- Commercial/POS load-safety contract tests

GitHub CI now runs both TypeScript typecheck and the full contract-validation suite. A future change that breaks either shared-core typing or an established cross-domain invariant should fail CI instead of silently entering the build.

## Remaining unproven areas
This is still not a production benchmark. Before production freeze, Palta still needs:
- real PostgreSQL/PostGIS migration execution,
- real concurrent transaction/load tests against PostgreSQL,
- React Native/Expo install + device/runtime verification,
- real SII/payment-provider adapter integration tests,
- one real Chile data flow from collection through Care/Relevance/Action.
