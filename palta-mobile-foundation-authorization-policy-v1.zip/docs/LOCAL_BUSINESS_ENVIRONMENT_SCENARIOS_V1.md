# Local Business Environment Scenarios V1

Status: validated scenario contract, 2026-09-14

Purpose: test one Local Business vertical against three materially different Chilean environments without adding duplicate cores.

## A. Tourist / seasonal coast — Algarrobo pattern

Scenario: a visitor selects or arrives in a coastal tourist area and wants food, coffee, services and useful nearby places.

Required behavior:
- current/selected/trip area changes local discovery relevance without deleting home context;
- business discovery emphasizes `open evidence`, special/seasonal hours and last verification rather than trusting normal hours alone;
- map can show a nearby parking place and walking relation to a storefront when known;
- restaurants/cafes expose category-aware attributes such as pet policy, terrace, family suitability, accessibility, takeaway/delivery/reservation and parking;
- a mobile electrician/plumber/gardener can be returned through `service_area` even without a customer-facing office;
- sparse specialist results may widen to adjacent functional life areas and must tell the user that scope expanded;
- owner/community corrections never silently overwrite canonical facts;
- free claimed profiles can update current status, photos, posts, attributes and basic customer actions;
- operator receives privacy-safe engagement signals so seasonal profiles have a reason to stay current.

Failure examples:
- claiming `open now` from stale normal hours alone;
- hiding a useful free business because it did not pay;
- requiring a mobile professional's home address;
- ranking a sponsored restaurant as an organic `best restaurant`.

## B. Dense urban center — Santiago Centro pattern

Scenario: a user wants a restaurant/shop/service in a dense center where driving, parking and walking access materially affect the choice.

Required behavior:
- `parking=true` is insufficient: represent own_free, own_paid, building_shared, nearby_paid, street_possible, difficult or unknown;
- when evidence exists, link the business to a separate nearby parking Place and show walking distance/time rather than duplicating parking facts into every business;
- do not imply street parking exists merely because a storefront has a street address;
- walking/transit access can outrank vehicle proximity where context makes it more useful;
- storefront discovery remains distinct from service-area professional discovery;
- category attributes stay concise and factual, not uncontrolled marketing copy;
- paid placement remains a separate labeled sponsored surface and cannot create `#1`, `best`, or Palta recommendation claims;
- multilingual presentation preserves canonical source text and provenance.

Failure examples:
- showing only `parking available` with no type/source;
- allowing an advertiser to self-write `Palta #1 restaurant`;
- letting payment alter organic recommendation score;
- treating every nearby provider as equally suitable regardless of specialty/coverage.

## C. Regional / lower-density city — San Fernando pattern

Scenario: a resident needs ordinary local commerce plus a specialist such as auto repair or home service, where the best fit may be farther away.

Required behavior:
- start local, then widen discovery based on result density and category purpose;
- cafes/convenience remain tight-radius; auto specialty, health/specialist and service-area work may widen substantially;
- explain expansion simply to the user;
- specialty/fit and service coverage can outrank raw distance;
- saved life context such as vehicle type may filter suitability without exposing private context to businesses before an action requires it;
- quote request routes to a bounded set of eligible providers, not a mass broadcast;
- user contact details remain purpose-bound until selection/disclosure is necessary;
- new/small businesses get discovery opportunity without manufacturing reputation or ranking;
- no assumption that low result density means no local economy exists: baseline data, claim, community contribution and corrections can improve coverage over time.

Failure examples:
- fixed 5 km rule for every category;
- sending one quote request to every provider in the region;
- exposing the requester's phone number to all bidders;
- interpreting one five-star review as a Palta recommendation badge.

## Cross-environment invariants

1. Organic recommendation, paid product capability and advertising remain separate.
2. Free profile is useful enough to participate in the local data flywheel.
3. Business identity is canonical; no duplicate identity per vertical or channel.
4. Physical storefront and service-area business are first-class discovery modes.
5. Administrative jurisdiction and functional discovery area are not the same concept.
6. Normal hours, temporary state and observed/verified state are distinguishable.
7. Official/operator content, community content and Palta-derived reputation remain separate.
8. Community criticism cannot be deleted by the business merely because it is negative.
9. Translation preserves source text and provenance.
10. Sensitive/private user context is not exposed for analytics or ranking.
11. Map, Home and Business use shared location/place primitives rather than duplicate maps.
12. Palta recommendation/badges require sufficient evidence and are never purchasable.

## Outcome

All three environments fit the existing Local Business Vertical contract. They do not justify reopening Core V1. The remaining implementation work belongs primarily to Local Discovery policy, Place/parking relationships, business attributes, live operating state, moderation, translation and UI/adapter work.
