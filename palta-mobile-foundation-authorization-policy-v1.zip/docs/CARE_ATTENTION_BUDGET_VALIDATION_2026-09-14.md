# Care Attention Budget Validation — 2026-09-14

Status: DESIGN VALIDATION / FIXTURE TESTS ONLY

## Question
Can Palta remember many life facts and Care items without turning Home into a noisy task list?

## Decision
Yes, if Home composition has an explicit **attention budget**. Care creation and Home display are separate decisions.

`Record/Context → Care candidate → Relevance → Attention budget → Home / Inbox / Store only`

## Rules validated

1. **No automatic Home placement.** Creating a Care item never guarantees Home display.
2. **Small active surface.** A composer may cap primary and secondary attention slots; overflow stays in Inbox/history rather than expanding Home indefinitely.
3. **Handled/dismissed/expired items leave the active surface** while their useful record may remain retrievable.
4. **Routine history stays searchable, not visible.** Ordinary purchases or low-value records do not become Home cards merely because Palta remembers them.
5. **Candidate entitlements remain candidates.** An uncertain possible benefit must not outrank a comparable confirmed obligation solely because it is attractive.
6. **Multiple children/objects do not imply equal simultaneous exposure.** Subject identity is preserved, but urgency/actionability determine what appears now.
7. **Critical items can overflow to Inbox rather than be discarded.** Attention budget limits presentation, not underlying memory.

## Fixture tests

`python3 scripts/validate_care_attention_budget.py`

- three-child mixed school-care load: PASS
- 20 ordinary purchase/history records suppressed from Home: PASS
- handled obligation removed from active surface: PASS
- candidate benefit confidence penalty: PASS
- expired entitlement suppressed: PASS
- 12 simultaneous urgent obligations respect 3 primary + 5 secondary attention slots with remaining items retained in Inbox: PASS

Result: **6/6 PASS**.

The slot counts are test policy, not frozen product UX. They prove the architectural separation between memory and attention; final mobile UX may use a different presentation and adaptive limits.

## Important boundary

Relevance ranking is not legal truth and does not decide family authority. It only decides presentation priority among items the person is already entitled to see.
