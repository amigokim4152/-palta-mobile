# Palta Legal Matrix V1 — Chile launch control

This is a product release-control matrix, not a substitute for Chilean legal advice. Red items require specialist legal confirmation and controls before launch.

| Capability | V1 gate | Primary issue | Product boundary |
|---|---|---|---|
| Municipality/public information summary + source link | YELLOW | accuracy, provenance, copyright/image rights | preserve source; short factual summary; use images only with lawful basis/permission |
| Community posts/photos | YELLOW | privacy, defamation, copyright, illegal content | reporting, moderation, appeal, evidence |
| Free Business Page / owner claim | YELLOW | identity, accuracy, consumer/business information | claim verification; public vs owner-provided provenance |
| Sponsored placement | YELLOW | advertising transparency, consumer rules | label Patrocinado/Publicidad; paid placement cannot buy organic reputation |
| Marketplace person-to-person discovery/messaging | YELLOW | fraud, prohibited goods, platform role | purpose messaging; safety controls; no V1 custody of funds |
| Palta payment/escrow | RED | payments, tax, consumer/platform obligations, disputes/refunds | out of V1 until specialist review |
| Real estate listings | YELLOW | listing accuracy, discrimination, intermediary role | discovery/contact first; domain-specific terms and moderation |
| Jobs | YELLOW | labor/discrimination/privacy | job-specific policy and prohibited criteria controls |
| General Local Request | YELLOW | safety, liability, identity | connection first; category risk routing |
| Child/caregiving requests | RED | minors/safety/qualification | restricted until enhanced verification/legal review |
| Electrical/gas/regulated professional services | RED | qualification/public safety | require verified qualification path before broad activation |
| Health personalization | RED | sensitive data, health claims | isolated sensitive realm; no diagnosis claims; specialist review |
| Precise location/family/private life data | RED | personal/sensitive data | private-by-default; purpose limitation; no operator browsing |
| Analytics from user behavior | YELLOW | re-identification, purpose limitation | pseudonymize, aggregate, minimum cohort, no reverse lookup |

## Release rule
Every new capability declares a matrix row before production. RED cannot ship by ordinary product approval. YELLOW must list required controls and evidence. Changes that move Palta from discovery/contact into contracting, payment, custody, regulated advice, or high-risk care trigger re-review.
