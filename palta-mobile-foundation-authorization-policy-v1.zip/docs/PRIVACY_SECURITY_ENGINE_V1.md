# Palta Privacy & Security Engine V1

## Non-negotiable boundary
A Palta operator, developer, or Operator AI does not receive general access to a person's private life. Business/support work is handled through an explicit Work Context. Relationship does not imply authority, access, or sharing.

## Realms
- PUBLIC: official/local/public business information.
- WORK: business onboarding, business support, Palta support, moderation/legal cases. Purpose-limited.
- PRIVATE: personal Home, private activity, saved items, personal messages outside the relevant work purpose.
- SENSITIVE: health and specially protected data; stronger isolation.
- ANALYTICS: pseudonymous/aggregated product signals; no operator reverse lookup to people.

## Operator AI
Operator AI has no generic person/private search tool. It may receive only a scoped Work Context and the minimum fields needed to perform the task. Tool authorization is deterministic and server-side. Prompt text never grants permission.

## Analytics pipeline
Private source -> minimization -> pseudonymous analytics subject -> coarse time/location/category -> minimum cohort suppression -> aggregate insight. Pseudonymous data remains protected data. Analytics APIs must never expose the mapping back to person_id.

## Maintenance without content inspection
Prefer technical metadata: request id, error code, app version, upload state, object size/type, transformation status, DB operation status. Production personal content is not copied to development/QA. Synthetic data is the default.

## Exceptional access
No standing super-admin private-content browser. Exceptional lawful/safety access is a separate case, narrow scope, time limited, reason recorded, and audited. It is not an ordinary support workflow.

## Security lifecycle
Least privilege, passkeys/MFA for privileged roles, separate service identities, encryption in transit/at rest, separate key domains for sensitive realms, secret scanning, dependency scanning, anomaly/rate controls, immutable audit trail, tested backup/restore, incident response and periodic penetration/security review.
