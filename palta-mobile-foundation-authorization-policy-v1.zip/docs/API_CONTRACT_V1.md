# Palta API Contract v1 — Kernel Boundary

Status: design contract; provider-neutral; not production connected.

Base path: `/v1`

## Context

### `GET /context`
Returns the person's durable and current context required by clients.

Response shape:
```json
{
  "person": {"id":"uuid","locale":"es-CL","timezone":"America/Santiago"},
  "location": {
    "current": {"placeId":"uuid|null","administrativeAreaId":"CL-...","updatedAt":"..."},
    "home": {"placeId":"uuid|null","administrativeAreaId":"CL-..."}
  },
  "relationships": [{"targetKind":"organization","targetId":"...","relationType":"member"}],
  "lifeObjects": [{"id":"uuid","objectType":"vehicle","title":"..."}]
}
```

### `POST /context/location`
Updates short-lived current/temporary location context. It does not create a permanent movement trail by default.

## Care

### `GET /care`
Returns the person's current care items (`obligation`, `entitlement`, `care_need`) with responsible person, optional subject/context, source provenance/version, due/expiry timing and actionability. Rule-generated items must be idempotent through a stable dedupe key. It is not a legal case-management endpoint.

### `POST /care/:id/handled`
Marks a person-owned care item as handled only when the user or a trusted connected system is authoritative for that result. A passed due time never implies completion.

### Schedule adapters
External calendars remain source systems. Palta may keep a lightweight schedule reference and convert relevant schedule entries into planned events/care candidates.

## Home

### `GET /home`
Reads `delivery_projection(channel=home)` plus minimal referenced detail.

Query inputs may include current location version and pagination. The client does not compose domain Home blocks itself.

### `POST /home/:projectionId/action`
Supported actions include `read`, `dismiss`, `snooze`, and domain action routing. Presentation actions do not mutate canonical domain truth.

## Events / actions

Shared events expose truth state (`planned`, `observed`, `confirmed`, `cancelled`, `unknown`). Planned events do not become confirmed merely because time passed.


### `GET /actions`
Returns open/scheduled action items for the person.

### `POST /actions/:id/complete`
Completes a person-owned action when completion is locally authoritative.

### `GET /cases/:id`
Returns normalized case state plus privacy-safe timeline.

### `POST /cases/:id/confirm-outcome`
Confirms or disputes an external/provider completion result. Confirmed outcomes may generate LifeHistory.

## Local

### `GET /local`
Returns current-area discovery from Local Graph/read models. Filters may include category, radius, time window and viewport.

The endpoint consumes `person_location_context` but local discovery data remains owned by its domain/Local Graph.

## Intake

### `POST /intake`
Accepts user-shared text/link/media metadata for structured processing. Examples: WhatsApp notice, school message, church notice, business message.

The Intake service returns an ingestion receipt and later produces domain/event candidates. It does not silently publish extracted claims as canonical truth.

## Search

### `GET /search`
Permissions-aware cross-domain search over derived indexes. Search is never a canonical owner.

## Integration rule

Mobile clients call Palta endpoints only. Provider-specific URLs, keys, response schemas and retry logic remain behind provider adapters.
