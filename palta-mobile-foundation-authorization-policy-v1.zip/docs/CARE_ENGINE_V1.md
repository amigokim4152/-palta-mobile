# Palta Care Engine v1

Status: DESIGN-VALIDATED DIRECTION / NOT PRODUCTION DEPLOYED  
Date: 2026-09-14

## 1. Purpose

Palta does not exist to manage a person's real life as if Palta were an employer, court, school authority, family registry, or tracking system.

Its job is simpler:

> **Understand enough context to help the person remember what they must do, what they may receive, and what they should care for.**

The Care layer has three kinds:

- `obligation` — something the person should do or pay;
- `entitlement` — something the person may be able to receive or use;
- `care_need` — something involving a person, household, object or routine that deserves attention.

Examples:
- salary/payment due to a household helper;
- tax, permit, insurance or fee deadline;
- municipal or national benefit eligibility;
- school material or family appointment;
- vehicle maintenance or pet vaccination reminder.

## 2. What Care is not

Care is **not**:
- legal employment lifecycle management;
- automatic proof that an event really happened;
- a family-law registry;
- permanent location surveillance;
- a workflow that forces the user to check every ordinary life event as completed.

A relationship can help explain why something matters without Palta becoming the authority over that relationship.

Example:

`María helps in the household → recurring salary obligation`.

Palta can remind the person about the salary. Palta does not decide whether María is legally employed, has resigned, or must be terminated.

## 3. Core flow

```text
Person / Relationship / LifeObject / Place / Schedule / Knowledge
                         ↓
                  Context Resolver
                         ↓
                     Care Item
          ┌──────────────┼──────────────┐
      Obligation     Entitlement     Care Need
                         ↓
                    Relevance
                         ↓
              Home / Reminder / Action
                         ↓
          Outcome only when actually known
```

## 4. Planned is not completed

Palta must preserve epistemic state.

- `planned` — expected/scheduled;
- `observed` — a signal says it occurred or changed;
- `confirmed` — an authoritative or explicit confirmation exists;
- `cancelled` — the plan/event was cancelled;
- `unknown` — Palta cannot determine truth.

Examples:

- calendar says school pickup at 16:00 → `planned`;
- calendar time passes → still not automatically `confirmed`;
- school/provider/system or a person explicitly confirms pickup → `confirmed`.

Same rule applies to appointments, repairs, trades, deliveries, payments and other real-world events.

## 5. Calendar rule

Google Calendar, Apple Calendar and other schedule providers remain source systems when they own the schedule.

Palta uses adapters and a lightweight `schedule_reference` so the schedule can contribute to Care/Relevance without duplicating the full calendar system.

```text
External Calendar
→ Schedule Reference
→ planned Event / Care Item
→ Relevance
→ Home / Reminder
```

A calendar event ending does not prove real-world completion.

## 6. Care generation

A Care item may be generated from:

- an explicit user statement;
- a deterministic Chile rule/deadline;
- a verified domain record;
- an external calendar event;
- an external system signal;
- a safe derived inference that remains marked as candidate/likely until confirmed when necessary.

AI may help classify or extract. AI does not invent legal duties, eligibility, payments, completion or authoritative facts.


## 6.1 Responsibility, subject and provenance

A Care item must distinguish **the person Palta is helping** from **what or whom the item is about**.

- `person_id` = the person whose Palta experience should surface the item;
- `subject_person_id` = optional other person the care concerns (child, parent, dependent, etc.);
- `life_object_id` = optional home/vehicle/pet/object context;
- `context_kind/context_ref` = optional domain-owned subject such as a Business, Property or Policy Program.

This prevents a child's school reminder, a parent's hospital appointment, or a business-owner obligation from being flattened into the user's own identity.

Rule/source-generated Care must also preserve enough provenance to be reproducible: source reference, source/rule version, last checked time, validity window and a stable `dedupe_key`. Retrying the same collector or rule must not create duplicate active Care items.

Recurring local obligations must retain their recurrence timezone. Chilean daylight-saving changes must not shift a local due time merely because UTC offsets change.

## 7. Relevance before display

Care items do not automatically flood Home.

Relevance decides whether the item should surface based on factors such as:
- deadline proximity;
- consequence of missing it;
- eligibility window;
- direct relationship;
- current location/context;
- current actionability;
- whether it has already been handled.

Principle:

> **Palta can remember many things and show only what matters now.**

## 8. Domain relationship

Domains remain specialist capability owners.

Examples:
- Business can execute quote/booking/order/payment;
- Real Estate can search/compare/contact/visit;
- Auto can support repair, inspection, insurance and marketplace flows;
- Education can structure school notices;
- Public Policy can determine benefit/deadline candidates.

Care sits above those domains and asks:

1. What should this person care about now?
2. Which domain can solve it?
3. What is the shortest safe action path?
4. What result is actually known afterward?

## 9. Family, children and need-to-know boundaries

Family context is intentionally incomplete and private. Palta is not a family registry and must not require documentary proof merely to provide ordinary life assistance.

- a self-declared relationship is context, not legal proof;
- relationship does not automatically create authority, access or sharing;
- a household is a living-context grouping, not proof of parentage or guardianship;
- a child may have different parents/caregivers and different sharing arrangements without exposing those relationships to one another;
- Palta must not infer access from surname, co-residence, parent labels or AI inference;
- information about a minor defaults to private and is disclosed only through an explicit, purpose-limited sharing decision or a trusted domain integration that is entitled to provide that specific information;
- ordinary personalization must not require custody, birth, marriage or family-registry documents;
- if a future official-government integration requires stronger identity/authority assurance, that belongs behind a separate authorized adapter and must not redefine the ordinary Care model.

The practical rule is **need-to-know, not family-tree visibility**.
