# Palta Kernel — Structural Review

Status: reviewed after scenario validation; not production deployed.

## What remains frozen

The following directions are stable enough to build against:

- one Person context, many roles/relationships;
- administrative jurisdiction separated from current/distance-based life area;
- domain truth emits a shared Event envelope instead of writing directly to Home;
- Relevance decides whether an eligible item is surfaced, action-only, stored, or suppressed;
- Home/Inbox/Push/Calendar are delivery projections, not canonical domain data;
- multi-step external work uses Action → Case → Outcome before durable LifeHistory where confirmation matters;
- external Chilean providers remain behind adapters;
- existing Map, Local/Admin, Business, Real Estate, Education and Mobility assets are migration inputs, not reasons to create duplicate engines.

## Hardening changes found necessary

### Spatial integrity
Latitude/longitude columns alone are not sufficient for Chile-wide radius/viewport work. PostgreSQL/PostGIS is now the intended open spatial contract, with versioned administrative boundaries kept separate from area identity.

### Current-location lifecycle
Only one open `current` location context is allowed per person. This prevents ambiguous simultaneous current locations while still allowing multiple saved/habitual/temporary contexts.

### Event audience
`visibility_scope` alone cannot tell the system which school, church, group or person an event belongs to. `palta_event_target` adds membership/audience targeting without copying domain content into the Event envelope.

### Relevance decision
A ranking score is not enough. The engine must persist the decision: `surface`, `inbox_only`, `action_only`, `store_only`, or `suppress`, together with location/relationship/relevance scores and `why_shown` evidence.

### Case traceability
A case now references the `action_item` that opened it. This closes the trace from Need → Action → Case → Outcome → LifeHistory.

### Delivery idempotency
Home/push generation needs a dedupe key so retries cannot create duplicate cards/notifications.

### Intake
WhatsApp/share-sheet/document ingestion is modeled as a receipt and review pipeline. Parsed text is evidence/input, not automatic canonical truth.

## Items deliberately not frozen yet

- exact Relevance scoring formula and weights;
- final authentication provider;
- payment provider;
- AI provider/model;
- dedicated search engine;
- exact municipal adapter list;
- intercity transport commercial/provider contracts;
- production database vendor and HA tier.

These can change without changing the Kernel contracts above.

## Next proof gate

Before production infrastructure is provisioned, one executable integration fixture should prove all of these through the same contracts:

1. public local event + current location → Home candidate;
2. municipal program + residence eligibility → Home/action candidate;
3. school intake + active membership → private parent action;
4. quote/service completion → Case/Outcome → user-confirmed vehicle/home LifeHistory;
5. changing current location changes local relevance without changing legal residence/jurisdiction.
