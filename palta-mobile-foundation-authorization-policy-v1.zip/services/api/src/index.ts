import { Router } from './core/router';
import { fail, requestId } from './core/http';
import { health } from './routes/health';
import { bootstrap } from './routes/bootstrap';
import { aiGateway } from './routes/ai';

export interface Env {
  ENVIRONMENT?: string;
}

const router = new Router<Env>()
  .on('GET', '/health', health)
  .on('GET', '/v1/bootstrap', (request) => bootstrap(request))
  .on('POST', '/v1/ai', (request) => aiGateway(request));

const securityHeaders: HeadersInit = {
  'x-frame-options': 'DENY',
  'permissions-policy': 'camera=(), microphone=(), geolocation=()'
};

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const rid = requestId(request);
    try {
      const response = await router.dispatch(request, env);
      if (!response) return fail('not_found', 'Route not found.', rid, 404);
      const headers = new Headers(response.headers);
      for (const [key, value] of Object.entries(securityHeaders)) headers.set(key, value);
      return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
    } catch {
      return fail('internal_error', 'Unexpected server error.', rid, 500);
    }
  }
} satisfies ExportedHandler<Env>;
