import type { ApiEnvelope } from '@palta/core';

export const requestId = (request: Request): string =>
  request.headers.get('cf-ray') ?? crypto.randomUUID();

export const json = <T>(body: ApiEnvelope<T>, status = 200, extraHeaders?: HeadersInit): Response =>
  Response.json(body, {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff',
      'referrer-policy': 'no-referrer',
      ...extraHeaders
    }
  });

export const ok = <T>(data: T, requestIdValue: string, status = 200): Response =>
  json({ ok: true, data, requestId: requestIdValue }, status);

export const fail = (
  code: string,
  message: string,
  requestIdValue: string,
  status = 400
): Response => json({ ok: false, error: { code, message, requestId: requestIdValue } }, status);
