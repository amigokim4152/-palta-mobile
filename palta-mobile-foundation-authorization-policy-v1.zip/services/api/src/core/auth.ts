import type { SessionUser } from '@palta/core';

export interface AuthContext {
  subject: string;
  user: SessionUser;
}

export interface AuthVerifier {
  verifyBearer(token: string): Promise<AuthContext | null>;
}

/**
 * Intentionally strict until a real auth provider is connected.
 * This prevents accidental "dev auth" from reaching production.
 */
export class UnconfiguredAuthVerifier implements AuthVerifier {
  async verifyBearer(_token: string): Promise<AuthContext | null> {
    return null;
  }
}

export async function requireAuth(request: Request, verifier: AuthVerifier): Promise<AuthContext | null> {
  const header = request.headers.get('authorization');
  if (!header?.startsWith('Bearer ')) return null;
  const token = header.slice('Bearer '.length).trim();
  if (!token) return null;
  return verifier.verifyBearer(token);
}
