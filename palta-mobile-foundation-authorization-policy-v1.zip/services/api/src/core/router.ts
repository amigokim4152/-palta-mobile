export type RouteHandler<Env> = (request: Request, env: Env, params: Record<string, string>) => Promise<Response>;

interface Route<Env> {
  method: string;
  pattern: URLPattern;
  handler: RouteHandler<Env>;
}

export class Router<Env> {
  private readonly routes: Route<Env>[] = [];

  on(method: string, pathname: string, handler: RouteHandler<Env>): this {
    this.routes.push({ method: method.toUpperCase(), pattern: new URLPattern({ pathname }), handler });
    return this;
  }

  async dispatch(request: Request, env: Env): Promise<Response | null> {
    const url = new URL(request.url);
    for (const route of this.routes) {
      if (request.method.toUpperCase() !== route.method) continue;
      const match = route.pattern.exec({ pathname: url.pathname });
      if (!match) continue;
      return route.handler(request, env, match.pathname.groups as Record<string, string>);
    }
    return null;
  }
}
