import type { BootstrapPayload } from '@palta/core';
import { fail, ok, requestId } from '../core/http';
import { requireAuth, UnconfiguredAuthVerifier } from '../core/auth';

export async function bootstrap(request: Request): Promise<Response> {
  const rid = requestId(request);
  const auth = await requireAuth(request, new UnconfiguredAuthVerifier());
  if (!auth) {
    return fail('unauthorized', 'Authentication is required.', rid, 401);
  }

  // Real DB-backed bootstrap is connected when PostgreSQL/auth bindings are provisioned.
  const payload: BootstrapPayload = {
    user: auth.user,
    context: {
      personId: auth.user.id,
      locale: 'es-CL',
      timezone: 'America/Santiago',
      locations: [],
      relationships: [],
      lifeObjects: []
    },
    unreadNotificationCount: 0,
    featureFlags: {}
  };
  return ok(payload, rid);
}
