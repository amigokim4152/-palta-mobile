import { ok } from '../core/http';

export async function health(_request: Request, _env: unknown, _params: Record<string, string>): Promise<Response> {
  return ok({ service: 'palta-api', version: '0.2.0', status: 'ready' }, crypto.randomUUID());
}
