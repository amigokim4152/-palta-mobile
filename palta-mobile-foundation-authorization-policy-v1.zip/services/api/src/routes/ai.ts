import { fail, requestId } from '../core/http';

/**
 * AI Gateway contract. No model/provider is hard-coded here.
 * Provider keys stay server-side and requests must be scoped/minimized before model invocation.
 */
export async function aiGateway(request: Request): Promise<Response> {
  const rid = requestId(request);
  if (request.method !== 'POST') return fail('method_not_allowed', 'POST required.', rid, 405);
  return fail('ai_not_configured', 'AI provider routing is not configured yet.', rid, 503);
}
