from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]

checks = []

def require(path, *tokens):
    text = (ROOT / path).read_text(encoding='utf-8')
    missing = [t for t in tokens if t not in text]
    checks.append((path, not missing, missing))

require('infra/sql/002_identity_location_relationships.sql',
        'person_location_context', 'relationship_edge', 'life_object', 'administrative_area', 'person_place')
require('infra/sql/003_events_notifications.sql',
        'palta_event', 'need_candidate', 'action_item', 'action_case', 'case_outcome', 'life_history', 'delivery_projection')
require('infra/sql/005_kernel_hardening.sql',
        'postgis', 'palta_event_target', 'decision', 'action_item_id', 'dedupe_key', 'intake_receipt')
require('infra/sql/006_care_engine.sql',
        'care_item', "'obligation','entitlement','care_need'", 'truth_state', 'schedule_reference', 'care_item_id', 'subject_person_id', 'source_version', 'dedupe_key', 'recurrence_timezone', 'context_kind')
require('infra/sql/007_relationship_access_boundaries.sql',
        'access_grant', 'purpose', 'subject_person_id', 'life_object_relation', 'DEPRECATED for authorization')
require('docs/CARE_ENGINE_V1.md',
        'What Care is not', 'Planned is not completed', 'Relevance before display', 'Calendar rule')
require('docs/API_CONTRACT_V1.md',
        'GET /context', 'GET /care', 'GET /home', 'GET /actions', 'GET /cases/:id', 'GET /local', 'POST /intake', 'GET /search')
require('docs/PALTA_KERNEL_V1_VALIDATED_DESIGN.md',
        'current-location change', 'municipal program', 'school/WhatsApp notice', 'business quote/service', 'local event/performance')

failed = [c for c in checks if not c[1]]
for path, ok, missing in checks:
    print(('OK   ' if ok else 'FAIL ') + path)
    if missing:
        print('     missing:', ', '.join(missing))

if failed:
    sys.exit(1)
print(f'KERNEL VALIDATION OK: {len(checks)} contract groups')
