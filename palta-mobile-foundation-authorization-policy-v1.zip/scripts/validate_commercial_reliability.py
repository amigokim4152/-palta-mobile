#!/usr/bin/env python3
"""Deterministic Commercial/POS reliability checks.
Models command idempotency, transactional outbox, stock reservation,
and reconciliation behavior. This is not a real PostgreSQL concurrency test.
"""
from dataclasses import dataclass, field
from decimal import Decimal
import hashlib, json


def h(payload):
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

@dataclass
class Reliability:
    stock: Decimal = Decimal('10')
    receipts: dict[tuple[str,str], dict] = field(default_factory=dict)
    outbox: dict[str, str] = field(default_factory=dict)
    reservations: dict[str, tuple[Decimal,str]] = field(default_factory=dict)
    issues: list[tuple[str,str]] = field(default_factory=list)

    def command(self, scope, cid, payload, result_ref='O1'):
        key=(scope,cid); rh=h(payload)
        if key in self.receipts:
            old=self.receipts[key]
            if old['hash'] != rh: raise ValueError('idempotency_payload_mismatch')
            return old['result']
        self.receipts[key]={'hash':rh,'status':'applied','result':result_ref}
        return result_ref

    def enqueue(self, key):
        self.outbox.setdefault(key,'pending')

    def deliver(self, key, fail=False):
        if self.outbox[key]=='delivered': return 'delivered'
        if fail:
            self.outbox[key]='failed'; return 'failed'
        self.outbox[key]='delivered'; return 'delivered'

    def available(self):
        active=sum(q for q,s in self.reservations.values() if s=='active')
        return self.stock-active

    def reserve(self, key, qty):
        if key in self.reservations: return self.reservations[key][1]
        if self.available() < qty: raise ValueError('insufficient_available_stock')
        self.reservations[key]=(qty,'active'); return 'active'

    def consume(self, key):
        qty,status=self.reservations[key]
        if status=='consumed': return
        if status!='active': raise ValueError('reservation_not_active')
        self.stock -= qty
        self.reservations[key]=(qty,'consumed')

    def issue(self, kind, ref):
        self.issues.append((kind,ref))


def check(name, fn):
    fn(); print(f'PASS {name}')

def main():
    def ack_loss_retry_returns_same_order():
        x=Reliability(); p={'lines':500,'total':123}
        a=x.command('pos:d1','cmd-1',p,'O500'); b=x.command('pos:d1','cmd-1',p,'O500')
        assert a==b=='O500' and len(x.receipts)==1

    def reused_id_different_payload_rejected():
        x=Reliability(); x.command('pos:d1','cmd-2',{'total':100},'O1')
        try: x.command('pos:d1','cmd-2',{'total':200},'O2')
        except ValueError as e: assert str(e)=='idempotency_payload_mismatch'
        else: raise AssertionError('must reject changed payload under same id')

    def committed_change_has_outbox_work():
        x=Reliability(); x.command('order','cmd-3',{'order':'O3'},'O3'); x.enqueue('order:O3:created')
        assert x.receipts[('order','cmd-3')]['status']=='applied' and x.outbox['order:O3:created']=='pending'

    def outbox_retry_is_safe():
        x=Reliability(); x.enqueue('tax:O4'); assert x.deliver('tax:O4',fail=True)=='failed'
        assert x.deliver('tax:O4')=='delivered' and x.deliver('tax:O4')=='delivered'

    def reservation_blocks_oversell():
        x=Reliability(); x.reserve('r1',Decimal('7'))
        try: x.reserve('r2',Decimal('4'))
        except ValueError as e: assert str(e)=='insufficient_available_stock'
        else: raise AssertionError('oversell must be blocked')
        assert x.available()==Decimal('3')

    def consume_once():
        x=Reliability(); x.reserve('r1',Decimal('4')); x.consume('r1'); x.consume('r1')
        assert x.stock==Decimal('6')

    def db_commit_unknown_is_not_replayed_blindly():
        x=Reliability(); x.issue('db_commit_unknown','cmd-77')
        assert ('db_commit_unknown','cmd-77') in x.issues

    def payment_timeout_stays_unknown():
        x=Reliability(); x.issue('payment_unknown','pay-9')
        # Contract: query/reconcile provider; do not create a second charge automatically.
        assert x.issues[-1]==('payment_unknown','pay-9')

    def tax_timeout_stays_unknown():
        x=Reliability(); x.issue('tax_document_unknown','tax-9')
        # Contract: reconcile with official adapter using same idempotency identity.
        assert x.issues[-1]==('tax_document_unknown','tax-9')

    def stock_conflict_is_reviewable_not_overwritten():
        x=Reliability(); x.issue('sync_conflict','stock:sku@branchA')
        assert x.issues[-1][0]=='sync_conflict' and x.stock==Decimal('10')

    tests=[
        ('ack-loss retry returns same order', ack_loss_retry_returns_same_order),
        ('same id with changed payload is rejected', reused_id_different_payload_rejected),
        ('committed domain change has outbox work', committed_change_has_outbox_work),
        ('outbox delivery retry is safe', outbox_retry_is_safe),
        ('inventory reservation blocks oversell', reservation_blocks_oversell),
        ('inventory reservation consumes once', consume_once),
        ('unknown DB commit enters reconciliation', db_commit_unknown_is_not_replayed_blindly),
        ('payment timeout remains unknown', payment_timeout_stays_unknown),
        ('tax timeout remains unknown', tax_timeout_stays_unknown),
        ('stock conflict is explicit, not overwritten', stock_conflict_is_reviewable_not_overwritten),
    ]
    for n,f in tests: check(n,f)
    print(f'COMMERCIAL RELIABILITY VALIDATION OK: {len(tests)}/{len(tests)}')

if __name__=='__main__': main()
