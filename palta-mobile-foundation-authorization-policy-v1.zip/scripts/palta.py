#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
CANONICAL = ROOT / "data" / "canonical"
SERVING = ROOT / "data" / "serving"
VALID_STATUSES = {
    "verified",
    "corroborated",
    "needs_verification",
    "stale",
    "conflict",
    "rejected",
}


def iter_json_records() -> list[tuple[Path, dict[str, Any]]]:
    records: list[tuple[Path, dict[str, Any]]] = []
    for path in sorted(CANONICAL.rglob("*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        items = payload if isinstance(payload, list) else [payload]
        for item in items:
            if not isinstance(item, dict):
                raise ValueError(f"{path}: every record must be an object")
            records.append((path, item))
    return records


def validate() -> int:
    records = iter_json_records()
    errors: list[str] = []
    ids: set[str] = set()
    for path, item in records:
        required = ("id", "kind", "countryCode", "title", "verificationStatus", "sources", "updatedAt")
        for field in required:
            if field not in item:
                errors.append(f"{path}: missing {field}")
        entity_id = item.get("id")
        if isinstance(entity_id, str):
            if entity_id in ids:
                errors.append(f"{path}: duplicate id {entity_id}")
            ids.add(entity_id)
        if item.get("countryCode") not in (None, "CL"):
            errors.append(f"{path}: countryCode must be CL")
        status = item.get("verificationStatus")
        if status is not None and status not in VALID_STATUSES:
            errors.append(f"{path}: invalid verificationStatus {status}")
        sources = item.get("sources")
        if sources is not None and (not isinstance(sources, list) or len(sources) == 0):
            errors.append(f"{path}: sources must be a non-empty list")

    if errors:
        print("VALIDATION FAILED")
        for error in errors:
            print(f"- {error}")
        return 1

    print(f"VALIDATION OK: {len(records)} canonical records")
    return 0


def build() -> int:
    if validate() != 0:
        return 1
    records = [item for _, item in iter_json_records()]
    SERVING.mkdir(parents=True, exist_ok=True)
    output = SERVING / "local-entities.json"
    output.write_text(json.dumps(records, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"BUILT: {output.relative_to(ROOT)} ({len(records)} records)")
    return 0


def publish() -> int:
    print("PUBLISH BLOCKED: connect PostgreSQL/R2 credentials first; no implicit production writes.")
    return 2


def main() -> int:
    parser = argparse.ArgumentParser(prog="palta")
    parser.add_argument("command", choices=("validate", "build", "publish"))
    args = parser.parse_args()
    if args.command == "validate":
        return validate()
    if args.command == "build":
        return build()
    return publish()


if __name__ == "__main__":
    raise SystemExit(main())
