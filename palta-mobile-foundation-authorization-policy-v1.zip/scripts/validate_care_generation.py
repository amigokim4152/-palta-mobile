"""Deterministic Care generation safety tests. No fixtures are public facts."""

def decide(source, kind, explicit=False, authoritative=False, deterministic_rule=False, ai_extracted=False):
    if explicit:
        return dict(create=True, mode='declared', evidence='user_asserted', review='not_required')
    if authoritative:
        return dict(create=True, mode='source_declared', evidence='authoritative', review='not_required')
    if deterministic_rule and source.get('version') and source.get('locator'):
        return dict(create=True, mode='rule_derived', evidence='source_backed', review='not_required')
    if ai_extracted:
        return dict(create=True, mode='extracted', evidence='unverified', review='required')
    return dict(create=False, mode='proposed', evidence='unverified', review='required')

cases = []
def check(name, cond):
    assert cond, name
    cases.append(name)

r=decide({},'care',explicit=True); check('explicit user care can exist without document proof', r['create'] and r['evidence']=='user_asserted')
r=decide({'locator':'official:x','version':'2026-09'},'entitlement',deterministic_rule=True); check('versioned official rule can derive candidate', r['create'] and r['mode']=='rule_derived')
r=decide({},'obligation',ai_extracted=True); check('AI extraction requires review', r['review']=='required' and r['evidence']=='unverified')
r=decide({},'entitlement'); check('unsupported inference does not create care', not r['create'])
r=decide({'provider':'school'},'care',authoritative=True); check('trusted source declaration preserves authority', r['evidence']=='authoritative')
# A calendar is evidence of a plan, never proof of completion.
truth='planned'; check('calendar plan does not auto-confirm outcome', truth!='confirmed')
# Relationship context never grants visibility by itself.
relationship_exists=True; access_grant=False; check('relationship alone cannot grant access', relationship_exists and not access_grant)
# Government guidance stays external action at current Palta boundary.
actionability='externally_actionable'; check('administrative care links outward, not proxy filing', actionability=='externally_actionable')
print(f'CARE GENERATION VALIDATION OK: {len(cases)}/{len(cases)}')
for c in cases: print('PASS', c)
