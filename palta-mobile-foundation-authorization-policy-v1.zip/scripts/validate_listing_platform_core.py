from pathlib import Path

root = Path(__file__).resolve().parents[1]
core = (root / 'packages/core/src/index.ts').read_text()
doc = (root / 'docs/LISTING_DISTRIBUTION_MONETIZATION_CORE_V1.md').read_text()

checks = []

def check(name, ok):
    checks.append((name, bool(ok)))

check('canonical listing type exists', 'interface CanonicalListingRef' in core)
check('listing core spans required verticals', all(x in core for x in ["'marketplace'", "'auto'", "'real_estate'", "'jobs'", "'local_activity'", "'local_alert'"]))
check('real estate supports venta/arriendo', "'venta' | 'arriendo'" in core)
check('cabana is a property type not separate platform', "'cabin'" in core and 'A cabaña is therefore not a separate platform' in doc)
check('arriendo supports temporary/vacational', all(x in core for x in ["'temporary'", "'vacational'"]))
check('distribution bindings exist', 'interface ListingDistributionBinding' in core and "'external_marketplace'" in core)
check('promotion references existing objects', 'interface PromotionCampaignRef' in core and 'Promotion does not clone domain content' in doc)
check('auto personal policy uses active personal listing concept', 'one active personal vehicle listing' in doc)
check('used goods does not classify by quantity alone', 'quantity alone must never classify' in doc)
check('job reuses business context', 'without re-entering business identity/location' in doc)
check('free quotas are configurable policy', 'must never be encoded in core schema' in doc)
check('professional signals are purpose specific', 'must not become a universal trust score' in doc)
check('imports require authorization/provenance', 'without authorization' in doc and 'preserve provenance' in doc)
check('operational-center acquisition strategy captured', 'first win the operational center, then the traffic' in doc)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' - ' + name)
print(f'\n{len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    raise SystemExit(1)
