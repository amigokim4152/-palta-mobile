from pathlib import Path
p=Path('docs/LOGISTICS_MODULE_V1.md').read_text()
checks={
'core frozen':'Core V1 remains frozen' in p,
'provider neutral':'provider-specific branches' in p,
'quote':'getQuotes' in p,
'create':'createShipment' in p,
'pickup':'requestPickup' in p,
'label':'getLabel' in p,
'cancel':'cancelShipment' in p,
'return':'createReturn' in p,
'tracking':'getTracking' in p,
'webhook':'ingestProviderEvent' in p,
'reconcile':'reconcile(shipment)' in p,
'idempotency':'idempotency key required' in p,
'timeout unknown':'timeout is `unknown`' in p,
'no fake weight':'Never fabricate it' in p,
'known data reuse':'Never ask staff/customer to retype known data' in p,
'commercial integration':'Order -> Fulfillment -> Logistics Shipment' in p,
'device boundary':'Native/Device Adapter' in p,
'registry':'External Integration Registry' in p,
'no credentials':'no real provider credentials' in p,
}
for k,v in checks.items(): print(('OK' if v else 'FAIL'), k)
assert all(checks.values())
print(f'PASS {sum(checks.values())}/{len(checks)}')
