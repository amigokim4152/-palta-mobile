#!/usr/bin/env python3
"""
Contract-level integration simulation for Palta Kernel v1.

These are deterministic test fixtures, not production/public facts.
The purpose is to prove that very different Chile-life scenarios can pass
through the same kernel contracts without creating domain-specific Home,
notification, location, or history engines.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
import json


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class PersonContext:
    person_id: str
    home_area: str
    current_area: str
    habitual_areas: List[str] = field(default_factory=list)
    memberships: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    life_objects: Dict[str, Dict[str, Any]] = field(default_factory=dict)


@dataclass
class KernelEvent:
    event_id: str
    event_type: str
    producer_domain: str
    area: Optional[str] = None
    subject_refs: Dict[str, str] = field(default_factory=dict)
    payload: Dict[str, Any] = field(default_factory=dict)
    urgency: int = 0
    occurred_at: str = field(default_factory=now_iso)


@dataclass
class RelevanceDecision:
    event_id: str
    eligible: bool
    surface: str
    score: int
    reasons: List[str]


def location_relevance(person: PersonContext, event: KernelEvent) -> RelevanceDecision:
    reasons = []
    score = 0
    if event.area and event.area == person.current_area:
        score += 45
        reasons.append("current_area_match")
    if event.area and event.area == person.home_area:
        score += 30
        reasons.append("home_area_match")
    if event.area and event.area in person.habitual_areas:
        score += 20
        reasons.append("habitual_area_match")
    score += min(max(event.urgency, 0), 30)
    if event.urgency:
        reasons.append("urgency")
    surface = "home" if score >= 40 else ("inbox" if score >= 20 else "history_only")
    return RelevanceDecision(event.event_id, score > 0, surface, score, reasons)


def scenario_location_switch() -> dict:
    person = PersonContext(
        person_id="p1",
        home_area="vitacura",
        current_area="vitacura",
        habitual_areas=["providencia"],
    )
    before = person.current_area
    person.current_area = "algarrobo"
    # Residence-based jurisdiction intentionally remains unchanged.
    assert person.home_area == "vitacura"
    assert person.current_area == "algarrobo"
    return {
        "scenario": "location_switch",
        "status": "PASS",
        "before_current_area": before,
        "after_current_area": person.current_area,
        "home_jurisdiction_preserved": person.home_area,
        "contract": "current context changes; residence/jurisdiction does not"
    }


def scenario_municipal_program() -> dict:
    person = PersonContext(
        person_id="p2",
        home_area="vitacura",
        current_area="algarrobo",
    )
    resident_only = {
        "program_id": "fixture_program_vitacura_resident",
        "area": "vitacura",
        "eligibility_relationship": "residence",
    }
    current_area_event = {
        "program_id": "fixture_program_algarrobo_current",
        "area": "algarrobo",
        "eligibility_relationship": "current_location",
    }

    resident_eligible = (
        resident_only["eligibility_relationship"] == "residence"
        and resident_only["area"] == person.home_area
    )
    current_eligible = (
        current_area_event["eligibility_relationship"] == "current_location"
        and current_area_event["area"] == person.current_area
    )

    assert resident_eligible is True
    assert current_eligible is True
    return {
        "scenario": "municipal_program",
        "status": "PASS",
        "resident_program_uses": "home_area",
        "temporary_local_program_uses": "current_area",
        "contract": "administrative eligibility and current-life relevance remain separate"
    }


def scenario_school_intake() -> dict:
    person = PersonContext(
        person_id="p3",
        home_area="vitacura",
        current_area="vitacura",
        memberships={
            "school-class-2A": {
                "type": "school_class",
                "status": "active",
                "grants": ["announcements", "schedule"],
            }
        },
    )
    # Test fixture emulating a user-shared WhatsApp notice.
    intake = {
        "source_type": "whatsapp",
        "raw_text": "Mañana traer polera blanca. Reunión de apoderados a las 18:00.",
        "scope": "school-class-2A",
    }
    membership = person.memberships.get(intake["scope"])
    assert membership and membership["status"] == "active"

    extracted = {
        "materials": ["polera blanca"],
        "actions": ["bring_material", "attend_parent_meeting"],
        "time": "18:00",
    }
    event = KernelEvent(
        event_id="evt_school_1",
        event_type="SCHOOL_NOTICE_STRUCTURED",
        producer_domain="education",
        subject_refs={"membership_scope": intake["scope"]},
        payload=extracted,
        urgency=15,
    )
    action = {
        "action_id": "act_school_1",
        "event_id": event.event_id,
        "owner_person_id": person.person_id,
        "status": "open",
        "action_type": "prepare_and_attend",
    }
    assert action["event_id"] == event.event_id
    return {
        "scenario": "school_whatsapp_intake",
        "status": "PASS",
        "pipeline": ["intake", "membership-check", "structured-event", "action"],
        "important_boundary": "shared message is intake evidence; extraction does not become official truth automatically"
    }


def scenario_business_service_history() -> dict:
    person = PersonContext(
        person_id="p4",
        home_area="vitacura",
        current_area="vitacura",
        life_objects={
            "veh_1": {"kind": "vehicle", "title": "My vehicle", "status": "active"}
        },
    )
    action = {
        "action_id": "act_quote_1",
        "owner_person_id": person.person_id,
        "life_object_id": "veh_1",
        "action_type": "request_quote",
        "status": "completed",
    }
    case = {
        "case_id": "case_service_1",
        "action_id": action["action_id"],
        "status": "completed_by_provider",
        "provider_id": "fixture_business_1",
    }
    outcome = {
        "outcome_id": "out_service_1",
        "case_id": case["case_id"],
        "status": "user_confirmed",
        "summary": "service completed",
    }
    history = {
        "history_id": "hist_vehicle_1",
        "owner_person_id": person.person_id,
        "life_object_id": action["life_object_id"],
        "outcome_id": outcome["outcome_id"],
        "history_type": "maintenance",
    }

    assert case["action_id"] == action["action_id"]
    assert outcome["status"] == "user_confirmed"
    assert history["life_object_id"] in person.life_objects
    return {
        "scenario": "business_quote_to_history",
        "status": "PASS",
        "pipeline": ["action", "case", "provider-complete", "user-confirm", "life-history"],
        "important_boundary": "provider cannot finalize the person's private history unilaterally"
    }


def scenario_local_event_projection() -> dict:
    person = PersonContext(
        person_id="p5",
        home_area="vitacura",
        current_area="algarrobo",
    )
    event = KernelEvent(
        event_id="evt_local_fixture",
        event_type="LOCAL_CULTURE_EVENT",
        producer_domain="local",
        area="algarrobo",
        payload={"category": "culture", "fixture": True},
        urgency=5,
    )
    decision_here = location_relevance(person, event)
    assert decision_here.surface == "home"

    person.current_area = "vitacura"
    decision_away = location_relevance(person, event)
    assert decision_away.surface == "history_only"

    return {
        "scenario": "local_event_projection",
        "status": "PASS",
        "when_in_algarrobo": decision_here.__dict__,
        "after_return_to_vitacura": decision_away.__dict__,
        "contract": "event remains canonical; only its personal projection changes"
    }


def scenario_household_salary_obligation() -> dict:
    relationship = {
        "relationship_id": "rel_household_help_1",
        "person_id": "p6",
        "target_person": "fixture_maria",
        "relation_type": "household_help",
    }
    care = {
        "care_id": "care_salary_1",
        "person_id": relationship["person_id"],
        "care_kind": "obligation",
        "relationship_id": relationship["relationship_id"],
        "source_kind": "user",
        "title": "recurring household payment",
        "status": "active",
        "due": "monthly",
    }
    assert care["care_kind"] == "obligation"
    assert "employment_status" not in relationship
    assert "termination" not in care
    return {
        "scenario": "household_salary_obligation",
        "status": "PASS",
        "pipeline": ["relationship-context", "obligation", "due-reminder", "optional-action"],
        "contract": "Palta can remember the payment without becoming an employment/legal authority",
    }


def scenario_benefit_entitlement() -> dict:
    person_context = {"person_id": "p7", "home_area": "fixture_comuna", "age_band": "adult"}
    program = {
        "program_id": "fixture_benefit_1",
        "eligible_area": "fixture_comuna",
        "rule_result": "candidate",
    }
    care = {
        "care_id": "care_benefit_1",
        "person_id": person_context["person_id"],
        "care_kind": "entitlement",
        "confidence": "candidate",
        "actionability": "externally_actionable",
    }
    assert program["eligible_area"] == person_context["home_area"]
    assert care["care_kind"] == "entitlement"
    assert care["confidence"] == "candidate"
    return {
        "scenario": "benefit_entitlement",
        "status": "PASS",
        "pipeline": ["context", "eligibility-rule", "entitlement-candidate", "relevance", "apply-link"],
        "contract": "possible eligibility can be surfaced without claiming an unverified entitlement as fact",
    }


def scenario_planned_pickup_not_auto_confirmed() -> dict:
    event = {
        "event_id": "evt_pickup_1",
        "event_type": "CHILD_PICKUP",
        "truth_state": "planned",
        "starts_at": "2026-09-14T16:00:00-03:00",
    }
    # Time passing alone is intentionally not a confirmation source.
    after_time_passed = dict(event)
    assert after_time_passed["truth_state"] == "planned"
    confirmed = dict(event)
    confirmed["truth_state"] = "confirmed"
    confirmed["confirmation_source"] = "explicit_fixture_confirmation"
    assert confirmed["truth_state"] == "confirmed"
    return {
        "scenario": "planned_pickup_truth_boundary",
        "status": "PASS",
        "before_confirmation": after_time_passed["truth_state"],
        "after_explicit_confirmation": confirmed["truth_state"],
        "contract": "schedule time passing does not invent real-world completion",
    }


def scenario_care_to_business_action() -> dict:
    care = {
        "care_id": "care_vehicle_repair_1",
        "person_id": "p8",
        "care_kind": "care_need",
        "life_object_id": "veh_fixture_8",
        "title": "vehicle repair needed",
    }
    action = {
        "action_id": "act_vehicle_quote_8",
        "care_item_id": care["care_id"],
        "action_type": "request_quote",
        "domain": "business",
    }
    assert action["care_item_id"] == care["care_id"]
    return {
        "scenario": "care_to_business_action",
        "status": "PASS",
        "pipeline": ["care-need", "relevance", "business-match", "quote-action"],
        "contract": "domain capability is invoked because Care found a need; the domain is not the starting point",
    }


def scenario_real_estate_care_flow() -> dict:
    current_home = {"life_object_id": "home_fixture_1", "object_type": "home"}
    care = {
        "care_id": "care_move_1",
        "person_id": "p9",
        "care_kind": "care_need",
        "life_object_id": current_home["life_object_id"],
        "context_kind": "property_search",
        "context_ref": "search_fixture_1",
        "title": "compare a possible move",
    }
    action = {"action_type": "compare_properties", "care_item_id": care["care_id"], "domain": "real_estate"}
    planned_visit = {"truth_state": "planned", "event_type": "PROPERTY_VISIT"}
    assert action["domain"] == "real_estate"
    assert planned_visit["truth_state"] == "planned"
    return {
        "scenario": "real_estate_care_flow",
        "status": "PASS",
        "pipeline": ["life-context", "care-need", "property-compare", "planned-visit", "confirmed-move-only-updates-home-context"],
        "contract": "property browsing is specialist capability; Care invokes it and only a confirmed move changes durable home context",
    }


def scenario_auto_obligation_responsibility() -> dict:
    vehicle = {"life_object_id": "veh_fixture_10", "legal_owner": "other_person", "maintenance_responsible": "p10"}
    care = {
        "care_id": "care_vehicle_due_10",
        "person_id": vehicle["maintenance_responsible"],
        "care_kind": "obligation",
        "life_object_id": vehicle["life_object_id"],
        "source_kind": "rule",
        "source_ref": "fixture_vehicle_rule",
        "source_version": "fixture-v1",
        "dedupe_key": "vehicle:veh_fixture_10:fixture_vehicle_rule:2026",
    }
    assert care["person_id"] != vehicle["legal_owner"]
    assert care["dedupe_key"]
    return {
        "scenario": "auto_obligation_responsibility",
        "status": "PASS",
        "pipeline": ["vehicle-relation", "rule", "obligation", "relevance", "action"],
        "contract": "the person responsible for the vehicle can be reminded even when legal ownership differs",
    }


def scenario_school_subject_person_boundary() -> dict:
    care = {
        "care_id": "care_school_11",
        "person_id": "parent_fixture_11",
        "subject_person_id": "child_fixture_11",
        "care_kind": "care_need",
        "domain": "education",
        "title": "prepare school materials",
    }
    assert care["person_id"] != care["subject_person_id"]
    return {
        "scenario": "school_subject_person_boundary",
        "status": "PASS",
        "pipeline": ["school-source", "child-subject", "parent-care-surface", "prepare-action"],
        "contract": "Palta can help a parent care for a child's school need without collapsing parent and child identities",
    }


def scenario_public_benefit_provenance() -> dict:
    care = {
        "care_id": "care_program_12",
        "person_id": "p12",
        "care_kind": "entitlement",
        "context_kind": "policy_program",
        "context_ref": "fixture_program_12",
        "source_kind": "rule",
        "source_ref": "fixture_official_source",
        "source_version": "2026-09-fixture",
        "source_valid_until": "2026-09-30T23:59:59-03:00",
        "confidence": "candidate",
        "dedupe_key": "program:fixture_program_12:p12:2026-09",
    }
    assert care["confidence"] == "candidate"
    assert care["source_version"] and care["dedupe_key"]
    return {
        "scenario": "public_benefit_provenance",
        "status": "PASS",
        "pipeline": ["official-source", "versioned-rule", "entitlement-candidate", "relevance", "application-action"],
        "contract": "eligibility candidates remain traceable to a versioned source and retry safely without duplication",
    }


def scenario_business_owner_care_context() -> dict:
    care = {
        "care_id": "care_business_13",
        "person_id": "owner_fixture_13",
        "care_kind": "obligation",
        "domain": "business",
        "context_kind": "business",
        "context_ref": "business_fixture_13",
        "title": "review a business operational deadline",
    }
    action = {"care_item_id": care["care_id"], "domain": "business", "action_type": "open_business_task"}
    assert care["context_kind"] == "business"
    assert action["care_item_id"] == care["care_id"]
    return {
        "scenario": "business_owner_care_context",
        "status": "PASS",
        "pipeline": ["business-context", "owner-care", "relevance", "business-action"],
        "contract": "Business remains a platform domain while the owner's Palta can surface what needs attention without turning Care into a business back office",
    }


SCENARIOS = [
    scenario_location_switch,
    scenario_municipal_program,
    scenario_school_intake,
    scenario_business_service_history,
    scenario_local_event_projection,
    scenario_household_salary_obligation,
    scenario_benefit_entitlement,
    scenario_planned_pickup_not_auto_confirmed,
    scenario_care_to_business_action,
    scenario_real_estate_care_flow,
    scenario_auto_obligation_responsibility,
    scenario_school_subject_person_boundary,
    scenario_public_benefit_provenance,
    scenario_business_owner_care_context,
]


def main() -> int:
    results = []
    for fn in SCENARIOS:
        try:
            results.append(fn())
        except Exception as exc:
            results.append({
                "scenario": fn.__name__,
                "status": "FAIL",
                "error": f"{type(exc).__name__}: {exc}",
            })

    passed = sum(1 for x in results if x["status"] == "PASS")
    report = {
        "suite": "palta_kernel_v1_contract_simulation",
        "fixture_notice": "No fixture in this simulation should be presented as live Chilean public data.",
        "passed": passed,
        "total": len(results),
        "results": results,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
