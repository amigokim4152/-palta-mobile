from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
text=(ROOT/'packages/core/src/security.ts').read_text(encoding='utf-8')
required=[
 'operator_ai_private_forbidden','operator_ai_individual_analytics_forbidden','work_context_required',
 'work_context_scope_mismatch','break_glass_review_required','resource_owner_required',
 'facts.workContextOpen','facts.isWorkParticipant','facts.workPurposeMatches','facts.analyticsAggregateOnly'
]
missing=[x for x in required if x not in text]
if missing:
 print('FAIL authorization policy missing:', ', '.join(missing)); sys.exit(1)
# Guard against future accidental permissive shortcuts in this policy module.
forbidden=['return { decision: \'allow\', reasonCode: \'allow_all\'', 'req.actor === \'operator_ai\' && true']
found=[x for x in forbidden if x in text]
if found:
 print('FAIL permissive authorization shortcut:', ', '.join(found)); sys.exit(1)
print('AUTHORIZATION POLICY CONTRACT OK: deterministic private/work/analytics boundaries present')
