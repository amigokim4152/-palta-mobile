#!/usr/bin/env python3
"""Deterministic checks for representative Chile business capability coverage."""

registered = {
    "booking", "quote", "field_service", "retail", "wholesale", "restaurant",
    "kitchen_kds", "delivery", "staff_operations", "multi_location", "crm_loyalty",
    "tax_document", "payment_adapter", "opportunity_tender", "business_messaging", "reporting",
    "lot_expiry", "production_batch", "recipe_bom", "storage_condition"
}

industry = {
    "kiosk": {"retail", "tax_document"},
    "minimarket": {"retail"},
    "clothing_retail": {"retail"},
    "clothing_wholesale": {"wholesale"},
    "imported_food_wholesale": {"wholesale", "lot_expiry", "storage_condition", "tax_document"},
    "fresh_food_distributor": {"wholesale", "lot_expiry", "storage_condition"},
    "bakery": {"retail", "production_batch", "recipe_bom", "lot_expiry"},
    "cafe": {"retail", "restaurant"},
    "restaurant": {"restaurant", "kitchen_kds", "recipe_bom"},
    "fast_food": {"restaurant", "kitchen_kds", "retail"},
    "catering": {"quote", "booking", "production_batch", "delivery"},
    "beauty": {"booking", "staff_operations"},
    "massage": {"booking", "staff_operations"},
    "gym": {"booking", "staff_operations"},
    "academy": {"booking", "staff_operations"},
    "auto_workshop": {"quote", "booking", "field_service"},
    "auto_parts": {"retail", "field_service"},
    "electronics_repair": {"retail", "quote", "field_service"},
    "hvac": {"quote", "field_service", "booking"},
    "window_film": {"wholesale", "quote", "field_service"},
    "hardware": {"retail", "wholesale"},
    "furniture": {"retail", "delivery"},
    "pet_shop": {"retail"},
    "veterinary_commercial": {"booking", "retail"},
    "optician_commercial": {"retail", "booking"},
    "hotel_commercial": {"booking", "payment_adapter", "tax_document"},
    "courier": {"delivery", "staff_operations"},
    "warehouse_distributor": {"wholesale", "multi_location"},
    "small_manufacturer": {"production_batch", "recipe_bom", "wholesale"},
    "multi_branch_chain": {"multi_location", "staff_operations", "reporting"},
}

checks = []
def check(name, cond): checks.append((name, bool(cond)))

check("all_industry_modules_registered", all(v <= registered for v in industry.values()))
check("coverage_at_least_30_profiles", len(industry) >= 30)
check("food_import_has_lot_expiry", "lot_expiry" in industry["imported_food_wholesale"])
check("food_import_has_storage_condition", "storage_condition" in industry["imported_food_wholesale"])
check("food_import_has_tax_document", "tax_document" in industry["imported_food_wholesale"])
check("bakery_has_batch_genealogy", "production_batch" in industry["bakery"])
check("bakery_has_recipe_bom", "recipe_bom" in industry["bakery"])
check("restaurant_has_kds_but_cafe_need_not", "kitchen_kds" in industry["restaurant"] and "kitchen_kds" not in industry["cafe"])
check("wholesale_not_forced_on_kiosk", "wholesale" not in industry["kiosk"])
check("lot_expiry_not_forced_on_general_retail", "lot_expiry" not in industry["clothing_retail"])
check("field_service_for_installation", "field_service" in industry["hvac"] and "field_service" in industry["window_film"])
check("wholesale_for_window_film_distribution", "wholesale" in industry["window_film"])
check("booking_for_time_based_services", all("booking" in industry[x] for x in ["beauty","massage","gym","academy"]))
check("multi_location_for_distributor", "multi_location" in industry["warehouse_distributor"])
check("production_not_forced_on_distributor", "production_batch" not in industry["warehouse_distributor"])
check("hotel_current_surface_stays_commercial", industry["hotel_commercial"] <= registered)
check("veterinary_commercial_does_not_encode_clinical_module", all("clinical" not in x for x in industry["veterinary_commercial"]))
check("optician_commercial_does_not_encode_health_module", all("health" not in x for x in industry["optician_commercial"]))
check("payment_adapter_not_forced_on_all", sum("payment_adapter" in v for v in industry.values()) < len(industry))
check("tax_document_not_equated_with_pos_everywhere", sum("tax_document" in v for v in industry.values()) < len(industry))

failed=[n for n,ok in checks if not ok]
for n,ok in checks:
    print(f"{'PASS' if ok else 'FAIL'} {n}")
print(f"\nCommercial industry matrix: {len(checks)-len(failed)}/{len(checks)} PASS across {len(industry)} profiles")
if failed:
    raise SystemExit(1)
