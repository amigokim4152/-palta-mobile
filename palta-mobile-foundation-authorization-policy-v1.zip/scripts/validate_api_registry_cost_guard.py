from pathlib import Path
p=Path('docs/API_REGISTRY_COST_GUARD_V1.md').read_text()
g=Path('docs/EXTERNAL_INTEGRATION_GATEWAY_V1.md').read_text()
checks={
'registry identity':'provider/integration id' in p,
'integration classes':'data_supply' in p and 'transaction' in p,
'secret refs':'secret reference only' in p,
'cost metrics':'actual calls' in p and 'projected month-end spend' in p,
'budget states':'blocked_noncritical' in p,
'no stale transaction':'no stale confirmation' in p,
'unknown reconcile':'unknown' in p and 'reconcile' in p,
'webhook preference':'webhook/event' in p,
'shared dedupe':'Deduplicate shared reads' in p,
'freshness static':'`static`' in p,
'freshness live':'`live`' in p,
'authoritative transaction':'`authoritative_transaction`' in p,
'fallback snapshots':'R2 snapshot' in p and 'device cache' in p,
'observability':'cache-hit ratio' in p and 'latency/error rate' in p,
'future municipality':'Municipalidad' in p,
'future transport':'DTPM' in p,
'future travel':'travel supplier' in p,
'future logistics':'courier' in p,
'gateway binding':'API_REGISTRY_COST_GUARD_V1.md' in g and 'bypassing the registry are non-compliant' in g,
'no hardcoded provider price':'no provider prices are hard-coded into Core' in p,
}
for k,v in checks.items(): print(('OK' if v else 'FAIL'), k)
assert all(checks.values())
print(f'PASS {sum(checks.values())}/{len(checks)}')
