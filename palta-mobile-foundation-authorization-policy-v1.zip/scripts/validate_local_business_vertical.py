from pathlib import Path
p = Path('docs/LOCAL_BUSINESS_VERTICAL_V1.md')
t = p.read_text()
checks = {
 'free_is_useful': 'Free profile may support' in t and 'deliberately degraded' in t,
 'storefront_and_service_area': '`storefront`' in t and '`service_area`' in t,
 'sparse_area_expansion': 'Sparse areas may widen' in t,
 'parking_detail': 'own_free' in t and 'nearby parking place reference' in t,
 'seasonal_hours': 'seasonal hours' in t and 'last-verified provenance' in t,
 'community_separation': 'official business content' in t and 'community photos/reviews' in t,
 'quote_routing': 'eligible providers -> proposals -> comparison' in t,
 'contact_privacy': 'Contact details stay limited' in t,
 'paid_not_rank': 'payment never buys organic rank' in t,
 'sponsored_label': 'Patrocinado' in t,
 'badge_not_purchasable': 'non-purchasable' in t,
 'moderation_audit': 'append-only/auditable history' in t,
 'negative_review_protected': 'legitimate negative experience is not abuse' in t,
 'multilingual_source_preserved': 'Translation never replaces the source text' in t,
 'engagement_loop': 'profile views, directions, favorites' in t,
 'map_home_connection': 'Event cards can open Map' in t,
 'no_fake_address': 'no fake physical address requirement' in t,
 'no_forced_pos': 'no forced POS adoption' in t,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
assert all(checks.values())
print(f'PASS {len(checks)}/{len(checks)} local business vertical contracts')
