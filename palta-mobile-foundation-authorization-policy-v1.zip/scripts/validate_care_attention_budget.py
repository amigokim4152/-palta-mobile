#!/usr/bin/env python3
"""Deterministic Care/Relevance overload tests. Fixtures only; no live Chile data."""
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

NOW = datetime(2026, 9, 14, 16, 0, tzinfo=timezone(timedelta(hours=-3)))

@dataclass
class Care:
    key: str; kind: str; due_hours: int|None; consequence: int; actionability: int
    direct: int; changed: int=0; handled: bool=False; dismissed: bool=False
    expires_hours: int|None=None; confidence: str='confirmed'; repeat_value: int=0


def rank(c: Care):
    if c.handled or c.dismissed: return ('store_only', -999)
    if c.expires_hours is not None and c.expires_hours < 0: return ('store_only', -999)
    if c.confidence == 'candidate' and c.kind == 'entitlement':
        # candidates can surface, but never outrank a confirmed near-term duty solely on possibility.
        confidence_penalty = 15
    else: confidence_penalty = 0
    due = 0
    if c.due_hours is not None:
        if c.due_hours <= 24: due = 45
        elif c.due_hours <= 72: due = 32
        elif c.due_hours <= 168: due = 20
        elif c.due_hours <= 720: due = 8
    score = due + c.consequence + c.actionability + c.direct + c.changed + c.repeat_value - confidence_penalty
    surface = 'home_primary' if score >= 70 else 'home_secondary' if score >= 45 else 'inbox' if score >= 25 else 'store_only'
    return surface, score


def compose(items, primary_cap=3, secondary_cap=5):
    ranked = sorted(((rank(x)[1], x, rank(x)[0]) for x in items), reverse=True, key=lambda z:z[0])
    primary=[]; secondary=[]; inbox=[]; stored=[]
    for score,item,surface in ranked:
        if surface=='home_primary' and len(primary)<primary_cap: primary.append(item.key)
        elif surface in ('home_primary','home_secondary') and len(secondary)<secondary_cap: secondary.append(item.key)
        elif surface!='store_only': inbox.append(item.key)
        else: stored.append(item.key)
    return primary, secondary, inbox, stored


def test_many_children_many_items():
    items=[]
    for child in range(1,4):
        items += [Care(f'child{child}_routine_notice','care_need',120,5,5,10), Care(f'child{child}_material_tomorrow','care_need',18,15,15,15)]
    items += [Care('vehicle_renewal','obligation',48,25,15,10), Care('possible_benefit','entitlement',240,10,10,10,confidence='candidate')]
    p,s,i,st=compose(items)
    assert len(p)<=3 and len(s)<=5
    assert 'vehicle_renewal' in p+s
    assert all(not x.endswith('routine_notice') for x in p)
    return True

def test_history_does_not_flood_home():
    items=[Care(f'purchase_{i}','care_need',None,0,0,2,repeat_value=2) for i in range(20)]
    p,s,i,st=compose(items)
    assert not p and not s and not i and len(st)==20
    return True

def test_handled_disappears_from_active_surface():
    x=Care('paid_fee','obligation',3,30,20,10,handled=True)
    assert rank(x)[0]=='store_only'
    return True

def test_candidate_benefit_not_claimed_as_priority_truth():
    benefit=Care('possible_benefit','entitlement',48,20,10,10,confidence='candidate')
    duty=Care('confirmed_school_deadline','obligation',48,20,10,10,confidence='confirmed')
    assert rank(duty)[1] > rank(benefit)[1]
    return True

def test_expired_item_suppressed():
    x=Care('expired_offer','entitlement',None,20,10,10,expires_hours=-1)
    assert rank(x)[0]=='store_only'
    return True

def test_attention_budget_under_stress():
    items=[Care(f'urgent_{i}','obligation',12,25,20,15) for i in range(12)]
    p,s,i,st=compose(items)
    assert len(p)==3 and len(s)==5 and len(i)==4
    return True

TESTS=[test_many_children_many_items,test_history_does_not_flood_home,test_handled_disappears_from_active_surface,test_candidate_benefit_not_claimed_as_priority_truth,test_expired_item_suppressed,test_attention_budget_under_stress]
if __name__=='__main__':
    passed=0
    for t in TESTS:
        t(); passed+=1; print('PASS', t.__name__)
    print(f'CARE ATTENTION VALIDATION OK: {passed}/{len(TESTS)}')
