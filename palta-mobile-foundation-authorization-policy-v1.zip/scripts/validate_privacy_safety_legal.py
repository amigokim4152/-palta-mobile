from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def req(path,*tokens):
    text=(ROOT/path).read_text(encoding='utf-8')
    missing=[x for x in tokens if x not in text]
    checks.append((path,not missing,missing))
req('infra/sql/012_privacy_operator_safety.sql','work_context','privacy_access_decision','analytics_subject','aggregate_release_policy','moderation_case','moderation_action','security_incident')
req('docs/PRIVACY_SECURITY_ENGINE_V1.md','no generic person/private search tool','minimum cohort suppression','Maintenance without content inspection','Exceptional access')
req('docs/TRUST_SAFETY_ENGINE_V1.md','human review','appeal','reported item/case evidence','does not create authorization')
req('docs/LEGAL_MATRIX_V1.md','Municipality/public information','Palta payment/escrow','Child/caregiving','Health personalization','Every new capability declares a matrix row')
req('packages/core/src/index.ts','DataRealm','AccessRequest','AccessResult','ModerationCaseRef')
for p,ok,missing in checks:
    print(('OK   ' if ok else 'FAIL ')+p)
    if missing: print('     missing:',', '.join(missing))
if not all(x[1] for x in checks): sys.exit(1)
print(f'PRIVACY/SAFETY/LEGAL VALIDATION OK: {len(checks)} contract groups')
