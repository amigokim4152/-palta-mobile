#!/usr/bin/env python3
"""Deterministic Commercial/POS load-safety contract tests.
No production DB is required; this validates invariants before live PostgreSQL load testing.
"""
from dataclasses import dataclass, field
from decimal import Decimal

@dataclass
class Store:
    orders: dict = field(default_factory=dict)
    stock: dict = field(default_factory=lambda: {"sku": 100000})

    def submit(self, key: str, qtys: list[int], fail_after: int | None = None):
        # idempotency: same client transaction never creates a second order
        if key in self.orders:
            return self.orders[key]
        before = self.stock["sku"]
        staged = 0
        try:
            for i, q in enumerate(qtys, 1):
                staged += q
                if fail_after and i == fail_after:
                    raise RuntimeError("simulated transaction failure")
            if staged > before:
                raise ValueError("insufficient stock")
            self.stock["sku"] = before - staged
            order = {"key": key, "items": len(qtys), "qty": staged, "total": Decimal(staged) * Decimal("1000")}
            self.orders[key] = order
            return order
        except Exception:
            # atomic rollback contract
            self.stock["sku"] = before
            raise

def check(name, fn):
    try:
        fn(); print(f"PASS {name}"); return True
    except Exception as e:
        print(f"FAIL {name}: {e}"); return False

def main():
    tests=[]
    for n in (500,1000,5000):
        def t(n=n):
            s=Store(); o=s.submit(f"bulk-{n}",[1]*n)
            assert o["items"]==n and o["qty"]==n and s.stock["sku"]==100000-n
        tests.append((f"bulk_{n}_items",t))
    def duplicate():
        s=Store(); a=s.submit("same",[1]*500); stock=s.stock["sku"]; b=s.submit("same",[1]*500)
        assert a is b and len(s.orders)==1 and s.stock["sku"]==stock
    tests.append(("duplicate_retry_idempotent",duplicate))
    def rollback():
        s=Store(); before=s.stock["sku"]
        try: s.submit("fail",[1]*1000,fail_after=470)
        except RuntimeError: pass
        else: raise AssertionError("failure not raised")
        assert not s.orders and s.stock["sku"]==before
    tests.append(("transaction_failure_rolls_back",rollback))
    def offline_replay():
        s=Store(); queue=[("a",[1]*500),("b",[1]*1000),("a",[1]*500)]
        for k,items in queue: s.submit(k,items)
        assert len(s.orders)==2 and s.stock["sku"]==98500
    tests.append(("offline_queue_replay_no_duplicate",offline_replay))
    def concurrent_keys():
        s=Store()
        for i in range(20): s.submit(f"pos-{i}",[1]*500)
        assert len(s.orders)==20 and s.stock["sku"]==90000
    tests.append(("multi_pos_distinct_transactions",concurrent_keys))
    passed=sum(check(n,f) for n,f in tests)
    print(f"RESULT {passed}/{len(tests)} PASS")
    raise SystemExit(0 if passed==len(tests) else 1)
if __name__=='__main__': main()
