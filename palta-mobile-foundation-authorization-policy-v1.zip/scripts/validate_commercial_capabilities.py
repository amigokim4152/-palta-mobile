#!/usr/bin/env python3
"""Deterministic architecture checks for Palta Commercial capability boundaries."""

checks = []

def check(name, cond):
    checks.append((name, bool(cond)))

shared_core = {
    "person", "location", "privacy", "access", "audit", "verification",
    "notification", "search", "map", "provenance"
}
commercial_core = {
    "catalog", "price", "inventory", "customer_ref", "order", "order_line",
    "fulfillment", "sale", "return", "commercial_case", "idempotency"
}
capabilities = {
    "booking", "quote", "field_service", "retail", "wholesale", "restaurant",
    "kitchen_kds", "delivery", "staff_operations", "multi_location", "crm_loyalty",
    "tax_document", "payment_adapter", "opportunity_tender", "business_messaging", "reporting"
}

check("restaurant_is_not_shared_core", "restaurant" not in shared_core)
check("kds_is_not_commercial_core", "kitchen_kds" not in commercial_core)
check("order_is_commercial_core", "order" in commercial_core)
check("booking_is_optional_capability", "booking" in capabilities)
check("wholesale_is_optional_capability", "wholesale" in capabilities)
check("quote_field_service_are_separate_capabilities", {"quote", "field_service"}.issubset(capabilities))
check("tender_is_business_capability_not_shared", "opportunity_tender" in capabilities and "opportunity_tender" not in shared_core)
check("payment_is_adapter_boundary", "payment_adapter" in capabilities and "payment" not in commercial_core)
check("multi_location_and_staff_are_explicit", {"multi_location", "staff_operations"}.issubset(capabilities))
check("tax_document_is_country_adapter_capability", "tax_document" in capabilities and "tax_document" not in shared_core)

# Representative industry combinations: all must reuse Commercial Core and only add capabilities.
industry = {
    "small_cafe": {"retail"},
    "restaurant": {"restaurant", "kitchen_kds"},
    "massage": {"booking"},
    "aircon": {"quote", "field_service"},
    "retail_store": {"retail"},
    "clothing_wholesale": {"wholesale"},
}
check("industry_examples_use_only_registered_capabilities",
      all(v <= capabilities for v in industry.values()))

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'} {name}")
print(f"\nCommercial capability contracts: {len(checks)-len(failed)}/{len(checks)} PASS")
if failed:
    raise SystemExit(1)
