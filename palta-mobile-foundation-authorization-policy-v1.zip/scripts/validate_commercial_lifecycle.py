#!/usr/bin/env python3
"""Deterministic Commercial Core lifecycle checks.
Not a substitute for PostgreSQL execution/load tests.
"""
from dataclasses import dataclass, field
from decimal import Decimal

@dataclass
class Order:
    key: str
    state: str = 'accepted'
    stock_applied: bool = False
    payment_status: str = 'pending'
    tax_status: str = 'pending'

@dataclass
class Ledger:
    stock: dict[str, Decimal] = field(default_factory=lambda: {'sku': Decimal('100')})
    order_by_key: dict[str, Order] = field(default_factory=dict)
    movement_keys: set[str] = field(default_factory=set)
    payment_keys: set[str] = field(default_factory=set)
    tax_keys: set[str] = field(default_factory=set)
    return_keys: set[str] = field(default_factory=set)

    def create_order(self, key: str) -> Order:
        return self.order_by_key.setdefault(key, Order(key))

    def apply_sale(self, order: Order, qty: Decimal):
        k = f'sale:{order.key}:sku'
        if k in self.movement_keys:
            return
        if self.stock['sku'] < qty:
            raise ValueError('insufficient_stock')
        self.stock['sku'] -= qty
        self.movement_keys.add(k)
        order.stock_applied = True

    def payment(self, order: Order, request_key: str, status: str):
        if request_key in self.payment_keys:
            return
        self.payment_keys.add(request_key)
        order.payment_status = status

    def tax(self, order: Order, request_key: str, status: str):
        if request_key in self.tax_keys:
            return
        self.tax_keys.add(request_key)
        order.tax_status = status

    def return_stock(self, order: Order, return_key: str, qty: Decimal, disposition: str):
        if return_key in self.return_keys:
            return
        self.return_keys.add(return_key)
        if disposition == 'restock':
            k = f'return:{return_key}:sku'
            if k not in self.movement_keys:
                self.stock['sku'] += qty
                self.movement_keys.add(k)


def check(name, fn):
    fn(); print(f'PASS {name}')


def main():
    def retry_order():
        x=Ledger(); a=x.create_order('A'); b=x.create_order('A'); assert a is b and len(x.order_by_key)==1
    def stock_once():
        x=Ledger(); o=x.create_order('A'); x.apply_sale(o, Decimal('3')); x.apply_sale(o, Decimal('3')); assert x.stock['sku']==Decimal('97')
    def payment_retry():
        x=Ledger(); o=x.create_order('A'); x.payment(o,'pay-1','captured'); x.payment(o,'pay-1','captured'); assert len(x.payment_keys)==1 and o.payment_status=='captured'
    def tax_independent():
        x=Ledger(); o=x.create_order('A'); x.payment(o,'pay-1','captured'); x.tax(o,'tax-1','rejected'); assert o.payment_status=='captured' and o.tax_status=='rejected'
    def return_once():
        x=Ledger(); o=x.create_order('A'); x.apply_sale(o,Decimal('4')); x.return_stock(o,'r1',Decimal('2'),'restock'); x.return_stock(o,'r1',Decimal('2'),'restock'); assert x.stock['sku']==Decimal('98')
    def damaged_return():
        x=Ledger(); o=x.create_order('A'); x.apply_sale(o,Decimal('4')); x.return_stock(o,'r2',Decimal('2'),'damage'); assert x.stock['sku']==Decimal('96')
    def unknown_payment_not_completion():
        x=Ledger(); o=x.create_order('A'); x.payment(o,'pay-x','unknown'); assert o.payment_status=='unknown' and o.state!='completed'
    def failed_stock_atomicity_model():
        x=Ledger(); before=x.stock['sku'];
        try: x.apply_sale(x.create_order('A'), Decimal('101'))
        except ValueError: pass
        assert x.stock['sku']==before and len(x.movement_keys)==0
    def capabilities_optional():
        base={'catalog','order','inventory'}; restaurant=base|{'restaurant','kitchen_kds'}; wholesale=base|{'wholesale'}
        assert 'kitchen_kds' not in wholesale and 'wholesale' not in restaurant
    tests=[
        ('order idempotency', retry_order),
        ('inventory decrement exactly once', stock_once),
        ('payment retry idempotency', payment_retry),
        ('payment and tax state remain independent', tax_independent),
        ('restock return exactly once', return_once),
        ('damaged return does not inflate sellable stock', damaged_return),
        ('unknown payment cannot imply completion', unknown_payment_not_completion),
        ('insufficient stock leaves ledger unchanged', failed_stock_atomicity_model),
        ('industry capabilities remain optional', capabilities_optional),
    ]
    for n,f in tests: check(n,f)
    print(f'COMMERCIAL LIFECYCLE VALIDATION OK: {len(tests)}/{len(tests)}')

if __name__=='__main__': main()
