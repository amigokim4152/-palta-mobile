from pathlib import Path
p = Path('docs/LOCAL_BUSINESS_ENVIRONMENT_SCENARIOS_V1.md')
t = p.read_text()
checks = {
 'tourist_trip_context': 'current/selected/trip area' in t,
 'seasonal_live_state': 'special/seasonal hours' in t and 'last verification' in t,
 'tourist_parking_relation': 'nearby parking place' in t,
 'service_area_no_home_address': "home address" in t and '`service_area`' in t,
 'sparse_expansion_explained': 'scope expanded' in t,
 'centro_parking_types': 'own_free, own_paid, building_shared, nearby_paid' in t,
 'centro_parking_place': 'separate nearby parking Place' in t,
 'centro_no_street_assumption': 'do not imply street parking' in t,
 'paid_separate': 'separate labeled sponsored surface' in t,
 'no_best_claim': '`#1`, `best`' in t,
 'regional_density_expansion': 'widen discovery based on result density' in t,
 'category_specific_radius': 'cafes/convenience remain tight-radius' in t,
 'specialty_over_distance': 'specialty/fit and service coverage can outrank raw distance' in t,
 'quote_bounded': 'bounded set of eligible providers' in t,
 'quote_contact_privacy': 'contact details remain purpose-bound' in t,
 'small_business_fairness': 'new/small businesses get discovery opportunity' in t,
 'community_separation': 'Official/operator content, community content and Palta-derived reputation remain separate' in t,
 'badge_not_buyable': 'never purchasable' in t,
 'core_not_reopened': 'do not justify reopening Core V1' in t,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
assert all(checks.values())
print(f'PASS {len(checks)}/{len(checks)} environment scenario contracts')
