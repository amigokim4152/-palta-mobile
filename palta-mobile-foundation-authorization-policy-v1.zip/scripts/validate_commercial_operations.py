#!/usr/bin/env python3
"""Deterministic Commercial/POS operational-control checks.
Covers permissions, caja, transfers, exchanges, and offline reconnect semantics.
This is a contract simulation, not a real PostgreSQL concurrency test.
"""
from dataclasses import dataclass, field
from decimal import Decimal

@dataclass
class Ops:
    stock: dict[tuple[str,str], Decimal] = field(default_factory=lambda: {('A','sku'): Decimal('100'), ('B','sku'): Decimal('10')})
    movements: set[str] = field(default_factory=set)
    sync_receipts: dict[tuple[str,str], str] = field(default_factory=dict)
    cash_movements: dict[str, int] = field(default_factory=dict)
    roles: dict[tuple[str,str], set[str]] = field(default_factory=dict)
    assignments: list[tuple[str,str,str|None]] = field(default_factory=list)  # person, role, location

    def allow(self, role, *permissions):
        self.roles[('biz', role)] = set(permissions)

    def assign(self, person, role, location=None):
        self.assignments.append((person, role, location))

    def authorized(self, person, permission, location):
        for p, role, loc in self.assignments:
            if p == person and (loc is None or loc == location):
                if permission in self.roles.get(('biz', role), set()):
                    return True
        return False

    def cash(self, key, amount):
        self.cash_movements.setdefault(key, amount)

    def expected_cash(self, opening):
        return opening + sum(self.cash_movements.values())

    def transfer_ship(self, transfer_key, qty):
        k=f'transfer-out:{transfer_key}:sku'
        if k in self.movements: return
        if self.stock[('A','sku')] < qty: raise ValueError('insufficient_stock')
        self.stock[('A','sku')] -= qty; self.movements.add(k)

    def transfer_receive(self, transfer_key, qty):
        out=f'transfer-out:{transfer_key}:sku'; k=f'transfer-in:{transfer_key}:sku'
        if out not in self.movements: raise ValueError('not_shipped')
        if k in self.movements: return
        self.stock[('B','sku')] += qty; self.movements.add(k)

    def sync(self, device, op_id, base_version, server_version):
        key=(device,op_id)
        if key in self.sync_receipts: return self.sync_receipts[key]
        status='applied' if base_version == server_version else 'conflict'
        self.sync_receipts[key]=status
        return status


def check(name, fn):
    fn(); print(f'PASS {name}')

def main():
    def location_permissions():
        x=Ops(); x.allow('cashier','sale.create','return.request'); x.assign('ana','cashier','A')
        assert x.authorized('ana','sale.create','A') and not x.authorized('ana','sale.create','B')
        assert not x.authorized('ana','inventory.adjust','A')

    def business_wide_manager():
        x=Ops(); x.allow('manager','inventory.adjust'); x.assign('maria','manager',None)
        assert x.authorized('maria','inventory.adjust','A') and x.authorized('maria','inventory.adjust','B')

    def cash_retry_once():
        x=Ops(); x.cash('sale-1',10000); x.cash('sale-1',10000); x.cash('refund-1',-2500)
        assert x.expected_cash(50000) == 57500 and len(x.cash_movements)==2

    def close_variance_does_not_rewrite():
        x=Ops(); x.cash('sale-1',10000); expected=x.expected_cash(50000); counted=59500; variance=counted-expected
        assert expected==60000 and variance==-500 and x.cash_movements['sale-1']==10000

    def transfer_exactly_once():
        x=Ops(); x.transfer_ship('T1',Decimal('7')); x.transfer_ship('T1',Decimal('7'))
        x.transfer_receive('T1',Decimal('7')); x.transfer_receive('T1',Decimal('7'))
        assert x.stock[('A','sku')]==Decimal('93') and x.stock[('B','sku')]==Decimal('17')

    def receive_before_ship_blocked():
        x=Ops()
        try: x.transfer_receive('T2',Decimal('2'))
        except ValueError as e: assert str(e)=='not_shipped'
        else: raise AssertionError('receive must not precede ship')
        assert x.stock[('B','sku')]==Decimal('10')

    def exchange_is_return_plus_order():
        # Contract: never mutate original sale line/price in place.
        original={'order':'O1','qty':1,'price':12000}; return_case={'return':'R1','original_order':'O1'}; replacement={'order':'O2','price':15000}
        exchange={'return':'R1','replacement_order':'O2'}
        assert original['price']==12000 and exchange['return']==return_case['return'] and replacement['price']-original['price']==3000

    def offline_retry_idempotent():
        x=Ops(); a=x.sync('device-1','op-99',4,4); b=x.sync('device-1','op-99',4,5)
        assert a=='applied' and b=='applied' and len(x.sync_receipts)==1

    def stale_offline_write_conflicts():
        x=Ops(); assert x.sync('device-1','op-100',3,4)=='conflict'

    def no_last_write_wins_for_stock():
        # Two devices start from version 8. First applies -> server 9; second must conflict.
        x=Ops(); first=x.sync('d1','stock-op-a',8,8); second=x.sync('d2','stock-op-b',8,9)
        assert first=='applied' and second=='conflict'

    tests=[
        ('location-scoped staff permission', location_permissions),
        ('business-wide manager permission', business_wide_manager),
        ('cash movement retry exactly once', cash_retry_once),
        ('caja variance does not rewrite sales', close_variance_does_not_rewrite),
        ('multi-location transfer exactly once', transfer_exactly_once),
        ('transfer cannot receive before ship', receive_before_ship_blocked),
        ('exchange preserves return plus replacement order', exchange_is_return_plus_order),
        ('offline retry is idempotent', offline_retry_idempotent),
        ('stale offline write becomes explicit conflict', stale_offline_write_conflicts),
        ('stock does not use last-write-wins', no_last_write_wins_for_stock),
    ]
    for n,f in tests: check(n,f)
    print(f'COMMERCIAL OPERATIONS VALIDATION OK: {len(tests)}/{len(tests)}')

if __name__=='__main__': main()
