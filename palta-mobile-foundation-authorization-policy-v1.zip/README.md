# Palta mobile foundation

Zero-base foundation for the new Palta mobile application.

## Product boundary
- Primary product: iOS/Android app using React Native + Expo.
- API: Cloudflare Workers.
- Operational database: standard PostgreSQL, provider-independent.
- Large/static assets: Cloudflare R2.
- Maps/GTFS: existing Santiago assets connect later; they are not a blocker for core development.
- Municipalidad/local-graph data: built in parallel and attached through the data/API boundary.
- Base44: legacy/reference/export only, never a runtime dependency.

## Core implemented in this foundation
- Provider-neutral identity boundary
- User/location/relationship schema
- Consent/preferences
- Event/notification core and transactional outbox
- Privacy/audit foundation
- Versioned API router and envelopes
- AI gateway boundary (provider intentionally not configured yet)
- Mobile API/session boundaries

## Safety by default
Until real PostgreSQL/auth/R2 credentials are connected, production writes and authentication remain deliberately unavailable. There is no fake login and no fake business/municipality dataset.

## Next concrete infrastructure step
Provision the low-cost PostgreSQL/auth choice, run migrations, bind Worker/R2, then implement the first real journey: sign-in → location → private context → personal home bootstrap.

## Kernel v1 validation

The validated kernel/database direction is documented in:
- `docs/PALTA_KERNEL_V1_VALIDATED_DESIGN.md`
- `docs/API_CONTRACT_V1.md`

SQL migrations `002` and `003` now reflect the validated Person/Geo/Relationship/Event/Relevance/Action/Case/History model. These are design-stage migrations and have not been applied to production.

## Contract simulation

Run the cross-domain Kernel validation:

```bash
python3 scripts/validate_kernel.py
python3 scripts/simulate_kernel_scenarios.py
```

The scenario suite uses deterministic fixtures only. It verifies shared contracts for location switching, municipal eligibility, school/WhatsApp intake, business service history, and local-event projection.
