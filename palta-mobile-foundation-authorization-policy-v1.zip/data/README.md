# Palta data pipeline

- `raw/`: source exports as collected. Never hand-edit source facts here.
- `canonical/`: normalized Palta records.
- `serving/`: generated app/API snapshots. Do not hand-edit.

The first end-to-end test must use a real existing Palta dataset. No invented records are bundled in this repository.
